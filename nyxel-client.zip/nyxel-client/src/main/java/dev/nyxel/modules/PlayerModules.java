package dev.nyxel.modules;

import dev.nyxel.core.*;
import net.minecraft.block.BlockState;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

import java.util.Random;

public final class PlayerModules {
    private PlayerModules() {}

    public static void register() {
        ModuleManager.reg(new AutoEat());
        ModuleManager.reg(new AutoRespawn());
        ModuleManager.reg(new AntiAFK());
        ModuleManager.reg(new AutoTool());
        ModuleManager.reg(new AutoLog());
    }

    public static class AutoEat extends Mod {
        final Setting.Num hunger = numI("Hunger", 14, 1, 19);
        boolean eating; int prev;
        public AutoEat() { super("AutoEat", "Je jedzenie z hotbara, gdy jestes glodny", Category.PLAYER); }

        static boolean good(ItemStack s) {
            return s.contains(DataComponentTypes.FOOD) && !s.isOf(Items.ROTTEN_FLESH) && !s.isOf(Items.SPIDER_EYE)
                    && !s.isOf(Items.POISONOUS_POTATO) && !s.isOf(Items.PUFFERFISH) && !s.isOf(Items.CHORUS_FRUIT)
                    && !s.isOf(Items.GOLDEN_APPLE) && !s.isOf(Items.ENCHANTED_GOLDEN_APPLE)
                    && !s.isOf(Items.SUSPICIOUS_STEW);
        }
        void stop() {
            mc.options.useKey.setPressed(false);
            if (eating) mc.player.getInventory().setSelectedSlot(prev);
            eating = false;
        }
        @Override public void onDisable() { if (mc.player != null) stop(); }
        @Override public void onTick() {
            int h = mc.player.getHungerManager().getFoodLevel();
            if (!eating) {
                if (h > hunger.i() || mc.currentScreen != null) return;
                for (int i = 0; i < 9; i++) if (good(mc.player.getInventory().getStack(i))) {
                    prev = mc.player.getInventory().getSelectedSlot();
                    mc.player.getInventory().setSelectedSlot(i);
                    mc.options.useKey.setPressed(true);
                    eating = true;
                    return;
                }
            } else if (h >= 20 || !good(mc.player.getMainHandStack())) stop();
        }
    }

    public static class AutoRespawn extends Mod {
        public AutoRespawn() { super("AutoRespawn", "Automatycznie odradza po smierci", Category.PLAYER); }
        @Override public void onTick() {
            if (mc.currentScreen instanceof DeathScreen || mc.player.isDead()) mc.player.requestRespawn();
        }
    }

    public static class AntiAFK extends Mod {
        final Setting.Num interval = numI("IntervalTicks", 80, 20, 600);
        final Random rnd = new Random();
        public AntiAFK() { super("AntiAFK", "Ruchy zapobiegajace kickowi za AFK", Category.PLAYER); }
        @Override public void onTick() {
            if (mc.player.age % interval.i() != 0) return;
            mc.player.setYaw(mc.player.getYaw() + (rnd.nextFloat() - 0.5f) * 50f);
            if (mc.player.isOnGround()) mc.player.jump();
            mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        }
    }

    public static class AutoTool extends Mod {
        public AutoTool() { super("AutoTool", "Wybiera najlepsze narzedzie do kopanego bloku", Category.PLAYER); }
        @Override public void onTick() {
            if (!mc.options.attackKey.isPressed() || mc.currentScreen != null) return;
            if (!(mc.crosshairTarget instanceof BlockHitResult r) || r.getType() != HitResult.Type.BLOCK) return;
            BlockState st = mc.world.getBlockState(r.getBlockPos());
            int best = mc.player.getInventory().getSelectedSlot();
            float bs = mc.player.getInventory().getStack(best).getMiningSpeedMultiplier(st);
            for (int i = 0; i < 9; i++) {
                float s = mc.player.getInventory().getStack(i).getMiningSpeedMultiplier(st);
                if (s > bs + 0.1f) { bs = s; best = i; }
            }
            mc.player.getInventory().setSelectedSlot(best);
        }
    }

    public static class AutoLog extends Mod {
        final Setting.Num health = num("Health", 6, 1, 19);
        public AutoLog() { super("AutoLog", "Wylogowuje, gdy zdrowie spadnie ponizej progu", Category.PLAYER); }
        @Override public void onTick() {
            if (mc.player.getHealth() > health.d() || mc.getNetworkHandler() == null) return;
            setEnabled(false);
            mc.getNetworkHandler().getConnection().disconnect(Text.literal("[Nyxel] AutoLog: zdrowie " + (int) mc.player.getHealth()));
        }
    }
}
