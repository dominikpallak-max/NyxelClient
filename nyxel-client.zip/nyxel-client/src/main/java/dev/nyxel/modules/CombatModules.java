package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public final class CombatModules {
    private CombatModules() {}

    public static void register() {
        ModuleManager.reg(new KillAura());
        ModuleManager.reg(new TriggerBot());
        ModuleManager.reg(new Aimbot());
        ModuleManager.reg(new AutoTotem());
        ModuleManager.reg(new AutoArmor());
        ModuleManager.reg(new AutoTrap());
        ModuleManager.reg(new SelfTrap());
        ModuleManager.reg(new Surround());
        ModuleManager.reg(new AutoWeb());
    }

    public static class KillAura extends Mod {
        final Setting.Num range = num("Range", 4.2, 1, 6), cooldown = num("Cooldown", 0.92, 0, 1);
        final Setting.Bool players = bool("Players", true), hostile = bool("Hostile", true),
                animals = bool("Animals", false), rotate = bool("Rotate", true), walls = bool("ThroughWalls", false);
        final Setting.Mode sort = mode("Sort", "Distance", "Distance", "Health");
        public KillAura() { super("KillAura", "Automatycznie atakuje pobliskie cele", Category.COMBAT); }
        @Override public void onTick() {
            var list = Util.targets(range.d(), players.get(), hostile.get(), animals.get(), walls.get(), sort.is("Health"));
            if (list.isEmpty()) return;
            LivingEntity t = list.get(0);
            if (rotate.get()) Util.lookAt(t.getBoundingBox().getCenter());
            if (mc.player.getAttackCooldownProgress(0f) < cooldown.f()) return;
            mc.interactionManager.attackEntity(mc.player, t);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }

    public static class TriggerBot extends Mod {
        final Setting.Num cooldown = num("Cooldown", 0.95, 0, 1);
        final Setting.Bool players = bool("Players", true), mobs = bool("Mobs", true);
        public TriggerBot() { super("TriggerBot", "Bije to, na co patrzysz, gdy bron jest naladowana", Category.COMBAT); }
        @Override public void onTick() {
            if (mc.currentScreen != null || !(mc.crosshairTarget instanceof EntityHitResult r)) return;
            Entity e = r.getEntity();
            if (!(e instanceof LivingEntity le) || !le.isAlive()) return;
            if (e instanceof PlayerEntity p) { if (!players.get() || Util.isFriend(p)) return; } else if (!mobs.get()) return;
            if (mc.player.getAttackCooldownProgress(0f) < cooldown.f()) return;
            mc.interactionManager.attackEntity(mc.player, e);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }

    public static class Aimbot extends Mod {
        final Setting.Num range = num("Range", 6, 1, 20);
        final Setting.Bool onlyAttack = bool("OnlyWhenAttacking", true);
        public Aimbot() { super("Aimbot", "Celuje w najblizszego gracza", Category.COMBAT); }
        @Override public void onTick() {
            if (onlyAttack.get() && !mc.options.attackKey.isPressed()) return;
            PlayerEntity p = Util.nearestPlayer(range.d());
            if (p != null) Util.lookAt(p.getBoundingBox().getCenter());
        }
    }

    public static class AutoTotem extends Mod {
        final Setting.Mode mode = mode("Mode", "Smart", "Smart", "Always");
        final Setting.Num health = num("Health", 10, 1, 20);
        final Setting.Num delay = numI("Delay", 0, 0, 20);
        int timer;
        public AutoTotem() { super("AutoTotem", "Wklada totem do drugiej reki", Category.COMBAT); }
        @Override public void onTick() {
            if (timer > 0) { timer--; return; }
            if (mc.currentScreen != null || mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
            if (mode.is("Smart") && mc.player.getHealth() + mc.player.getAbsorptionAmount() > health.d()) return;
            for (int i = 0; i < 36; i++) {
                if (mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                    mc.interactionManager.clickSlot(0, Util.screenSlot(i), 40, SlotActionType.SWAP, mc.player);
                    timer = delay.i();
                    return;
                }
            }
        }
    }

    public static class AutoArmor extends Mod {
        final Setting.Num delay = numI("Delay", 4, 0, 20);
        int timer;
        public AutoArmor() { super("AutoArmor", "Zaklada brakujace elementy zbroi", Category.COMBAT); }
        @Override public void onTick() {
            if (timer > 0) { timer--; return; }
            if (mc.currentScreen != null) return;
            for (int i = 0; i < 36; i++) {
                ItemStack s = mc.player.getInventory().getStack(i);
                if (s.isEmpty()) continue;
                EquipmentSlot es = mc.player.getPreferredEquipmentSlot(s);
                if (!es.isArmorSlot() || !mc.player.getEquippedStack(es).isEmpty()) continue;
                mc.interactionManager.clickSlot(0, Util.screenSlot(i), 0, SlotActionType.QUICK_MOVE, mc.player);
                timer = delay.i();
                return;
            }
        }
    }

    /** Wspolna logika stawiania listy blokow z limitem na tick. */
    abstract static class Placer extends Mod {
        final Setting.Num perTick = numI("BlocksPerTick", 2, 1, 6);
        final Setting.Bool rotate = bool("Rotate", false);
        boolean warned;
        Placer(String n, String d) { super(n, d, Category.COMBAT); }
        @Override public void onEnable() { warned = false; }
        abstract net.minecraft.item.Item item();
        void placeAll(List<BlockPos> plan) {
            int slot = Util.findHotbar(s -> s.isOf(item()));
            if (slot < 0) {
                if (!warned) { Util.info("§cBrak " + item().getName().getString() + " w hotbarze"); warned = true; }
                return;
            }
            int n = 0;
            for (BlockPos p : plan) {
                if (n >= perTick.i()) break;
                if (Util.place(p, slot, rotate.get())) n++;
            }
        }
    }

    static List<BlockPos> ring(BlockPos f, boolean feet, boolean head, boolean top) {
        List<BlockPos> l = new ArrayList<>();
        if (feet) for (Direction d : Direction.Type.HORIZONTAL) l.add(f.offset(d));
        if (head) for (Direction d : Direction.Type.HORIZONTAL) l.add(f.up().offset(d));
        if (top) l.add(f.up(2));
        return l;
    }

    public static class AutoTrap extends Placer {
        final Setting.Num range = num("Range", 5, 1, 6);
        public AutoTrap() { super("AutoTrap", "Zamyka najblizszego gracza w obsydianie"); }
        net.minecraft.item.Item item() { return Items.OBSIDIAN; }
        @Override public void onTick() {
            PlayerEntity t = Util.nearestPlayer(range.d());
            if (t != null) placeAll(ring(t.getBlockPos(), true, true, true));
        }
    }

    public static class SelfTrap extends Placer {
        public SelfTrap() { super("SelfTrap", "Zamyka ciebie w obsydianie (glowa + sufit)"); }
        net.minecraft.item.Item item() { return Items.OBSIDIAN; }
        @Override public void onTick() { placeAll(ring(mc.player.getBlockPos(), false, true, true)); }
    }

    public static class Surround extends Placer {
        public Surround() { super("Surround", "Obsydian wokol twoich stop"); }
        net.minecraft.item.Item item() { return Items.OBSIDIAN; }
        @Override public void onTick() { placeAll(ring(mc.player.getBlockPos(), true, false, false)); }
    }

    public static class AutoWeb extends Placer {
        final Setting.Num range = num("Range", 5, 1, 6);
        public AutoWeb() { super("AutoWeb", "Stawia pajeczyne na nogach i glowie celu"); }
        net.minecraft.item.Item item() { return Items.COBWEB; }
        @Override public void onTick() {
            PlayerEntity t = Util.nearestPlayer(range.d());
            if (t == null) return;
            placeAll(List.of(t.getBlockPos(), t.getBlockPos().up()));
        }
    }
}
