package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;

public final class MovementPlus {
    private MovementPlus() {}

    public static void register() {
        ModuleManager.reg(new Jesus());
        ModuleManager.reg(new Sneak());
        ModuleManager.reg(new EdgeSneak());
        ModuleManager.reg(new HighJump());
        ModuleManager.reg(new LongJump());
        ModuleManager.reg(new Strafe());
        ModuleManager.reg(new Bhop());
        ModuleManager.reg(new AutoWalk());
        ModuleManager.reg(new ElytraBoost());
        ModuleManager.reg(new FastFall());
        ModuleManager.reg(new Hover());
        ModuleManager.reg(new Jetpack());
        ModuleManager.reg(new WaterSpeed());
        ModuleManager.reg(new AutoSwim());
        ModuleManager.reg(new Dash());
        ModuleManager.reg(new Launch());
        ModuleManager.reg(new RocketBoost());
    }

    public static class Jesus extends Mod {
        public Jesus() { super("Jesus", "Chodzenie po wodzie", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.player.isTouchingWater() && !mc.options.sneakKey.isPressed()) {
                Vec3d v = mc.player.getVelocity();
                mc.player.setVelocity(v.x, 0.11, v.z);
            }
        }
    }

    public static class Sneak extends Mod {
        public Sneak() { super("Sneak", "Zawsze skradasz sie", Category.MOVEMENT); }
        @Override public void onTick() { mc.options.sneakKey.setPressed(true); }
        @Override public void onDisable() { mc.options.sneakKey.setPressed(false); }
    }

    public static class EdgeSneak extends Mod {
        boolean set;
        public EdgeSneak() { super("EdgeSneak", "Automatycznie kucasz na krawedzi (nie spadniesz)", Category.MOVEMENT); }
        @Override public void onTick() {
            boolean edge = mc.player.isOnGround()
                    && mc.world.isSpaceEmpty(mc.player, mc.player.getBoundingBox().offset(0, -0.6, 0).expand(0.1, 0, 0.1).contract(0.0, 0, 0.0));
            if (edge) { mc.options.sneakKey.setPressed(true); set = true; }
            else if (set) { mc.options.sneakKey.setPressed(false); set = false; }
        }
        @Override public void onDisable() { if (set) mc.options.sneakKey.setPressed(false); set = false; }
    }

    public static class HighJump extends Mod {
        final Setting.Num height = num("Height", 0.8, 0.42, 3);
        public HighJump() { super("HighJump", "Wyzsze skoki", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.player.isOnGround() && mc.options.jumpKey.isPressed()) {
                Vec3d v = mc.player.getVelocity();
                mc.player.setVelocity(v.x, height.d(), v.z);
            }
        }
    }

    public static class LongJump extends Mod {
        final Setting.Num boost = num("Boost", 0.9, 0.3, 3);
        public LongJump() { super("LongJump", "Dlugie skoki do przodu", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.player.isOnGround() && mc.options.jumpKey.isPressed() && Util.moving()) {
                Util.setHorizontalSpeed(boost.d());
                Vec3d v = mc.player.getVelocity();
                mc.player.setVelocity(v.x, 0.5, v.z);
            }
        }
    }

    public static class Strafe extends Mod {
        public Strafe() { super("Strafe", "Pelna kontrola ruchu w powietrzu", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.player.isOnGround() || !Util.moving()) return;
            Vec3d v = mc.player.getVelocity();
            Util.setHorizontalSpeed(Math.max(0.2, Math.sqrt(v.x * v.x + v.z * v.z)));
        }
    }

    public static class Bhop extends Mod {
        final Setting.Num speed = num("Speed", 1.2, 0.5, 3);
        public Bhop() { super("Bhop", "Bunny hop - skacze i przyspiesza", Category.MOVEMENT); }
        @Override public void onTick() {
            if (!Util.moving()) return;
            if (mc.player.isOnGround()) mc.player.jump();
            Util.setHorizontalSpeed(0.28 * speed.d());
        }
    }

    public static class AutoWalk extends Mod {
        public AutoWalk() { super("AutoWalk", "Ciagle idziesz do przodu", Category.MOVEMENT); }
        @Override public void onTick() { mc.options.forwardKey.setPressed(true); }
        @Override public void onDisable() { mc.options.forwardKey.setPressed(false); }
    }

    public static class ElytraBoost extends Mod {
        final Setting.Num boost = num("Boost", 1.0, 0.1, 5);
        public ElytraBoost() { super("ElytraBoost", "Trzymaj skok podczas lotu na elytrach, zeby przyspieszac", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.player.isGliding() && mc.options.jumpKey.isPressed()) {
                Vec3d look = mc.player.getRotationVector();
                mc.player.setVelocity(mc.player.getVelocity().add(look.multiply(0.05 * boost.d())));
            }
        }
    }

    public static class FastFall extends Mod {
        final Setting.Num mult = num("Multiplier", 1.5, 1, 4);
        public FastFall() { super("FastFall", "Szybsze spadanie", Category.MOVEMENT); }
        @Override public void onTick() {
            Vec3d v = mc.player.getVelocity();
            if (!mc.player.isOnGround() && v.y < 0) mc.player.setVelocity(v.x, Math.max(v.y * mult.d(), -3.5), v.z);
        }
    }

    public static class Hover extends Mod {
        public Hover() { super("Hover", "Trzymaj sneak, zeby zawisnac w powietrzu", Category.MOVEMENT); }
        @Override public void onTick() {
            if (!mc.player.isOnGround() && mc.options.sneakKey.isPressed()) {
                Vec3d v = mc.player.getVelocity();
                mc.player.setVelocity(v.x, 0, v.z);
            }
        }
    }

    public static class Jetpack extends Mod {
        final Setting.Num power = num("Power", 0.5, 0.1, 2);
        public Jetpack() { super("Jetpack", "Trzymaj skok w powietrzu, zeby lecec w gore", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.options.jumpKey.isPressed() && !mc.player.isOnGround()) {
                Vec3d v = mc.player.getVelocity();
                mc.player.setVelocity(v.x, power.d(), v.z);
            }
        }
    }

    public static class WaterSpeed extends Mod {
        final Setting.Num speed = num("Speed", 1.5, 0.5, 4);
        public WaterSpeed() { super("WaterSpeed", "Szybsze plywanie", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.player.isTouchingWater() && Util.moving()) Util.setHorizontalSpeed(0.17 * speed.d());
        }
    }

    public static class AutoSwim extends Mod {
        boolean set;
        public AutoSwim() { super("AutoSwim", "Automatycznie plyniesz w gore w wodzie", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.player.isTouchingWater()) { mc.options.jumpKey.setPressed(true); set = true; }
            else if (set) { mc.options.jumpKey.setPressed(false); set = false; }
        }
        @Override public void onDisable() { if (set) mc.options.jumpKey.setPressed(false); set = false; }
    }

    public static class Dash extends OneShot {
        final Setting.Num power = num("Power", 1.6, 0.5, 5);
        public Dash() { super("Dash", "Jednorazowy zryw w kierunku patrzenia (bind!)", Category.MOVEMENT); }
        @Override protected void run() {
            Vec3d l = mc.player.getRotationVector();
            mc.player.setVelocity(l.x * power.d(), 0.25, l.z * power.d());
        }
    }

    public static class Launch extends OneShot {
        final Setting.Num power = num("Power", 1.8, 0.5, 6);
        public Launch() { super("Launch", "Jednorazowy wystrzal w gore (bind!)", Category.MOVEMENT); }
        @Override protected void run() {
            Vec3d v = mc.player.getVelocity();
            mc.player.setVelocity(v.x, power.d(), v.z);
        }
    }

    public static class RocketBoost extends OneShot {
        public RocketBoost() { super("RocketBoost", "Uzywa fajerwerku z hotbara (lot na elytrach)", Category.MOVEMENT); }
        @Override protected void run() {
            int s = Util.findHotbar(i -> i.isOf(Items.FIREWORK_ROCKET));
            if (s < 0) Util.info("§cBrak fajerwerku w hotbarze"); else Util.useItem(s);
        }
    }
}
