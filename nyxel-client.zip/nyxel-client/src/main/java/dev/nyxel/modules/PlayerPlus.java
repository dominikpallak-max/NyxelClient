package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import net.minecraft.client.gui.screen.ingame.AnvilScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public final class PlayerPlus {
    private PlayerPlus() {}

    public static void register() {
        ModuleManager.reg(new AutoReplenish());
        ModuleManager.reg(new AutoDrop());
        ModuleManager.reg(new XPThrower());
        ModuleManager.reg(new InvMove());
        ModuleManager.reg(new AutoMine());
        ModuleManager.reg(new AutoUse());
        ModuleManager.reg(new RotationLock());
        ModuleManager.reg(new OffhandSwap());
    }

    public static class AutoReplenish extends Mod {
        final Setting.Num threshold = numI("Threshold", 8, 1, 32);
        int timer;
        public AutoReplenish() { super("AutoReplenish", "Uzupelnia konczace sie stacki w hotbarze", Category.PLAYER); }
        @Override public void onTick() {
            if (timer-- > 0 || mc.currentScreen != null) return;
            for (int i = 0; i < 9; i++) {
                ItemStack h = mc.player.getInventory().getStack(i);
                if (h.isEmpty() || !h.isStackable() || h.getCount() > threshold.i() || h.getCount() >= h.getMaxCount()) continue;
                for (int j = 9; j < 36; j++) {
                    ItemStack s = mc.player.getInventory().getStack(j);
                    if (!s.isEmpty() && ItemStack.areItemsAndComponentsEqual(h, s)) {
                        mc.interactionManager.clickSlot(0, j, i, SlotActionType.SWAP, mc.player);
                        timer = 4;
                        return;
                    }
                }
            }
        }
    }

    public static class AutoDrop extends Mod {
        final Setting.Str items = str("Items", "dirt,cobblestone,gravel,rotten_flesh,spider_eye,andesite,diorite,granite");
        final Setting.Num delay = numI("DelayTicks", 2, 0, 20);
        int timer;
        public AutoDrop() { super("AutoDrop", "Wyrzuca niechciane przedmioty (.set AutoDrop Items dirt,gravel)", Category.PLAYER); }
        @Override public void onTick() {
            if (timer-- > 0 || mc.currentScreen != null) return;
            Set<String> junk = new HashSet<>(Arrays.asList(items.get().toLowerCase().replace(" ", "").split(",")));
            for (int i = 0; i < 36; i++) {
                ItemStack s = mc.player.getInventory().getStack(i);
                if (s.isEmpty()) continue;
                if (junk.contains(Registries.ITEM.getId(s.getItem()).getPath())) {
                    mc.interactionManager.clickSlot(0, Util.screenSlot(i), 1, SlotActionType.THROW, mc.player);
                    timer = delay.i();
                    return;
                }
            }
        }
    }

    public static class XPThrower extends Mod {
        final Setting.Num delay = numI("DelayTicks", 3, 1, 20);
        int prev = -1;
        public XPThrower() { super("XPThrower", "Rzuca butelki XP w dol (naprawia ekwipunek)", Category.PLAYER); }
        @Override public void onEnable() { prev = -1; }
        @Override public void onDisable() { if (prev >= 0 && mc.player != null) mc.player.getInventory().setSelectedSlot(prev); prev = -1; }
        @Override public void onTick() {
            int s = Util.findHotbar(i -> i.isOf(Items.EXPERIENCE_BOTTLE));
            if (s < 0) return;
            if (prev < 0) prev = mc.player.getInventory().getSelectedSlot();
            mc.player.getInventory().setSelectedSlot(s);
            mc.player.setPitch(90f);
            if (mc.player.age % delay.i() == 0) Util.useItem(s);
        }
    }

    public static class InvMove extends Mod {
        public InvMove() { super("InvMove", "Ruch (WASD, skok) przy otwartym ekwipunku", Category.PLAYER); }
        private static void sync(long h, KeyBinding k) {
            int code = InputUtil.fromTranslationKey(k.getBoundKeyTranslationKey()).getCode();
            k.setPressed(GLFW.glfwGetKey(h, code) == GLFW.GLFW_PRESS);
        }
        @Override public void onTick() {
            if (!(mc.currentScreen instanceof HandledScreen<?>) || mc.currentScreen instanceof AnvilScreen) return;
            long h = mc.getWindow().getHandle();
            sync(h, mc.options.forwardKey); sync(h, mc.options.backKey);
            sync(h, mc.options.leftKey); sync(h, mc.options.rightKey); sync(h, mc.options.jumpKey);
        }
    }

    public static class AutoMine extends Mod {
        public AutoMine() { super("AutoMine", "Trzyma LPM za ciebie (kopanie/bicie)", Category.PLAYER); }
        @Override public void onTick() { mc.options.attackKey.setPressed(true); }
        @Override public void onDisable() { mc.options.attackKey.setPressed(false); }
    }

    public static class AutoUse extends Mod {
        public AutoUse() { super("AutoUse", "Trzyma PPM za ciebie (jedzenie, luk, stawianie)", Category.PLAYER); }
        @Override public void onTick() { mc.options.useKey.setPressed(true); }
        @Override public void onDisable() { mc.options.useKey.setPressed(false); }
    }

    public static class RotationLock extends Mod {
        final Setting.Num step = num("YawStep", 45, 15, 90);
        final Setting.Bool pitch = bool("LockPitch", false);
        public RotationLock() { super("RotationLock", "Zaokragla yaw do stalych katow (prosta jazda/budowanie)", Category.PLAYER); }
        @Override public void onTick() {
            float st = step.f();
            mc.player.setYaw(Math.round(mc.player.getYaw() / st) * st);
            if (pitch.get()) mc.player.setPitch(0f);
        }
    }

    public static class OffhandSwap extends OneShot {
        public OffhandSwap() { super("OffhandSwap", "Zamienia przedmiot z reki z druga reka (bind!)", Category.PLAYER); }
        @Override protected void run() {
            mc.interactionManager.clickSlot(0, 36 + mc.player.getInventory().getSelectedSlot(), 40, SlotActionType.SWAP, mc.player);
        }
    }
}
