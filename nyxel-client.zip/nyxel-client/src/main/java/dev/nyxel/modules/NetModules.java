package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.PacketHooks;
import dev.nyxel.util.Util;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.common.KeepAliveC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Moduly sieciowe: FakeLag (opoznianie pakietow) i Desync (klient != serwer). */
public final class NetModules {
    private NetModules() {}

    public static void register() {
        ModuleManager.reg(new FakeLag());
        ModuleManager.reg(new Desync());
    }

    private static void hudLine(DrawContext ctx, String text, int yOff) {
        int w = mc().textRenderer.getWidth(text);
        ctx.drawText(mc().textRenderer, text, ctx.getScaledWindowWidth() / 2 - w / 2,
                ctx.getScaledWindowHeight() / 2 + yOff, 0xFFC77DFF, true);
    }
    private static net.minecraft.client.MinecraftClient mc() { return net.minecraft.client.MinecraftClient.getInstance(); }

    // ------------------------------------------------------------------
    public static class FakeLag extends Mod {
        final Setting.Mode mode = mode("Mode", "Constant", "Constant", "Hold");
        final Setting.Num delay = numI("DelayMs", 400, 50, 5000);
        final Setting.Num max = numI("MaxPackets", 300, 20, 2000);
        final Setting.Bool keepAlive = bool("DelayKeepAlive", false);
        final Setting.Bool flushAttack = bool("FlushOnAttack", true);
        final Setting.Bool flushHurt = bool("FlushOnHurt", true);
        final Setting.Bool hud = bool("ShowQueue", true);
        private final List<Packet<?>> queue = new ArrayList<>();
        private long last;

        public FakeLag() {
            super("FakeLag", "Opoznia pakiety ruchu - serwer widzi cie z lagiem", Category.MOVEMENT);
            PacketHooks.FILTERS.add(this::filter);
        }

        private boolean filter(Packet<?> p) {
            if (!enabled || mc.player == null) return false;
            if (flushAttack.get() && p instanceof PlayerInteractEntityC2SPacket) { flush(); return false; }
            boolean q = p instanceof PlayerMoveC2SPacket || (keepAlive.get() && p instanceof KeepAliveC2SPacket);
            if (!q) return false;
            synchronized (queue) { queue.add(p); }
            return true;
        }

        public void flush() {
            List<Packet<?>> snap;
            synchronized (queue) { snap = new ArrayList<>(queue); queue.clear(); }
            last = System.currentTimeMillis();
            for (Packet<?> p : snap) PacketHooks.sendRaw(p);
        }

        @Override public void onEnable() { last = System.currentTimeMillis(); }
        @Override public void onDisable() { flush(); }

        @Override public void onTick() {
            boolean due = mode.is("Constant") && System.currentTimeMillis() - last >= delay.i();
            if (flushHurt.get() && mc.player.hurtTime > 0) due = true;
            int size; synchronized (queue) { size = queue.size(); }
            if (size >= max.i()) due = true;
            if (due) flush();
        }

        @Override public void onHud(DrawContext ctx) {
            if (!hud.get()) return;
            int size; synchronized (queue) { size = queue.size(); }
            hudLine(ctx, "FakeLag: " + size + " pakietow w kolejce", 24);
        }
    }

    // ------------------------------------------------------------------
    public static class Desync extends Mod {
        final Setting.Mode onDisable = mode("OnDisable", "Return", "Return", "Sync");
        final Setting.Bool hud = bool("ShowInfo", true);
        private Vec3d serverPos, lastPos;

        public Desync() {
            super("Desync", "Klient sie rusza, serwer zostaje na starej pozycji", Category.MOVEMENT);
            PacketHooks.FILTERS.add(p -> enabled && mc.player != null && p instanceof PlayerMoveC2SPacket);
        }

        @Override public void onEnable() {
            if (mc.player == null) return;
            serverPos = mc.player.getPos();
            lastPos = serverPos;
        }

        @Override public void onTick() {
            Vec3d now = mc.player.getPos();
            // duzy skok = teleport od serwera (rubberband) -> serwer i klient znowu zgodne
            if (lastPos != null && now.distanceTo(lastPos) > 20) serverPos = now;
            lastPos = now;
        }

        @Override public void onDisable() {
            if (mc.player == null || serverPos == null) return;
            if (onDisable.is("Return")) {
                mc.player.setPosition(serverPos);
                mc.player.setVelocity(Vec3d.ZERO);
            }
            // "Sync": nastepne pakiety ruchu zglosza aktualna pozycje (serwer moze cofnac)
            serverPos = null;
        }

        @Override public void onHud(DrawContext ctx) {
            if (!hud.get() || serverPos == null || mc.player == null) return;
            double d = mc.player.getPos().distanceTo(serverPos);
            hudLine(ctx, String.format("Desync: %.1f bloku od pozycji serwera (%.0f %.0f %.0f)",
                    d, serverPos.x, serverPos.y, serverPos.z), 24);
        }
    }
}
