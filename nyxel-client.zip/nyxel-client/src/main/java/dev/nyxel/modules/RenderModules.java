package dev.nyxel.modules;

import dev.nyxel.NyxelClient;
import dev.nyxel.core.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class RenderModules {
    private RenderModules() {}

    public static void register() {
        ModuleManager.reg(new ESP());
        ModuleManager.reg(new Fullbright());
        ModuleManager.reg(new Hud());
    }

    public static class ESP extends Mod {
        static ESP inst;
        final Setting.Bool players = bool("Players", true), hostile = bool("Hostile", true),
                animals = bool("Animals", false), items = bool("Items", true);
        public ESP() { super("ESP", "Kontur encji widoczny przez sciany", Category.RENDER); inst = this; }
        /** Wolane z EntityMixin. */
        public static boolean shouldGlow(Entity e) {
            if (inst == null || !inst.enabled || e == mc.player) return false;
            if (e instanceof PlayerEntity) return inst.players.get();
            if (e instanceof HostileEntity) return inst.hostile.get();
            if (e instanceof AnimalEntity) return inst.animals.get();
            if (e instanceof ItemEntity) return inst.items.get();
            return false;
        }
    }

    public static class Fullbright extends Mod {
        public Fullbright() { super("Fullbright", "Pelna jasnosc (nocne widzenie po stronie klienta)", Category.RENDER); }
        @Override public void onTick() {
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
        }
        @Override public void onDisable() { if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION); }
    }

    public static class Hud extends Mod {
        final Setting.Bool watermark = bool("Watermark", true), coords = bool("Coords", true),
                fps = bool("FPS", true), ping = bool("Ping", true), arrayList = bool("ArrayList", true);
        static final int PURPLE = 0xFFB45CFF, WHITE = 0xFFFFFFFF, GRAY = 0xFFB8B8C8;

        public Hud() { super("HUD", "Znak wodny, koordynaty, FPS, ping i lista modulow", Category.RENDER); enabled = true; }

        @Override public void onHud(DrawContext ctx) {
            var tr = mc.textRenderer;
            int y = 4;
            if (watermark.get()) {
                ctx.drawText(tr, NyxelClient.NAME, 4, y, PURPLE, true);
                ctx.drawText(tr, "v" + NyxelClient.VERSION, 6 + tr.getWidth(NyxelClient.NAME), y, GRAY, true);
                y += 11;
            }
            if (coords.get()) {
                ctx.drawText(tr, String.format("XYZ %.1f %.1f %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ()), 4, y, WHITE, true);
                y += 10;
            }
            if (fps.get()) { ctx.drawText(tr, "FPS " + mc.getCurrentFps(), 4, y, WHITE, true); y += 10; }
            if (ping.get() && mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (e != null) ctx.drawText(tr, "Ping " + e.getLatency() + "ms", 4, y, WHITE, true);
            }
            if (arrayList.get()) {
                List<Mod> on = new ArrayList<>();
                for (Mod m : ModuleManager.ALL) if (m.enabled && m != this) on.add(m);
                on.sort(Comparator.comparingInt((Mod m) -> -tr.getWidth(m.name)));
                int ry = 4, w = ctx.getScaledWindowWidth();
                for (Mod m : on) {
                    ctx.drawText(tr, m.name, w - tr.getWidth(m.name) - 4, ry, PURPLE, true);
                    ry += 10;
                }
            }
        }
    }
}
