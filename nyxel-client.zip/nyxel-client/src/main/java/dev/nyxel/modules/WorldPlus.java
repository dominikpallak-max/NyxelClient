package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

import java.util.*;
import java.util.function.Predicate;

public final class WorldPlus {
    private WorldPlus() {}

    public static void register() {
        ModuleManager.reg(new AutoHarvest());
        ModuleManager.reg(new AutoLumber());
        ModuleManager.reg(new OreFinder());
        ModuleManager.reg(new SpawnerFinder());
        ModuleManager.reg(new AutoTunnel());
        ModuleManager.reg(new Lawnmower());
        ModuleManager.reg(new AutoBonemeal());
    }

    /** Wszystkie pozycje w kuli o promieniu r spelniajace warunek, od najblizszej. */
    static List<BlockPos> scan(double r, Predicate<BlockState> f) {
        List<BlockPos> out = new ArrayList<>();
        BlockPos c = mc().player.getBlockPos();
        Vec3d eye = mc().player.getEyePos();
        int ri = (int) Math.ceil(r);
        for (int x = -ri; x <= ri; x++) for (int y = -ri; y <= ri; y++) for (int z = -ri; z <= ri; z++) {
            BlockPos p = c.add(x, y, z);
            if (eye.distanceTo(Vec3d.ofCenter(p)) > r) continue;
            if (f.test(mc().world.getBlockState(p))) out.add(p);
        }
        out.sort(Comparator.comparingDouble(p -> eye.squaredDistanceTo(Vec3d.ofCenter(p))));
        return out;
    }
    private static net.minecraft.client.MinecraftClient mc() { return net.minecraft.client.MinecraftClient.getInstance(); }

    public static class AutoHarvest extends Mod {
        final Setting.Num range = num("Range", 4.5, 1, 6);
        public AutoHarvest() { super("AutoHarvest", "Zbiera dojrzale uprawy w poblizu", Category.WORLD); }
        @Override public void onTick() {
            var l = scan(range.d(), s -> s.getBlock() instanceof CropBlock c && c.isMature(s));
            if (!l.isEmpty()) Util.mine(l.get(0));
        }
    }

    public static class AutoLumber extends Mod {
        final Setting.Num range = num("Range", 4.5, 1, 6);
        public AutoLumber() { super("AutoLumber", "Scina pnie drzew w poblizu", Category.WORLD); }
        @Override public void onTick() {
            var l = scan(range.d(), s -> s.isIn(BlockTags.LOGS));
            if (!l.isEmpty()) Util.mine(l.get(0));
        }
    }

    public static class OreFinder extends Mod {
        final Setting.Num radius = numI("Radius", 14, 4, 32);
        final Setting.Bool diamond = bool("Diamond", true), debris = bool("AncientDebris", true),
                emerald = bool("Emerald", true), gold = bool("Gold", false);
        private final Set<Long> seen = new HashSet<>();
        public OreFinder() { super("OreFinder", "Pisze na czacie koordynaty rud w poblizu", Category.WORLD); }
        @Override public void onEnable() { seen.clear(); }
        @Override public void onTick() {
            if (mc.player.age % 40 != 0) return;
            int n = 0;
            for (BlockPos p : scan(radius.d(), this::wanted)) {
                if (!seen.add(p.asLong())) continue;
                Util.info("§b" + mc.world.getBlockState(p).getBlock().getName().getString() + " §fna "
                        + p.getX() + " " + p.getY() + " " + p.getZ());
                if (++n >= 5) break;
            }
        }
        private boolean wanted(BlockState s) {
            return (diamond.get() && s.isIn(BlockTags.DIAMOND_ORES)) || (debris.get() && s.isOf(Blocks.ANCIENT_DEBRIS))
                    || (emerald.get() && s.isIn(BlockTags.EMERALD_ORES)) || (gold.get() && s.isIn(BlockTags.GOLD_ORES));
        }
    }

    public static class SpawnerFinder extends Mod {
        private final Set<Long> seen = new HashSet<>();
        public SpawnerFinder() { super("SpawnerFinder", "Wykrywa spawnery w zaladowanych chunkach", Category.WORLD); }
        @Override public void onEnable() { seen.clear(); }
        @Override public void onTick() {
            if (mc.player.age % 40 != 0) return;
            int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
            int r = Math.min(mc.options.getViewDistance().getValue(), 32);
            for (int cx = pcx - r; cx <= pcx + r; cx++) for (int cz = pcz - r; cz <= pcz + r; cz++) {
                WorldChunk ch = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (ch == null) continue;
                for (BlockEntity be : ch.getBlockEntities().values()) {
                    if (be instanceof MobSpawnerBlockEntity && seen.add(be.getPos().asLong()))
                        Util.info("§6Spawner §fna " + be.getPos().getX() + " " + be.getPos().getY() + " " + be.getPos().getZ());
                }
            }
        }
    }

    public static class AutoTunnel extends Mod {
        final Setting.Num length = numI("Length", 3, 1, 5);
        final Setting.Bool walk = bool("Walk", true);
        public AutoTunnel() { super("AutoTunnel", "Kopie tunel 1x2 przed toba", Category.WORLD); }
        @Override public void onDisable() { mc.options.forwardKey.setPressed(false); }
        @Override public void onTick() {
            Direction d = mc.player.getHorizontalFacing();
            BlockPos b = mc.player.getBlockPos();
            boolean mining = false;
            for (int k = 1; k <= length.i() && !mining; k++) {
                for (BlockPos p : new BlockPos[]{b.offset(d, k), b.offset(d, k).up()}) {
                    BlockState s = mc.world.getBlockState(p);
                    if (!s.isAir() && s.getFluidState().isEmpty() && s.getHardness(mc.world, p) >= 0) { Util.mine(p); mining = true; break; }
                }
            }
            if (walk.get()) mc.options.forwardKey.setPressed(!mining);
        }
    }

    public static class Lawnmower extends Mod {
        final Setting.Num range = num("Range", 4.5, 1, 6);
        public Lawnmower() { super("Lawnmower", "Wycina trawe, kwiaty i krzaki wokol", Category.WORLD); }
        @Override public void onTick() {
            int n = 0;
            for (BlockPos p : scan(range.d(), s -> !s.isAir() && s.isIn(BlockTags.REPLACEABLE) && s.getFluidState().isEmpty())) {
                Util.mine(p);
                if (++n >= 4) break;
            }
        }
    }

    public static class AutoBonemeal extends Mod {
        final Setting.Num range = num("Range", 4.5, 1, 6);
        public AutoBonemeal() { super("AutoBonemeal", "Uzywa mączki kostnej na niedojrzalych uprawach", Category.WORLD); }
        @Override public void onTick() {
            if (mc.player.age % 3 != 0) return;
            int slot = Util.findHotbar(s -> s.isOf(Items.BONE_MEAL));
            if (slot < 0) return;
            var l = scan(range.d(), s -> s.getBlock() instanceof CropBlock c && !c.isMature(s));
            if (l.isEmpty()) return;
            BlockPos p = l.get(0);
            int prev = mc.player.getInventory().getSelectedSlot();
            mc.player.getInventory().setSelectedSlot(slot);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(Vec3d.ofCenter(p), Direction.UP, p, false));
            mc.player.swingHand(Hand.MAIN_HAND);
            mc.player.getInventory().setSelectedSlot(prev);
        }
    }
}
