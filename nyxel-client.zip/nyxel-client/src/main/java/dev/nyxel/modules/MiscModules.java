package dev.nyxel.modules;

import dev.nyxel.core.*;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.item.BlockItem;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;

import java.util.Random;

public final class MiscModules {
    private MiscModules() {}

    public static void register() {
        ModuleManager.reg(new ChestStealer());
        ModuleManager.reg(new Spammer());
        ModuleManager.reg(new PlaceSound());
    }

    public static class ChestStealer extends Mod {
        final Setting.Num delay = numI("DelayTicks", 1, 0, 10);
        final Setting.Bool autoClose = bool("AutoClose", true);
        int timer;
        public ChestStealer() { super("ChestStealer", "Szybko zabiera wszystko z otwartej skrzyni", Category.MISC); }
        @Override public void onTick() {
            if (!(mc.currentScreen instanceof GenericContainerScreen s)) return;
            if (timer-- > 0) return;
            GenericContainerScreenHandler h = s.getScreenHandler();
            int n = h.getRows() * 9;
            for (int i = 0; i < n; i++) {
                if (!h.getSlot(i).getStack().isEmpty()) {
                    mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player);
                    timer = delay.i();
                    return;
                }
            }
            if (autoClose.get()) mc.player.closeHandledScreen();
        }
    }

    public static class Spammer extends Mod {
        final Setting.Str message = str("Message", "Nyxel Client na topie");
        final Setting.Num delay = numI("DelayTicks", 100, 20, 1200);
        final Setting.Bool suffix = bool("RandomSuffix", true);
        final Random rnd = new Random();
        public Spammer() { super("Spammer", "Wysyla wiadomosc na czat co jakis czas (.set Spammer Message ...)", Category.MISC); }
        @Override public void onTick() {
            if (mc.player.age % delay.i() != 0 || mc.getNetworkHandler() == null) return;
            String m = message.get() + (suffix.get() ? " " + Integer.toString(rnd.nextInt(0xFFFF), 36) : "");
            if (m.startsWith("/")) mc.getNetworkHandler().sendChatCommand(m.substring(1));
            else mc.getNetworkHandler().sendChatMessage(m);
        }
    }

    /** Dziwny dzwiek przy stawianiu bloku. */
    public static class PlaceSound extends Mod {
        final Setting.Mode sound = mode("Sound", "Burp", "Burp", "Orb", "ArrowHit", "Anvil", "VillagerNo", "Egg", "Enderman", "Random");
        final Setting.Num volume = num("Volume", 1.0, 0.1, 2);
        final Setting.Num pitch = num("Pitch", 1.0, 0.5, 2);
        final Setting.Bool randomPitch = bool("RandomPitch", true);
        final Random rnd = new Random();

        public PlaceSound() {
            super("PlaceSound", "Odtwarza dzwiek przy stawianiu bloku", Category.MISC);
            UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
                if (enabled && world.isClient() && player == mc.player
                        && player.getStackInHand(hand).getItem() instanceof BlockItem) play();
                return ActionResult.PASS;
            });
        }

        private SoundEvent pick(String n) {
            return switch (n) {
                case "Orb" -> SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP;
                case "ArrowHit" -> SoundEvents.ENTITY_ARROW_HIT_PLAYER;
                case "Anvil" -> SoundEvents.BLOCK_ANVIL_LAND;
                case "VillagerNo" -> SoundEvents.ENTITY_VILLAGER_NO;
                case "Egg" -> SoundEvents.ENTITY_CHICKEN_EGG;
                case "Enderman" -> SoundEvents.ENTITY_ENDERMAN_TELEPORT;
                default -> SoundEvents.ENTITY_PLAYER_BURP;
            };
        }

        private void play() {
            String n = sound.get();
            if (n.equals("Random")) n = sound.options.get(rnd.nextInt(sound.options.size() - 1));
            float p = pitch.f() + (randomPitch.get() ? (rnd.nextFloat() - 0.5f) * 0.6f : 0f);
            mc.getSoundManager().play(PositionedSoundInstance.master(pick(n), Math.max(0.5f, p), volume.f()));
        }
    }
}
