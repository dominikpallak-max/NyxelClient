package dev.nyxel.modules;

import dev.nyxel.core.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.Deque;

/** Widzety HUD (kazdy z ustawieniami X/Y) + Zoom, FovChanger, Crosshair, HealthAlert. */
public final class RenderPlus {
    private RenderPlus() {}
    static final int WHITE = 0xFFFFFFFF, PURPLE = 0xFFB45CFF;

    public static void register() {
        ModuleManager.reg(new ArmorHUD());
        ModuleManager.reg(new Keystrokes());
        ModuleManager.reg(new CPS());
        ModuleManager.reg(new Speedometer());
        ModuleManager.reg(new Clock());
        ModuleManager.reg(new Direction());
        ModuleManager.reg(new PotionHUD());
        ModuleManager.reg(new TotemCount());
        ModuleManager.reg(new WorldTime());
        ModuleManager.reg(new NetherCoords());
        ModuleManager.reg(new ServerInfo());
        ModuleManager.reg(new SessionTimer());
        ModuleManager.reg(new Radar());
        ModuleManager.reg(new Crosshair());
        ModuleManager.reg(new HealthAlert());
        ModuleManager.reg(new Zoom());
        ModuleManager.reg(new FovChanger());
    }

    abstract static class Widget extends Mod {
        final Setting.Num x, y;
        Widget(String n, String d, int dx, int dy) {
            super(n, d, Category.RENDER);
            x = numI("X", dx, 0, 2000);
            y = numI("Y", dy, 0, 1200);
        }
        @Override public final void onHud(DrawContext c) { draw(c, x.i(), y.i()); }
        abstract void draw(DrawContext c, int x, int y);
        static void text(DrawContext c, String s, int x, int y, int col) { c.drawText(mc.textRenderer, s, x, y, col, true); }
    }

    public static class ArmorHUD extends Widget {
        public ArmorHUD() { super("ArmorHUD", "Pancerz i wytrzymalosc na ekranie", 4, 190); }
        void draw(DrawContext c, int x, int y) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            for (int i = 0; i < 4; i++) {
                ItemStack s = mc.player.getEquippedStack(slots[i]);
                if (s.isEmpty()) continue;
                c.drawItem(s, x + i * 18, y);
                c.drawStackOverlay(mc.textRenderer, s, x + i * 18, y);
            }
        }
    }

    public static class Keystrokes extends Widget {
        public Keystrokes() { super("Keystrokes", "Podglad klawiszy WASD i spacji", 4, 215); }
        private void key(DrawContext c, int x, int y, int w, String l, boolean down) {
            c.fill(x, y, x + w, y + 16, down ? 0xAAB45CFF : 0x88000000);
            text(c, l, x + w / 2 - mc.textRenderer.getWidth(l) / 2, y + 4, WHITE);
        }
        void draw(DrawContext c, int x, int y) {
            key(c, x + 18, y, 16, "W", mc.options.forwardKey.isPressed());
            key(c, x, y + 18, 16, "A", mc.options.leftKey.isPressed());
            key(c, x + 18, y + 18, 16, "S", mc.options.backKey.isPressed());
            key(c, x + 36, y + 18, 16, "D", mc.options.rightKey.isPressed());
            key(c, x, y + 36, 52, "SPACE", mc.options.jumpKey.isPressed());
        }
    }

    public static class CPS extends Widget {
        private final Deque<Long> clicks = new ArrayDeque<>();
        private boolean prev;
        public CPS() { super("CPS", "Licznik klikniec na sekunde", 4, 60); }
        @Override public void onTick() {
            boolean d = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
            long now = System.currentTimeMillis();
            if (d && !prev) clicks.add(now);
            prev = d;
            while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.pollFirst();
        }
        void draw(DrawContext c, int x, int y) { text(c, "CPS: " + clicks.size(), x, y, WHITE); }
    }

    public static class Speedometer extends Widget {
        private double lx, lz, bps;
        public Speedometer() { super("Speedometer", "Predkosc w blokach na sekunde", 4, 72); }
        @Override public void onTick() {
            bps = Math.hypot(mc.player.getX() - lx, mc.player.getZ() - lz) * 20.0;
            lx = mc.player.getX(); lz = mc.player.getZ();
        }
        void draw(DrawContext c, int x, int y) { text(c, String.format("Speed: %.2f b/s", bps), x, y, WHITE); }
    }

    public static class Clock extends Widget {
        public Clock() { super("Clock", "Zegar systemowy", 4, 84); }
        void draw(DrawContext c, int x, int y) {
            text(c, LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), x, y, WHITE);
        }
    }

    public static class Direction extends Widget {
        public Direction() { super("Direction", "Strona swiata, w ktora patrzysz", 4, 96); }
        void draw(DrawContext c, int x, int y) {
            text(c, "Facing: " + mc.player.getHorizontalFacing().name() + String.format(" (%.0f)", mc.player.getYaw()), x, y, WHITE);
        }
    }

    public static class PotionHUD extends Widget {
        public PotionHUD() { super("PotionHUD", "Aktywne efekty mikstur", 140, 4); }
        void draw(DrawContext c, int x, int y) {
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                int sec = e.getDuration() / 20;
                String s = e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1)
                        + String.format(" %d:%02d", sec / 60, sec % 60);
                text(c, s, x, y, PURPLE);
                y += 10;
            }
        }
    }

    public static class TotemCount extends Widget {
        public TotemCount() { super("TotemCount", "Ile masz totemow", 4, 108); }
        void draw(DrawContext c, int x, int y) {
            int n = 0;
            for (int i = 0; i < 36; i++) { ItemStack s = mc.player.getInventory().getStack(i); if (s.isOf(Items.TOTEM_OF_UNDYING)) n += s.getCount(); }
            if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) n += mc.player.getOffHandStack().getCount();
            text(c, "Totemy: " + n, x, y, n == 0 ? 0xFFFF5555 : WHITE);
        }
    }

    public static class WorldTime extends Widget {
        public WorldTime() { super("WorldTime", "Czas w swiecie gry", 4, 120); }
        void draw(DrawContext c, int x, int y) {
            long t = mc.world.getTimeOfDay() % 24000;
            text(c, "Czas: " + t + (t >= 13000 && t < 23000 ? " (noc)" : " (dzien)"), x, y, WHITE);
        }
    }

    public static class NetherCoords extends Widget {
        public NetherCoords() { super("NetherCoords", "Przelicznik koordynatow Overworld <-> Nether", 4, 132); }
        void draw(DrawContext c, int x, int y) {
            boolean nether = mc.world.getRegistryKey() == World.NETHER;
            double f = nether ? 8.0 : 0.125;
            text(c, (nether ? "Overworld: " : "Nether: ") + (int) (mc.player.getX() * f) + " " + (int) (mc.player.getZ() * f), x, y, WHITE);
        }
    }

    public static class ServerInfo extends Widget {
        public ServerInfo() { super("ServerInfo", "Adres serwera i liczba graczy", 4, 144); }
        void draw(DrawContext c, int x, int y) {
            String a = mc.getCurrentServerEntry() != null ? mc.getCurrentServerEntry().address : "singleplayer";
            int n = mc.getNetworkHandler() != null ? mc.getNetworkHandler().getPlayerList().size() : 0;
            text(c, a + " (" + n + ")", x, y, WHITE);
        }
    }

    public static class SessionTimer extends Widget {
        long start;
        public SessionTimer() { super("SessionTimer", "Czas gry od wlaczenia modulu", 4, 156); }
        @Override public void onEnable() { start = System.currentTimeMillis(); }
        void draw(DrawContext c, int x, int y) {
            long s = (System.currentTimeMillis() - start) / 1000;
            text(c, String.format("Sesja: %d:%02d:%02d", s / 3600, s / 60 % 60, s % 60), x, y, WHITE);
        }
    }

    public static class Radar extends Widget {
        final Setting.Num range = numI("Range", 50, 10, 200), size = numI("Size", 80, 40, 200);
        public Radar() { super("Radar", "Radar 2D z graczami i wrogami wokol", 200, 60); }
        void draw(DrawContext c, int x, int y) {
            int s = size.i(), half = s / 2, cx = x + half, cy = y + half;
            c.fill(x, y, x + s, y + s, 0x88000000);
            c.fill(cx - 1, cy - 1, cx + 2, cy + 2, WHITE);
            double yaw = Math.toRadians(mc.player.getYaw()), cos = Math.cos(yaw), sin = Math.sin(yaw);
            for (Entity e : mc.world.getEntities()) {
                boolean pl = e instanceof PlayerEntity && e != mc.player;
                if (!pl && !(e instanceof HostileEntity)) continue;
                double dx = e.getX() - mc.player.getX(), dz = e.getZ() - mc.player.getZ();
                double rx = -(dx * cos + dz * sin), rz = -dx * sin + dz * cos;
                int px = cx + (int) (rx / range.d() * half), py = cy - (int) (rz / range.d() * half);
                if (px < x + 1 || px > x + s - 2 || py < y + 1 || py > y + s - 2) continue;
                c.fill(px - 1, py - 1, px + 2, py + 2, pl ? 0xFFFF4D6D : 0xFFFFC857);
            }
        }
    }

    public static class Crosshair extends Mod {
        final Setting.Num gap = numI("Gap", 3, 0, 10), len = numI("Length", 5, 1, 15);
        public Crosshair() { super("Crosshair", "Wlasny fioletowy celownik (dodatkowo do vanilla)", Category.RENDER); }
        @Override public void onHud(DrawContext c) {
            int cx = c.getScaledWindowWidth() / 2, cy = c.getScaledWindowHeight() / 2, g = gap.i(), l = len.i();
            c.fill(cx - g - l, cy, cx - g, cy + 1, PURPLE);
            c.fill(cx + g + 1, cy, cx + g + l + 1, cy + 1, PURPLE);
            c.fill(cx, cy - g - l, cx + 1, cy - g, PURPLE);
            c.fill(cx, cy + g + 1, cx + 1, cy + g + l + 1, PURPLE);
        }
    }

    public static class HealthAlert extends Mod {
        final Setting.Num health = num("Health", 6, 1, 19);
        public HealthAlert() { super("HealthAlert", "Duzy napis, gdy masz malo zdrowia", Category.RENDER); }
        @Override public void onHud(DrawContext c) {
            if (mc.player.getHealth() > health.d()) return;
            String s = "!!! HP: " + (int) mc.player.getHealth() + " !!!";
            c.drawText(mc.textRenderer, s, c.getScaledWindowWidth() / 2 - mc.textRenderer.getWidth(s) / 2,
                    c.getScaledWindowHeight() / 2 - 40, 0xFFFF3B3B, true);
        }
    }

    public static class Zoom extends Mod {
        final Setting.Num fov = numI("FOV", 30, 30, 90);
        int prev = 70;
        public Zoom() { super("Zoom", "Przyblizenie (zmniejsza FOV; ustaw bind)", Category.RENDER); }
        @Override public void onEnable() { prev = mc.options.getFov().getValue(); }
        @Override public void onTick() { mc.options.getFov().setValue(fov.i()); }
        @Override public void onDisable() { mc.options.getFov().setValue(prev); }
    }

    public static class FovChanger extends Mod {
        final Setting.Num fov = numI("FOV", 100, 30, 110);
        int prev = 70;
        public FovChanger() { super("FovChanger", "Stale pole widzenia", Category.RENDER); }
        @Override public void onEnable() { prev = mc.options.getFov().getValue(); }
        @Override public void onTick() { mc.options.getFov().setValue(fov.i()); }
        @Override public void onDisable() { mc.options.getFov().setValue(prev); }
    }
}
