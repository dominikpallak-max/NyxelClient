package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.*;
import net.minecraft.item.BlockItem;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.chunk.WorldChunk;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.*;

public final class WorldModules {
    private WorldModules() {}

    public static void register() {
        ModuleManager.reg(new StashFinder());
        ModuleManager.reg(new Nuker());
        ModuleManager.reg(new Scaffold());
    }

    /** Skanuje zaladowane chunki i raportuje te z duza liczba kontenerow (stashe). */
    public static class StashFinder extends Mod {
        public static final List<String> log = new ArrayList<>();
        final Setting.Num minContainers = numI("MinContainers", 4, 1, 60);
        final Setting.Bool shulkerAlert = bool("ShulkerAlert", true);
        final Setting.Bool furnaces = bool("CountFurnaces", false);
        final Setting.Bool chat = bool("ChatAlert", true);
        final Setting.Bool save = bool("SaveToFile", true);
        private final Set<Long> seen = new HashSet<>();
        private Object lastWorld;

        public StashFinder() { super("StashFinder", "Wykrywa chunki z duza iloscia skrzyn/beczek/shulkerow", Category.WORLD); }

        @Override public void onEnable() { seen.clear(); }

        @Override public void onTick() {
            if (mc.player.age % 40 != 0) return;
            if (lastWorld != mc.world) { seen.clear(); lastWorld = mc.world; }
            int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
            int r = Math.min(mc.options.getViewDistance().getValue(), 32);
            for (int cx = pcx - r; cx <= pcx + r; cx++) {
                for (int cz = pcz - r; cz <= pcz + r; cz++) {
                    long key = ((long) cx << 32) ^ (cz & 0xFFFFFFFFL);
                    if (seen.contains(key)) continue;
                    WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                    if (chunk == null) continue;
                    int total = 0, shulkers = 0;
                    for (BlockEntity be : chunk.getBlockEntities().values()) {
                        if (be instanceof ShulkerBoxBlockEntity) { shulkers++; total++; }
                        else if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity
                                || be instanceof HopperBlockEntity || be instanceof DispenserBlockEntity
                                || (furnaces.get() && be instanceof AbstractFurnaceBlockEntity)) total++;
                    }
                    if (total >= minContainers.i() || (shulkerAlert.get() && shulkers > 0)) {
                        seen.add(key);
                        report(cx, cz, total, shulkers);
                    }
                }
            }
        }

        private void report(int cx, int cz, int total, int shulkers) {
            int x = cx * 16 + 8, z = cz * 16 + 8;
            String line = String.format("Stash? X=%d Z=%d  kontenery=%d shulkery=%d", x, z, total, shulkers);
            log.add(line);
            if (log.size() > 200) log.remove(0);
            if (chat.get()) Util.info("§d" + line);
            if (save.get()) {
                try {
                    String srv = mc.getCurrentServerEntry() != null ? mc.getCurrentServerEntry().address : "singleplayer";
                    var f = FabricLoader.getInstance().getConfigDir().resolve("nyxel/stashes.txt");
                    Files.createDirectories(f.getParent());
                    Files.writeString(f, srv + " | " + line + System.lineSeparator(),
                            StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                } catch (IOException ignored) {}
            }
        }
    }

    public static class Nuker extends Mod {
        final Setting.Num range = num("Range", 4, 1, 6);
        final Setting.Num perTick = numI("BlocksPerTick", 1, 1, 10);
        final Setting.Bool flatten = bool("OnlyAtOrAboveFeet", true);
        public Nuker() { super("Nuker", "Niszczy bloki wokol ciebie", Category.WORLD); }
        @Override public void onTick() {
            int r = (int) Math.ceil(range.d());
            BlockPos c = mc.player.getBlockPos();
            Vec3d eye = mc.player.getEyePos();
            List<BlockPos> list = new ArrayList<>();
            for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
                BlockPos p = c.add(x, y, z);
                if (flatten.get() && p.getY() < c.getY()) continue;
                if (eye.distanceTo(Vec3d.ofCenter(p)) > range.d()) continue;
                BlockState s = mc.world.getBlockState(p);
                if (s.isAir() || !s.getFluidState().isEmpty() || s.getHardness(mc.world, p) < 0) continue;
                list.add(p);
            }
            list.sort(Comparator.comparingDouble(p -> eye.squaredDistanceTo(Vec3d.ofCenter(p))));
            int n = 0;
            for (BlockPos p : list) {
                if (n++ >= perTick.i()) break;
                if (mc.player.isCreative()) mc.interactionManager.attackBlock(p, Direction.UP);
                else mc.interactionManager.updateBlockBreakingProgress(p, Direction.UP);
                mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
            }
        }
    }

    public static class Scaffold extends Mod {
        final Setting.Bool rotate = bool("Rotate", false), tower = bool("Tower", true);
        public Scaffold() { super("Scaffold", "Stawia bloki pod toba podczas chodzenia", Category.WORLD); }
        @Override public void onTick() {
            int slot = Util.findHotbar(s -> s.getItem() instanceof BlockItem);
            if (slot < 0) return;
            BlockPos below = mc.player.getBlockPos().down();
            if (Util.place(below, slot, rotate.get()) && tower.get() && mc.options.jumpKey.isPressed() && !Util.moving()) {
                Vec3d v = mc.player.getVelocity();
                mc.player.setVelocity(v.x, 0.42, v.z);
            }
        }
    }
}
