package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.slot.SlotActionType;

import java.util.*;

public final class MiscPlus {
    private MiscPlus() {}

    public static void register() {
        ModuleManager.reg(new VisualRange());
        ModuleManager.reg(new DeathCoords());
        ModuleManager.reg(new AutoLogin());
        ModuleManager.reg(new AutoReply());
        ModuleManager.reg(new AutoTPA());
        ModuleManager.reg(new Twerk());
        ModuleManager.reg(new Spinbot());
        ModuleManager.reg(new Derp());
        ModuleManager.reg(new ShareCoords());
        ModuleManager.reg(new DropAll());
        ModuleManager.reg(new AutoCommand());
        ModuleManager.reg(new CycleHotbar());
    }

    public static class VisualRange extends Mod {
        private final Set<UUID> known = new HashSet<>();
        public VisualRange() { super("VisualRange", "Alert na czacie, gdy gracz wejdzie/wyjdzie z zasiegu renderu", Category.MISC); }
        @Override public void onEnable() { known.clear(); }
        @Override public void onTick() {
            if (mc.player.age % 10 != 0) return;
            Set<UUID> now = new HashSet<>();
            for (PlayerEntity p : mc.world.getPlayers()) {
                if (p == mc.player) continue;
                now.add(p.getUuid());
                if (known.add(p.getUuid()))
                    Util.info("§a+ §f" + p.getName().getString() + " §7(" + (int) mc.player.distanceTo(p) + "m)");
            }
            known.removeIf(u -> {
                if (now.contains(u)) return false;
                Util.info("§c- §fgracz opuscil zasieg");
                return true;
            });
        }
    }

    public static class DeathCoords extends Mod {
        boolean was;
        public DeathCoords() { super("DeathCoords", "Zapisuje na czacie miejsce smierci", Category.MISC); }
        @Override public void onTick() {
            boolean dead = mc.player.isDead();
            if (dead && !was) Util.info(String.format("§cSmierc na §fX=%.0f Y=%.0f Z=%.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ()));
            was = dead;
        }
    }

    public static class AutoLogin extends Mod {
        final Setting.Str command = str("Command", "/login haslo");
        final Setting.Num delay = numI("DelayTicks", 60, 20, 400);
        public AutoLogin() { super("AutoLogin", "Wysyla komende logowania po wejsciu na serwer (.set AutoLogin Command /login x)", Category.MISC); }
        @Override public void onTick() { if (mc.player.age == delay.i()) Util.say(command.get()); }
    }

    public static class AutoReply extends Mod {
        final Setting.Str reply = str("Reply", "Nie ma mnie, wroce pozniej");
        final Setting.Num cooldown = numI("CooldownSec", 20, 5, 300);
        long last;
        public AutoReply() {
            super("AutoReply", "Odpisuje, gdy ktos napisze twoj nick (wiadomosci systemowe/plugin chat)", Category.MISC);
            ClientReceiveMessageEvents.GAME.register((msg, overlay) -> {
                if (!enabled || overlay || mc.player == null) return;
                String s = msg.getString();
                if (s.contains(reply.get()) || !s.contains(mc.player.getName().getString())) return;
                long now = System.currentTimeMillis();
                if (now - last < cooldown.i() * 1000L) return;
                last = now;
                Util.say(reply.get());
            });
        }
    }

    public static class AutoTPA extends Mod {
        final Setting.Bool onlyFriends = bool("OnlyFriends", true);
        long last;
        public AutoTPA() {
            super("AutoTPA", "Akceptuje prosby o teleport (domyslnie tylko od przyjaciol)", Category.MISC);
            ClientReceiveMessageEvents.GAME.register((msg, overlay) -> {
                if (!enabled || overlay || mc.player == null) return;
                String s = msg.getString(), l = s.toLowerCase();
                if (!(l.contains("tpa") || l.contains("teleport"))) return;
                if (onlyFriends.get() && Config.friends.stream().noneMatch(s::contains)) return;
                long now = System.currentTimeMillis();
                if (now - last < 3000) return;
                last = now;
                Util.say("/tpaccept");
            });
        }
    }

    public static class Twerk extends Mod {
        final Setting.Num speed = numI("Period", 4, 2, 20);
        public Twerk() { super("Twerk", "Szybko przysiadasz i wstajesz", Category.MISC); }
        @Override public void onTick() { mc.options.sneakKey.setPressed(mc.player.age % speed.i() < speed.i() / 2); }
        @Override public void onDisable() { mc.options.sneakKey.setPressed(false); }
    }

    public static class Spinbot extends Mod {
        final Setting.Num speed = num("Speed", 30, 5, 90);
        final Setting.Bool pitch = bool("PitchDown", false);
        public Spinbot() { super("Spinbot", "Kreci glowa (inni widza twoj obrot)", Category.MISC); }
        @Override public void onTick() {
            mc.player.setYaw(mc.player.getYaw() + speed.f());
            if (pitch.get()) mc.player.setPitch(90f);
        }
    }

    public static class Derp extends Mod {
        final Random rnd = new Random();
        public Derp() { super("Derp", "Losowe ruchy glowa", Category.MISC); }
        @Override public void onTick() {
            mc.player.setYaw(rnd.nextFloat() * 360f);
            mc.player.setPitch((rnd.nextFloat() - 0.5f) * 180f);
        }
    }

    public static class ShareCoords extends OneShot {
        public ShareCoords() { super("ShareCoords", "Wysyla swoje koordynaty na czat", Category.MISC); }
        @Override protected void run() {
            Util.say(String.format("Moje koordy: %.0f %.0f %.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ()));
        }
    }

    public static class DropAll extends OneShot {
        public DropAll() { super("DropAll", "Wyrzuca caly ekwipunek (uwaga!)", Category.MISC); }
        @Override protected void run() {
            for (int i = 0; i < 36; i++)
                if (!mc.player.getInventory().getStack(i).isEmpty())
                    mc.interactionManager.clickSlot(0, Util.screenSlot(i), 1, SlotActionType.THROW, mc.player);
        }
    }

    public static class AutoCommand extends Mod {
        final Setting.Str command = str("Command", "/sethome");
        final Setting.Num delay = numI("DelayTicks", 600, 20, 12000);
        public AutoCommand() { super("AutoCommand", "Wysyla komende co jakis czas (.set AutoCommand Command /x)", Category.MISC); }
        @Override public void onTick() { if (mc.player.age % delay.i() == 0) Util.say(command.get()); }
    }

    public static class CycleHotbar extends Mod {
        final Setting.Num delay = numI("DelayTicks", 10, 1, 100);
        public CycleHotbar() { super("CycleHotbar", "Przelacza sloty hotbara po kolei", Category.MISC); }
        @Override public void onTick() {
            if (mc.player.age % delay.i() == 0)
                mc.player.getInventory().setSelectedSlot((mc.player.getInventory().getSelectedSlot() + 1) % 9);
        }
    }
}
