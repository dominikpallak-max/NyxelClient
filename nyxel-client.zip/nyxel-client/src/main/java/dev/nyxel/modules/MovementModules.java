package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec3d;

public final class MovementModules {
    private MovementModules() {}

    public static void register() {
        ModuleManager.reg(new Sprint());
        ModuleManager.reg(new Flight());
        ModuleManager.reg(new Speed());
        ModuleManager.reg(new Step());
        ModuleManager.reg(new NoFall());
        ModuleManager.reg(new Spider());
        ModuleManager.reg(new AutoJump());
        ModuleManager.reg(new Parkour());
        ModuleManager.reg(new Glide());
        ModuleManager.reg(new AirJump());
        ModuleManager.reg(new AntiVoid());
        ModuleManager.reg(new FastClimb());
    }

    public static class Sprint extends Mod {
        public Sprint() { super("Sprint", "Zawsze biegniesz do przodu", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.options.forwardKey.isPressed() && !mc.player.horizontalCollision
                    && !mc.player.isSneaking() && mc.player.getHungerManager().getFoodLevel() > 6)
                mc.player.setSprinting(true);
        }
    }

    public static class Flight extends Mod {
        final Setting.Mode mode = mode("Mode", "Velocity", "Velocity", "Abilities");
        final Setting.Num speed = num("Speed", 1.0, 0.1, 5);
        public Flight() { super("Flight", "Latanie", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mode.is("Abilities")) {
                mc.player.getAbilities().allowFlying = true;
                mc.player.getAbilities().flying = true;
                mc.player.getAbilities().setFlySpeed(speed.f() * 0.05f);
            } else {
                double vy = mc.options.jumpKey.isPressed() ? speed.d() * 0.5 : mc.options.sneakKey.isPressed() ? -speed.d() * 0.5 : 0;
                mc.player.setVelocity(0, vy, 0);
                Util.setHorizontalSpeed(speed.d() * 0.6);
            }
        }
        @Override public void onDisable() {
            if (mc.player != null && !mc.player.isCreative() && !mc.player.isSpectator()) {
                mc.player.getAbilities().allowFlying = false;
                mc.player.getAbilities().flying = false;
                mc.player.getAbilities().setFlySpeed(0.05f);
            }
        }
    }

    public static class Speed extends Mod {
        final Setting.Num speed = num("Speed", 1.4, 0.5, 4);
        final Setting.Bool onlyGround = bool("OnlyOnGround", false);
        public Speed() { super("Speed", "Szybszy ruch poziomy", Category.MOVEMENT); }
        @Override public void onTick() {
            if (!Util.moving() || (onlyGround.get() && !mc.player.isOnGround())) return;
            Util.setHorizontalSpeed(0.2873 * speed.d());
        }
    }

    public static class Step extends Mod {
        final Setting.Num height = num("Height", 1.0, 0.6, 2.5);
        public Step() { super("Step", "Wchodzisz na wyzsze bloki bez skakania", Category.MOVEMENT); }
        @Override public void onTick() {
            EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
            if (a != null) a.setBaseValue(height.d());
        }
        @Override public void onDisable() {
            if (mc.player == null) return;
            EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
            if (a != null) a.setBaseValue(0.6);
        }
    }

    public static class NoFall extends Mod {
        public NoFall() { super("NoFall", "Brak obrazen od upadku", Category.MOVEMENT); }
        @Override public void onTick() {
            if (!mc.player.isOnGround() && mc.player.getVelocity().y < -0.5 && !mc.player.isGliding())
                mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, false));
        }
    }

    public static class Spider extends Mod {
        public Spider() { super("Spider", "Wspinasz sie po scianach", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.player.horizontalCollision && Util.moving()) {
                Vec3d v = mc.player.getVelocity();
                mc.player.setVelocity(v.x, 0.2, v.z);
            }
        }
    }

    public static class AutoJump extends Mod {
        public AutoJump() { super("AutoJump", "Skacze automatycznie podczas ruchu", Category.MOVEMENT); }
        @Override public void onTick() { if (mc.player.isOnGround() && Util.moving()) mc.player.jump(); }
    }

    public static class Parkour extends Mod {
        public Parkour() { super("Parkour", "Skacze na krawedzi bloku", Category.MOVEMENT); }
        @Override public void onTick() {
            if (!mc.player.isOnGround() || mc.player.isSneaking() || mc.options.jumpKey.isPressed()) return;
            if (mc.world.isSpaceEmpty(mc.player, mc.player.getBoundingBox().offset(0, -0.5, 0).expand(-0.001, 0, -0.001)))
                mc.player.jump();
        }
    }

    public static class Glide extends Mod {
        final Setting.Num fall = num("FallSpeed", 0.1, 0.01, 0.5);
        public Glide() { super("Glide", "Powolne opadanie", Category.MOVEMENT); }
        @Override public void onTick() {
            Vec3d v = mc.player.getVelocity();
            if (!mc.player.isOnGround() && v.y < -fall.d()) mc.player.setVelocity(v.x, -fall.d(), v.z);
        }
    }

    public static class AirJump extends Mod {
        boolean prev;
        public AirJump() { super("AirJump", "Skok w powietrzu", Category.MOVEMENT); }
        @Override public void onTick() {
            boolean j = mc.options.jumpKey.isPressed();
            if (j && !prev && !mc.player.isOnGround()) mc.player.jump();
            prev = j;
        }
    }

    public static class AntiVoid extends Mod {
        public AntiVoid() { super("AntiVoid", "Wyrzuca w gore przed wpadnieciem w pustke", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.player.getY() < mc.world.getBottomY() + 1) {
                Vec3d v = mc.player.getVelocity();
                mc.player.setVelocity(v.x, 1.0, v.z);
            }
        }
    }

    public static class FastClimb extends Mod {
        public FastClimb() { super("FastClimb", "Szybsze wspinanie po drabinach", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.player.isClimbing() && Util.moving()) {
                Vec3d v = mc.player.getVelocity();
                mc.player.setVelocity(v.x, 0.25, v.z);
            }
        }
    }
}
