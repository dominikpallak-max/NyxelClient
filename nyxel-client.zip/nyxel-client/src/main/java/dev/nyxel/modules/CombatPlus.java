package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

public final class CombatPlus {
    private CombatPlus() {}

    public static void register() {
        ModuleManager.reg(new AutoClicker());
        ModuleManager.reg(new AutoGapple());
        ModuleManager.reg(new AutoShield());
        ModuleManager.reg(new AutoWeapon());
        ModuleManager.reg(new MobAura());
        ModuleManager.reg(new JumpCrits());
        ModuleManager.reg(new PearlThrow());
    }

    public static class AutoClicker extends Mod {
        final Setting.Num cps = numI("CPS", 10, 1, 20);
        double acc;
        public AutoClicker() { super("AutoClicker", "Klika za ciebie na celu pod celownikiem (trzymaj LPM)", Category.COMBAT); }
        @Override public void onTick() {
            if (!mc.options.attackKey.isPressed() || mc.currentScreen != null) return;
            acc += cps.d() / 20.0;
            if (acc < 1) return;
            acc -= 1;
            if (mc.crosshairTarget instanceof EntityHitResult r) {
                mc.interactionManager.attackEntity(mc.player, r.getEntity());
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        }
    }

    public static class AutoGapple extends Mod {
        final Setting.Num health = num("Health", 12, 1, 20);
        boolean eating; int prev, ticks;
        public AutoGapple() { super("AutoGapple", "Je zlote jablko, gdy zdrowie spadnie", Category.COMBAT); }
        void stop() {
            mc.options.useKey.setPressed(false);
            if (eating) mc.player.getInventory().setSelectedSlot(prev);
            eating = false;
        }
        @Override public void onDisable() { if (mc.player != null) stop(); }
        @Override public void onTick() {
            if (!eating) {
                if (mc.player.getHealth() + mc.player.getAbsorptionAmount() > health.d()) return;
                int s = Util.findHotbar(i -> i.isOf(Items.GOLDEN_APPLE) || i.isOf(Items.ENCHANTED_GOLDEN_APPLE));
                if (s < 0) return;
                prev = mc.player.getInventory().getSelectedSlot();
                mc.player.getInventory().setSelectedSlot(s);
                mc.options.useKey.setPressed(true);
                eating = true; ticks = 0;
            } else if (++ticks > 40 || (ticks > 3 && !mc.player.isUsingItem())) stop();
        }
    }

    public static class AutoShield extends Mod {
        final Setting.Num range = num("Range", 4, 1, 8);
        boolean held;
        public AutoShield() { super("AutoShield", "Podnosi tarcze, gdy gracz jest blisko", Category.COMBAT); }
        @Override public void onDisable() { if (held) mc.options.useKey.setPressed(false); held = false; }
        @Override public void onTick() {
            boolean has = mc.player.getOffHandStack().isOf(Items.SHIELD) || mc.player.getMainHandStack().isOf(Items.SHIELD);
            PlayerEntity p = has ? Util.nearestPlayer(range.d()) : null;
            if (p != null) { mc.options.useKey.setPressed(true); held = true; }
            else if (held) { mc.options.useKey.setPressed(false); held = false; }
        }
    }

    public static class AutoWeapon extends Mod {
        public AutoWeapon() { super("AutoWeapon", "Wybiera miecz/topor, gdy bijesz", Category.COMBAT); }
        static boolean weapon(ItemStack s) { return s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES); }
        @Override public void onTick() {
            if (!mc.options.attackKey.isPressed() || !(mc.crosshairTarget instanceof EntityHitResult)) return;
            if (weapon(mc.player.getMainHandStack())) return;
            int s = Util.findHotbar(AutoWeapon::weapon);
            if (s >= 0) mc.player.getInventory().setSelectedSlot(s);
        }
    }

    public static class MobAura extends Mod {
        final Setting.Num range = num("Range", 4.2, 1, 6), cooldown = num("Cooldown", 0.92, 0, 1);
        final Setting.Bool rotate = bool("Rotate", true);
        public MobAura() { super("MobAura", "Atakuje tylko wrogie moby", Category.COMBAT); }
        @Override public void onTick() {
            var l = Util.targets(range.d(), false, true, false, false, false);
            if (l.isEmpty()) return;
            LivingEntity t = l.get(0);
            if (rotate.get()) Util.lookAt(t.getBoundingBox().getCenter());
            if (mc.player.getAttackCooldownProgress(0f) < cooldown.f()) return;
            mc.interactionManager.attackEntity(mc.player, t);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }

    public static class JumpCrits extends Mod {
        public JumpCrits() { super("JumpCrits", "Skacze przy biciu, zeby trafiac krytyki", Category.COMBAT); }
        @Override public void onTick() {
            if (mc.options.attackKey.isPressed() && mc.crosshairTarget instanceof EntityHitResult
                    && mc.player.isOnGround() && !mc.options.jumpKey.isPressed()) mc.player.jump();
        }
    }

    public static class PearlThrow extends OneShot {
        public PearlThrow() { super("PearlThrow", "Rzuca perle z hotbara (uzyj na bindzie)", Category.COMBAT); }
        @Override protected void run() {
            int s = Util.findHotbar(i -> i.isOf(Items.ENDER_PEARL));
            if (s < 0) Util.info("§cBrak perly w hotbarze"); else Util.useItem(s);
        }
    }
}
