package dev.nyxel.core;

import dev.nyxel.NyxelClient;
import dev.nyxel.gui.ClickGuiScreen;
import dev.nyxel.modules.WorldModules;
import dev.nyxel.util.Util;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;

import java.util.Arrays;

/** Komendy na czacie z prefiksem ".". */
public final class Commands {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private Commands() {}

    public static void register() {
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> {
            if (!msg.startsWith(".") || msg.startsWith("..")) return true;
            try { run(msg.substring(1).trim().split("\\s+")); }
            catch (Exception e) { Util.info("§cBlad komendy: " + e.getMessage()); }
            return false;
        });
    }

    public static int keyFromName(String n) {
        if (n.equalsIgnoreCase("none")) return -1;
        try { return InputUtil.fromTranslationKey("key.keyboard." + n.toLowerCase().replace(' ', '.')).getCode(); }
        catch (Exception e) { return -2; }
    }

    private static void run(String[] a) {
        String c = a[0].toLowerCase();
        switch (c) {
            case "help" -> {
                Util.info("§d.toggle <modul> §7| §d.bind <modul> <klawisz|none> §7| §d.set <modul> <opcja> <wartosc>");
                Util.info("§d.config save|load|list <nazwa> §7| §d.friend add|remove|list <nick> §7| §d.modules §7| §d.stashes §7| §d.panic §7| §d.gui §7| §d.guikey <klawisz>");
            }
            case "gui" -> mc.send(() -> mc.setScreen(new ClickGuiScreen()));
            case "guikey" -> {
                int k = keyFromName(a[1]);
                if (k < 0) { Util.info("§cNieznany klawisz"); return; }
                ModuleManager.guiKey = k; Util.info("Klawisz GUI ustawiony: " + a[1]);
            }
            case "panic" -> { ModuleManager.panic(); Util.info("Wszystkie moduly wylaczone"); }
            case "modules" -> {
                StringBuilder sb = new StringBuilder();
                for (Category cat : Category.values()) {
                    sb.append("\n§5").append(cat.label).append("§7: ");
                    for (Mod m : ModuleManager.in(cat)) sb.append(m.enabled ? "§a" : "§f").append(m.name).append("§7, ");
                }
                Util.info(sb.toString());
            }
            case "toggle", "t" -> { Mod m = need(a[1]); m.toggle(); }
            case "bind" -> {
                Mod m = need(a[1]);
                int k = keyFromName(a[2]);
                if (k == -2) { Util.info("§cNieznany klawisz: " + a[2]); return; }
                m.bind = k; Util.info(m.name + " bind = " + a[2]);
            }
            case "set" -> {
                Mod m = need(a[1]);
                Setting<?> s = m.setting(a[2]);
                if (s == null) { Util.info("§cBrak opcji. Dostepne: " + m.settings.stream().map(x -> x.name).toList()); return; }
                String v = String.join(" ", Arrays.copyOfRange(a, 3, a.length));
                Util.info(s.parse(v) ? m.name + "." + s.name + " = " + s.display() : "§cZla wartosc");
            }
            case "config", "cfg" -> {
                String sub = a.length > 1 ? a[1].toLowerCase() : "list";
                String name = a.length > 2 ? a[2] : "default";
                switch (sub) {
                    case "save" -> Util.info(Config.save(name) ? "Zapisano config §d" + name : "§cNie udalo sie zapisac");
                    case "load" -> Util.info(Config.load(name, true) ? "Wczytano config §d" + name : "§cBrak configu " + name);
                    default -> Util.info("Configi: §d" + Config.list());
                }
            }
            case "friend", "friends" -> {
                String sub = a.length > 1 ? a[1].toLowerCase() : "list";
                switch (sub) {
                    case "add" -> { Config.friends.add(a[2]); Util.info("Dodano przyjaciela " + a[2]); }
                    case "remove", "del" -> { Config.friends.remove(a[2]); Util.info("Usunieto " + a[2]); }
                    default -> Util.info("Przyjaciele: §d" + Config.friends);
                }
            }
            case "stashes" -> {
                if (WorldModules.StashFinder.log.isEmpty()) Util.info("Brak znalezionych stashy");
                else WorldModules.StashFinder.log.forEach(s -> Util.info("§d" + s));
            }
            default -> Util.info("§cNieznana komenda. Wpisz §d.help");
        }
    }

    private static Mod need(String n) {
        Mod m = ModuleManager.get(n);
        if (m == null) throw new IllegalArgumentException("nie ma modulu " + n);
        return m;
    }
}
