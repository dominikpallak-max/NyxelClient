package dev.nyxel.core;

import dev.nyxel.NyxelClient;

/** Modul jednorazowy: kazde "wlaczenie" (klik/bind/.toggle) wykonuje akcje i modul zostaje wylaczony. */
public abstract class OneShot extends Mod {
    protected OneShot(String name, String description, Category category) { super(name, description, category); }

    protected abstract void run();

    @Override public void setEnabled(boolean v) {
        if (!v || mc.player == null || mc.world == null) return;
        try { run(); } catch (Throwable t) { NyxelClient.LOG.error("OneShot {}", name, t); }
    }
}
