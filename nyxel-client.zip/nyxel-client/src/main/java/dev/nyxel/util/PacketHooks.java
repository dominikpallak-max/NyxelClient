package dev.nyxel.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.Packet;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Predicate;

/** Wspolny hak na pakiety wychodzace. Filtr zwracajacy true = pakiet przechwycony (nie idzie na serwer). */
public final class PacketHooks {
    public static final List<Predicate<Packet<?>>> FILTERS = new CopyOnWriteArrayList<>();
    private static volatile boolean bypass;

    private PacketHooks() {}

    /** Wolane z mixina. true = anuluj wysylke. */
    public static boolean intercept(Packet<?> p) {
        if (bypass) return false;
        for (Predicate<Packet<?>> f : FILTERS) if (f.test(p)) return true;
        return false;
    }

    /** Wysyla pakiet z pominieciem filtrow (np. przy zwalnianiu kolejki). */
    public static void sendRaw(Packet<?> p) {
        var h = MinecraftClient.getInstance().getNetworkHandler();
        if (h == null) return;
        bypass = true;
        try { h.sendPacket(p); } finally { bypass = false; }
    }
}
