package dev.nyxel.util;

import dev.nyxel.core.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

public final class Util {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private Util() {}

    public static void info(String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("§5[Nyxel] §f" + s), false);
    }

    public static boolean isFriend(PlayerEntity p) { return Config.friends.contains(p.getName().getString()); }

    public static int findHotbar(Predicate<ItemStack> p) {
        for (int i = 0; i < 9; i++) if (p.test(mc.player.getInventory().getStack(i))) return i;
        return -1;
    }

    /** Index w ekwipunku (0-8 hotbar, 9-35 glowny) -> numer slotu w playerScreenHandler. */
    public static int screenSlot(int invIndex) { return invIndex < 9 ? invIndex + 36 : invIndex; }

    public static void lookAt(Vec3d t) {
        Vec3d e = mc.player.getEyePos();
        double dx = t.x - e.x, dy = t.y - e.y, dz = t.z - e.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        mc.player.setYaw((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
        mc.player.setPitch((float) -Math.toDegrees(Math.atan2(dy, h)));
    }

    public static List<LivingEntity> targets(double range, boolean players, boolean hostile, boolean animals,
                                             boolean walls, boolean byHealth) {
        List<LivingEntity> out = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == mc.player || !le.isAlive() || le.isSpectator()) continue;
            if (mc.player.distanceTo(le) > range) continue;
            boolean ok = (e instanceof PlayerEntity p && players && !isFriend(p))
                    || (e instanceof HostileEntity && hostile)
                    || (e instanceof AnimalEntity && animals);
            if (!ok) continue;
            if (!walls && !mc.player.canSee(le)) continue;
            out.add(le);
        }
        out.sort(byHealth ? Comparator.comparingDouble(LivingEntity::getHealth)
                : Comparator.comparingDouble(x -> mc.player.distanceTo(x)));
        return out;
    }

    public static PlayerEntity nearestPlayer(double range) {
        PlayerEntity best = null; double bd = range;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive() || p.isSpectator() || isFriend(p)) continue;
            double d = mc.player.distanceTo(p);
            if (d <= bd) { bd = d; best = p; }
        }
        return best;
    }

    /** Stawia blok z podanego slotu hotbara na pos, opierajac sie o sasiedni blok. */
    public static boolean place(BlockPos pos, int slot, boolean rotate) {
        if (!mc.world.getBlockState(pos).isReplaceable()) return false;
        if (mc.player.getEyePos().distanceTo(Vec3d.ofCenter(pos)) > 5.0) return false;
        for (Direction d : Direction.values()) {
            BlockPos n = pos.offset(d);
            if (mc.world.getBlockState(n).isReplaceable()) continue;
            Direction face = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(n).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            int prev = mc.player.getInventory().getSelectedSlot();
            mc.player.getInventory().setSelectedSlot(slot);
            if (rotate) lookAt(hit);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hit, face, n, false));
            mc.player.swingHand(Hand.MAIN_HAND);
            mc.player.getInventory().setSelectedSlot(prev);
            return true;
        }
        return false;
    }

    public static boolean moving() {
        return mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed()
                || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed();
    }

    /** Ustawia predkosc pozioma wg klawiszy WASD i yaw, zachowujac Y. */
    public static void setHorizontalSpeed(double speed) {
        float f = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
        float s = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
        Vec3d v = mc.player.getVelocity();
        if (f == 0 && s == 0) { mc.player.setVelocity(0, v.y, 0); return; }
        double len = Math.sqrt(f * f + s * s);
        f /= len; s /= len;
        double yaw = Math.toRadians(mc.player.getYaw());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        mc.player.setVelocity((-sin * f + cos * s) * speed, v.y, (cos * f + sin * s) * speed);
    }

    /** Kopie/niszczenie bloku (creative = natychmiast, survival = postep co tick). */
    public static void mine(BlockPos p) {
        if (mc.player.isCreative()) mc.interactionManager.attackBlock(p, Direction.UP);
        else mc.interactionManager.updateBlockBreakingProgress(p, Direction.UP);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    /** Uzywa przedmiotu z danego slotu hotbara (perla, rakieta...) i wraca na poprzedni slot. */
    public static void useItem(int slot) {
        int prev = mc.player.getInventory().getSelectedSlot();
        mc.player.getInventory().setSelectedSlot(slot);
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.player.getInventory().setSelectedSlot(prev);
    }

    public static void say(String m) {
        if (mc.getNetworkHandler() == null) return;
        if (m.startsWith("/")) mc.getNetworkHandler().sendChatCommand(m.substring(1));
        else mc.getNetworkHandler().sendChatMessage(m);
    }
}
