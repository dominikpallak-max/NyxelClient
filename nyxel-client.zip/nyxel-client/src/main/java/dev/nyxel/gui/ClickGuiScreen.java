package dev.nyxel.gui;

import dev.nyxel.NyxelClient;
import dev.nyxel.core.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.EnumMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * ClickGUI w stylu Meteora: kolumna na kategorie.
 * LPM na module = wlacz/wylacz, PPM = rozwin ustawienia. PPM na naglowku = zwin kolumne.
 * Wejscie jest odczytywane przez GLFW (niezalezne od zmian API ekranow).
 */
public class ClickGuiScreen extends Screen {
    private static final int W = 122, ROW = 13, HEAD = 16;
    private static final int C_HEAD = 0xFF7B2FF7, C_BG = 0xE6140C22, C_ON = 0xFF5B2A9E, C_SET = 0xF01B1030,
            C_TEXT = 0xFFFFFFFF, C_DIM = 0xFFB8B0CC, C_ACC = 0xFFC77DFF, C_HOV = 0x28FFFFFF;

    private static final Map<Category, int[]> POS = new EnumMap<>(Category.class); // x, y, zwiniete
    private static final Set<Mod> EXPANDED = new HashSet<>();
    private static int scroll;

    private boolean lDown, lPrev, rDown, rPrev;
    private final boolean[] keyPrev = new boolean[400];
    private Mod binding;
    private Setting.Num dragNum;
    private Category dragWin;
    private int dragDX, dragDY;
    private Mod hovered;

    public ClickGuiScreen() { super(Text.literal(NyxelClient.NAME)); }

    @Override protected void init() {
        if (!POS.isEmpty()) return;
        int i = 0;
        for (Category c : Category.values()) { POS.put(c, new int[]{12 + i * (W + 8), 24, 0}); i++; }
    }

    @Override public boolean shouldPause() { return false; }
    @Override public boolean shouldCloseOnEsc() { return binding == null; }

    @Override public boolean mouseScrolled(double x, double y, double h, double v) {
        scroll = Math.max(-700, Math.min(0, scroll + (int) (v * 16)));
        return true;
    }

    private static boolean in(int mx, int my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        long h = client.getWindow().getHandle();
        lPrev = lDown; rPrev = rDown;
        lDown = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        rDown = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean lc = lDown && !lPrev, rc = rDown && !rPrev;
        if (!lDown) { dragNum = null; dragWin = null; }
        pollKeys(h);

        ctx.fill(0, 0, width, height, 0x88000000);
        hovered = null;

        for (Category cat : Category.values()) {
            int[] p = POS.get(cat);
            if (dragWin == cat && lDown) { p[0] = mx - dragDX; p[1] = my - dragDY - scroll; }
            int x = p[0], y = p[1] + scroll;
            ctx.fill(x, y, x + W, y + HEAD, C_HEAD);
            ctx.drawText(textRenderer, cat.label, x + 6, y + 4, C_TEXT, true);
            ctx.drawText(textRenderer, p[2] == 1 ? "+" : "-", x + W - 10, y + 4, C_TEXT, false);
            if (in(mx, my, x, y, W, HEAD)) {
                if (lc && dragWin == null) { dragWin = cat; dragDX = mx - x; dragDY = my - y; }
                if (rc) p[2] ^= 1;
            }
            int cy = y + HEAD;
            if (p[2] == 1) continue;
            for (Mod m : ModuleManager.in(cat)) {
                boolean hov = in(mx, my, x, cy, W, ROW);
                ctx.fill(x, cy, x + W, cy + ROW, m.enabled ? C_ON : C_BG);
                if (hov) ctx.fill(x, cy, x + W, cy + ROW, C_HOV);
                ctx.drawText(textRenderer, m.name, x + 6, cy + 3, m.enabled ? C_TEXT : C_DIM, false);
                {
                    ctx.drawText(textRenderer, EXPANDED.contains(m) ? "v" : ">", x + W - 10, cy + 3, C_DIM, false);
                }
                if (hov && dragWin == null) {
                    hovered = m;
                    if (lc) m.toggle();
                    if (rc) { if (!EXPANDED.remove(m)) EXPANDED.add(m); }
                }
                cy += ROW;
                if (EXPANDED.contains(m)) cy = drawSettings(ctx, m, x, cy, mx, my, lc, rc);
            }
        }

        ctx.drawText(textRenderer, NyxelClient.NAME + " v" + NyxelClient.VERSION
                + "  |  LPM: wlacz  PPM: ustawienia  |  .help na czacie", 6, height - 12, C_DIM, true);

        if (hovered != null) {
            String d = hovered.description;
            int w = textRenderer.getWidth(d) + 8;
            int tx = Math.min(mx + 10, width - w - 2), ty = my + 12;
            ctx.fill(tx, ty, tx + w, ty + 14, 0xF0000000);
            ctx.drawText(textRenderer, d, tx + 4, ty + 3, C_ACC, false);
        }
    }

    private int drawSettings(DrawContext ctx, Mod m, int x, int cy, int mx, int my, boolean lc, boolean rc) {
        for (Setting<?> s : m.settings) {
            boolean hov = in(mx, my, x, cy, W, ROW);
            ctx.fill(x, cy, x + W, cy + ROW, C_SET);
            if (s instanceof Setting.Bool b) {
                ctx.drawText(textRenderer, "  " + s.name, x + 6, cy + 3, C_TEXT, false);
                ctx.fill(x + W - 18, cy + 3, x + W - 8, cy + ROW - 3, b.get() ? C_ACC : 0xFF3A3050);
                if (hov && lc) b.toggle();
            } else if (s instanceof Setting.Num n) {
                int fw = (int) (W * n.ratio());
                ctx.fill(x, cy, x + fw, cy + ROW, 0x886B2FD0);
                ctx.drawText(textRenderer, "  " + s.name + ": " + n.display(), x + 6, cy + 3, C_TEXT, false);
                if (hov && lc) dragNum = n;
                if (dragNum == n && lDown) n.setRatio((mx - x) / (double) W);
            } else if (s instanceof Setting.Mode md) {
                ctx.drawText(textRenderer, "  " + s.name + ": ", x + 6, cy + 3, C_TEXT, false);
                ctx.drawText(textRenderer, md.get(), x + 6 + textRenderer.getWidth("  " + s.name + ": "), cy + 3, C_ACC, false);
                if (hov && lc) md.cycle(1);
                if (hov && rc) md.cycle(-1);
            } else {
                ctx.drawText(textRenderer, "  " + s.name + ": " + s.display(), x + 6, cy + 3, C_DIM, false);
            }
            cy += ROW;
        }
        // bind
        boolean hov = in(mx, my, x, cy, W, ROW);
        ctx.fill(x, cy, x + W, cy + ROW, C_SET);
        String bt = binding == m ? "<nacisnij klawisz, ESC = brak>" : "  Bind: " + keyName(m.bind);
        ctx.drawText(textRenderer, bt, x + 6, cy + 3, binding == m ? C_ACC : C_TEXT, false);
        if (hov && lc) binding = m;
        return cy + ROW;
    }

    private void pollKeys(long h) {
        for (int k = 32; k < keyPrev.length; k++) {
            boolean d = GLFW.glfwGetKey(h, k) == GLFW.GLFW_PRESS;
            if (d && !keyPrev[k] && binding != null) {
                binding.bind = k == GLFW.GLFW_KEY_ESCAPE ? -1 : k;
                binding = null;
            }
            keyPrev[k] = d;
        }
    }

    public static String keyName(int k) {
        if (k < 0) return "brak";
        String n = GLFW.glfwGetKeyName(k, 0);
        if (n != null) return n.toUpperCase();
        return switch (k) {
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCTRL";
            case GLFW.GLFW_KEY_LEFT_ALT -> "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "RALT";
            case GLFW.GLFW_KEY_TAB -> "TAB";
            case GLFW.GLFW_KEY_ENTER -> "ENTER";
            case GLFW.GLFW_KEY_UP -> "UP";
            case GLFW.GLFW_KEY_DOWN -> "DOWN";
            case GLFW.GLFW_KEY_LEFT -> "LEFT";
            case GLFW.GLFW_KEY_RIGHT -> "RIGHT";
            default -> (k >= GLFW.GLFW_KEY_F1 && k <= GLFW.GLFW_KEY_F12) ? "F" + (k - GLFW.GLFW_KEY_F1 + 1) : "KEY" + k;
        };
    }
}
