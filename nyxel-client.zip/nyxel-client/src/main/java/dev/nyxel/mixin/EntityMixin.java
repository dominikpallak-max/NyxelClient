package dev.nyxel.mixin;

import dev.nyxel.modules.RenderModules;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** ESP: wymusza efekt glow (kontur widoczny przez sciany) na wybranych encjach. */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "isGlowing", at = @At("RETURN"), cancellable = true)
    private void nyxel$glow(CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValueZ() && RenderModules.ESP.shouldGlow((Entity) (Object) this)) {
            cir.setReturnValue(true);
        }
    }
}
