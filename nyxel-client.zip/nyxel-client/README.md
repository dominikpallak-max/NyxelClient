# Nyxel Client

Klient utility/cheat dla **Fabric 1.21.11** w stylu Meteor (fioletowy ClickGUI, kategorie, keybindy, configi).
Tylko po stronie klienta. **105 modulow**, ~3000 linii.

![baner](banner.png)

## Build

> **Kod nie byl kompilowany** (srodowisko, w ktorym powstal, nie ma dostepu do Mavena Fabrica).
> Skladnia Javy jest sprawdzona, ale nazwy klas/metod Yarn 1.21.11 pisane z pamieci moga wymagac drobnych poprawek.

1. JDK 21.
2. Sprawdz wersje w `gradle.properties` na https://fabricmc.net/develop (zwlaszcza `yarn_mappings` - numer buildu jest zgadniety).
3. `gradle build` -> `build/libs/nyxel-client-1.0.0.jar` do `.minecraft/mods` (potrzebny Fabric API).

Miejsca najbardziej narazone na zmiany API (jesli build sie wysypie, zacznij tu):
- `NoFall` - konstruktor `PlayerMoveC2SPacket.OnGroundOnly(boolean, boolean)`
- `Util.place` / `Placer` - `getInventory().getSelectedSlot()/setSelectedSlot()`, `interactBlock`
- `RenderModules.Hud` - `HudRenderCallback` (w nowszym Fabric API oznaczony jako przestarzaly)
- `ClientConnectionMixin` - sygnatura `send(Packet)` (dla FakeLag/Desync)
- `StashFinder` - `ClientChunkManager.getWorldChunk`, `MinecraftClient.getCurrentServerEntry().address`

## Sterowanie
- **Right Shift** - ClickGUI (zmiana: `.guikey <klawisz>`). LPM = wlacz modul, PPM = ustawienia, PPM na naglowku = zwin kolumne, kolko = przewijanie.
- W rozwinietym module klik w "Bind" i nacisnij klawisz (ESC = usun bind).
- Komendy na czacie z prefiksem `.`:

| Komenda | Opis |
|---|---|
| `.help` | pomoc |
| `.toggle <modul>` | wlacz/wylacz |
| `.bind <modul> <klawisz\|none>` | keybind |
| `.set <modul> <opcja> <wartosc>` | ustawienie (np. `.set Spammer Message hej`) |
| `.config save\|load\|list <nazwa>` | profile w `config/nyxel/<nazwa>.json` (`default` laduje sie sam i zapisuje przy wyjsciu) |
| `.friend add\|remove\|list <nick>` | przyjaciele (ignorowani przez KillAura, AutoTrap itd.) |
| `.stashes` | lista znalezionych stashy (zapis tez w `config/nyxel/stashes.txt`) |
| `.modules`, `.panic`, `.gui` | lista, wylacz wszystko, otworz GUI |

## Moduly (105)
**Combat (16):** KillAura, TriggerBot, Aimbot, AutoTotem, AutoArmor, AutoTrap, SelfTrap, Surround, AutoWeb, AutoClicker, AutoGapple, AutoShield, AutoWeapon, MobAura, JumpCrits, PearlThrow*
**Player (13):** AutoEat, AutoRespawn, AntiAFK, AutoTool, AutoLog, AutoReplenish, AutoDrop, XPThrower, InvMove, AutoMine, AutoUse, RotationLock, OffhandSwap*
**Movement (31):** Sprint, Flight, Speed, Step, NoFall, Spider, AutoJump, Parkour, Glide, AirJump, AntiVoid, FastClimb, FakeLag, Desync, Jesus, Sneak, EdgeSneak, HighJump, LongJump, Strafe, Bhop, AutoWalk, ElytraBoost, FastFall, Hover, Jetpack, WaterSpeed, AutoSwim, Dash*, Launch*, RocketBoost*
**Render (20):** ESP, Fullbright, HUD, ArmorHUD, Keystrokes, CPS, Speedometer, Clock, Direction, PotionHUD, TotemCount, WorldTime, NetherCoords, ServerInfo, SessionTimer, Radar, Crosshair, HealthAlert, Zoom, FovChanger (widzety HUD maja ustawienia X/Y)
**World (10):** StashFinder, Nuker, Scaffold, AutoHarvest, AutoLumber, OreFinder, SpawnerFinder, AutoTunnel, Lawnmower, AutoBonemeal
**Misc (15):** ChestStealer, Spammer, PlaceSound, VisualRange, DeathCoords, AutoLogin, AutoReply, AutoTPA, Twerk, Spinbot, Derp, ShareCoords*, DropAll*, AutoCommand, CycleHotbar

\* = modul jednorazowy: kazde klikniecie / nacisniecie bindu wykonuje akcje (nie zostaje "wlaczony"). Ustaw im bind.

Ograniczenia: AutoReply/AutoTPA widza tylko wiadomosci "systemowe" (czat z pluginow); zwykly podpisany czat vanilla ich nie wywola.

### FakeLag
Przechwytuje pakiety ruchu (opcjonalnie tez keep-alive = wyzszy ping) i zwalnia je paczkami.
`Constant` - wysyla co `DelayMs`; `Hold` - trzyma do wylaczenia / `MaxPackets`. `FlushOnAttack` wysyla kolejke tuz przed uderzeniem, `FlushOnHurt` gdy dostaniesz obrazenia.

### Desync
Blokuje wszystkie pakiety pozycji: klient chodzi/lata, serwer zostaje na pozycji z momentu wlaczenia (HUD pokazuje dystans).
`OnDisable=Return` cofa cie na pozycje serwera, `Sync` probuje zostac tam, gdzie jestes (serwer moze cofnac/rubberband).
Desync przez wierzchowca (entity desync) **nie jest** zaimplementowany.

### PlaceSound
Dzwiek przy kazdej probie postawienia bloku: Burp, Orb, ArrowHit, Anvil, VillagerNo, Egg, Enderman lub Random, z glosnoscia i pitch.

## Uwagi
- Wiekszosc modulow jest wykrywalna przez anticheaty. Na serwerach, gdzie cheaty sa zakazane (np. minigry/survival), dostaniesz bana - uzywaj na serwerach, gdzie sa dozwolone (anarchia) albo na wlasnych.
- Dodanie modulu: nowa klasa `extends Mod` + `ModuleManager.reg(...)` w odpowiednim `*Modules.register()`.
