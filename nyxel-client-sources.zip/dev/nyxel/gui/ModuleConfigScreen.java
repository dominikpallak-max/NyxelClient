package dev.nyxel.gui;

import dev.nyxel.core.*;
import org.lwjgl.glfw.GLFW;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

/** Maly config jednego modulu na ekranie gry (bez tla, reszta menu schowana). */
public class ModuleConfigScreen extends class_437 {
    private static final int W = 104, ROW = 11, HEAD = 13;
    private static final int C_HEAD = 0xFF7B2FF7, C_SET = 0xF01B1030, C_TEXT = 0xFFFFFFFF, C_DIM = 0xFFB8B0CC,
            C_ACC = 0xFFC77DFF, C_HOV = 0x28FFFFFF;

    private final Mod mod;
    private boolean lDown, lPrev, rDown, rPrev, binding;
    private final boolean[] keyPrev = new boolean[400];
    private Setting.Num dragNum;

    public ModuleConfigScreen(Mod m) { super(class_2561.method_43470(m.name)); this.mod = m; }

    @Override public boolean method_25421() { return false; }
    @Override public boolean method_25422() { return !binding; }

    private static boolean in(int mx, int my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    @Override public void method_25394(class_332 ctx, int mx, int my, float delta) {
        long h = field_22787.method_22683().method_4490();
        lPrev = lDown; rPrev = rDown;
        lDown = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        rDown = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean lc = lDown && !lPrev, rc = rDown && !rPrev;
        if (!lDown) dragNum = null;
        pollKeys(h);

        int x = 8, y = 8;
        ctx.method_25294(x, y, x + W, y + HEAD, C_HEAD);
        ctx.method_51433(field_22793, mod.name + (mod.enabled ? " [ON]" : " [OFF]"), x + 5, y + 3, C_TEXT, true);
        if (in(mx, my, x, y, W, HEAD) && lc) mod.toggle();
        int cy = y + HEAD;

        for (Setting<?> s : mod.settings) {
            boolean hov = in(mx, my, x, cy, W, ROW);
            ctx.method_25294(x, cy, x + W, cy + ROW, C_SET);
            if (s instanceof Setting.Bool b) {
                ctx.method_51433(field_22793, s.name, x + 5, cy + 2, C_TEXT, false);
                ctx.method_25294(x + W - 16, cy + 2, x + W - 7, cy + ROW - 2, b.get() ? C_ACC : 0xFF3A3050);
                if (hov && lc) b.toggle();
            } else if (s instanceof Setting.Num n) {
                ctx.method_25294(x, cy, x + (int) (W * n.ratio()), cy + ROW, 0x886B2FD0);
                ctx.method_51433(field_22793, s.name + ": " + n.display(), x + 5, cy + 2, C_TEXT, false);
                if (hov && lc) dragNum = n;
                if (dragNum == n && lDown) n.setRatio((mx - x) / (double) W);
            } else if (s instanceof Setting.Mode md) {
                String l = s.name + ": ";
                ctx.method_51433(field_22793, l, x + 5, cy + 2, C_TEXT, false);
                ctx.method_51433(field_22793, md.get(), x + 5 + field_22793.method_1727(l), cy + 2, C_ACC, false);
                if (hov && lc) md.cycle(1);
                if (hov && rc) md.cycle(-1);
            } else {
                ctx.method_51433(field_22793, s.name + ": " + s.display(), x + 5, cy + 2, C_DIM, false);
            }
            if (hov) ctx.method_25294(x, cy, x + W, cy + ROW, C_HOV);
            cy += ROW;
        }

        boolean hovB = in(mx, my, x, cy, W, ROW);
        ctx.method_25294(x, cy, x + W, cy + ROW, C_SET);
        ctx.method_51433(field_22793, binding ? "<klawisz, ESC = brak>" : "Bind: " + ClickGuiScreen.keyName(mod.bind),
                x + 5, cy + 2, binding ? C_ACC : C_TEXT, false);
        if (hovB && lc) binding = true;
        cy += ROW;

        boolean hovBack = in(mx, my, x, cy, W, ROW);
        ctx.method_25294(x, cy, x + W, cy + ROW, C_SET);
        ctx.method_51433(field_22793, "< menu", x + 5, cy + 2, C_DIM, false);
        if (hovBack && lc) { field_22787.method_1507(new ClickGuiScreen()); return; }
    }

    private void pollKeys(long h) {
        for (int k = 32; k < keyPrev.length; k++) {
            boolean d = GLFW.glfwGetKey(h, k) == GLFW.GLFW_PRESS;
            if (d && !keyPrev[k] && binding) {
                mod.bind = k == GLFW.GLFW_KEY_ESCAPE ? -1 : k;
                binding = false;
            }
            keyPrev[k] = d;
        }
    }
}
