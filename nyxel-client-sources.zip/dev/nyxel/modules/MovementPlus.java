package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import net.minecraft.class_1802;
import net.minecraft.class_243;

public final class MovementPlus {
    private MovementPlus() {}

    public static void register() {
        ModuleManager.reg(new Jesus());
        ModuleManager.reg(new Sneak());
        ModuleManager.reg(new EdgeSneak());
        ModuleManager.reg(new HighJump());
        ModuleManager.reg(new LongJump());
        ModuleManager.reg(new Strafe());
        ModuleManager.reg(new Bhop());
        ModuleManager.reg(new AutoWalk());
        ModuleManager.reg(new ElytraBoost());
        ModuleManager.reg(new FastFall());
        ModuleManager.reg(new Hover());
        ModuleManager.reg(new Jetpack());
        ModuleManager.reg(new WaterSpeed());
        ModuleManager.reg(new AutoSwim());
        ModuleManager.reg(new Dash());
        ModuleManager.reg(new Launch());
        ModuleManager.reg(new RocketBoost());
    }

    public static class Jesus extends Mod {
        public Jesus() { super("Jesus", "Chodzenie po wodzie (shift = zanurzenie)", Category.MOVEMENT); }
        @Override public void onTick() {
            var p = mc.field_1724;
            if (p.method_5715() || p.field_6017 > 3.0f && p.method_18798().field_1351 < -0.6) return; // shift lub dlugi spadek
            var pos = p.method_24515();
            boolean feetWater = !mc.field_1687.method_8320(pos).method_26227().method_15769();
            boolean aboveWater = !mc.field_1687.method_8320(pos.method_10084()).method_26227().method_15769();
            boolean belowWater = !mc.field_1687.method_8320(pos.method_10074()).method_26227().method_15769();
            class_243 v = p.method_18798();
            if (feetWater && aboveWater) {                 // wpadles gleboko - wynurz sie
                p.method_18800(v.field_1352, 0.18, v.field_1350);
            } else if (feetWater) {                        // na powierzchni - utrzymaj na wodzie
                p.method_18800(v.field_1352, Math.max(0.0, v.field_1351), v.field_1350);
                p.method_24830(true);
            } else if (belowWater && v.field_1351 <= 0) {  // stoisz tuz nad woda
                p.method_18800(v.field_1352, 0.0, v.field_1350);
                p.method_24830(true);
            }
        }
    }

    public static class Sneak extends Mod {
        public Sneak() { super("Sneak", "Zawsze skradasz sie", Category.MOVEMENT); }
        @Override public void onTick() { mc.field_1690.field_1832.method_23481(true); }
        @Override public void onDisable() { mc.field_1690.field_1832.method_23481(false); }
    }

    public static class EdgeSneak extends Mod {
        boolean set;
        public EdgeSneak() { super("EdgeSneak", "Automatycznie kucasz na krawedzi (nie spadniesz)", Category.MOVEMENT); }
        @Override public void onTick() {
            boolean edge = mc.field_1724.method_24828()
                    && mc.field_1687.method_8587(mc.field_1724, mc.field_1724.method_5829().method_989(0, -0.6, 0).method_1009(0.1, 0, 0.1).method_35580(0.0, 0, 0.0));
            if (edge) { mc.field_1690.field_1832.method_23481(true); set = true; }
            else if (set) { mc.field_1690.field_1832.method_23481(false); set = false; }
        }
        @Override public void onDisable() { if (set) mc.field_1690.field_1832.method_23481(false); set = false; }
    }

    public static class HighJump extends Mod {
        final Setting.Num height = num("Height", 0.8, 0.42, 3);
        public HighJump() { super("HighJump", "Wyzsze skoki", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.field_1724.method_24828() && mc.field_1690.field_1903.method_1434()) {
                class_243 v = mc.field_1724.method_18798();
                mc.field_1724.method_18800(v.field_1352, height.d(), v.field_1350);
            }
        }
    }

    public static class LongJump extends Mod {
        final Setting.Num boost = num("Boost", 0.9, 0.3, 3);
        public LongJump() { super("LongJump", "Dlugie skoki do przodu", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.field_1724.method_24828() && mc.field_1690.field_1903.method_1434() && Util.moving()) {
                Util.setHorizontalSpeed(boost.d());
                class_243 v = mc.field_1724.method_18798();
                mc.field_1724.method_18800(v.field_1352, 0.5, v.field_1350);
            }
        }
    }

    public static class Strafe extends Mod {
        public Strafe() { super("Strafe", "Pelna kontrola ruchu w powietrzu", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.field_1724.method_24828() || !Util.moving()) return;
            class_243 v = mc.field_1724.method_18798();
            Util.setHorizontalSpeed(Math.max(0.2, Math.sqrt(v.field_1352 * v.field_1352 + v.field_1350 * v.field_1350)));
        }
    }

    public static class Bhop extends Mod {
        final Setting.Num speed = num("Speed", 1.2, 0.5, 3);
        public Bhop() { super("Bhop", "Bunny hop - skacze i przyspiesza", Category.MOVEMENT); }
        @Override public void onTick() {
            if (!Util.moving()) return;
            if (mc.field_1724.method_24828()) mc.field_1724.method_6043();
            Util.setHorizontalSpeed(0.28 * speed.d());
        }
    }

    public static class AutoWalk extends Mod {
        public AutoWalk() { super("AutoWalk", "Ciagle idziesz do przodu", Category.MOVEMENT); }
        @Override public void onTick() { mc.field_1690.field_1894.method_23481(true); }
        @Override public void onDisable() { mc.field_1690.field_1894.method_23481(false); }
    }

    public static class ElytraBoost extends Mod {
        final Setting.Num boost = num("Boost", 1.0, 0.1, 5);
        public ElytraBoost() { super("ElytraBoost", "Trzymaj skok podczas lotu na elytrach, zeby przyspieszac", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.field_1724.method_6128() && mc.field_1690.field_1903.method_1434()) {
                class_243 look = mc.field_1724.method_5720();
                mc.field_1724.method_18799(mc.field_1724.method_18798().method_1019(look.method_1021(0.05 * boost.d())));
            }
        }
    }

    public static class FastFall extends Mod {
        final Setting.Num mult = num("Multiplier", 1.5, 1, 4);
        public FastFall() { super("FastFall", "Szybsze spadanie", Category.MOVEMENT); }
        @Override public void onTick() {
            class_243 v = mc.field_1724.method_18798();
            if (!mc.field_1724.method_24828() && v.field_1351 < 0) mc.field_1724.method_18800(v.field_1352, Math.max(v.field_1351 * mult.d(), -3.5), v.field_1350);
        }
    }

    public static class Hover extends Mod {
        public Hover() { super("Hover", "Trzymaj sneak, zeby zawisnac w powietrzu", Category.MOVEMENT); }
        @Override public void onTick() {
            if (!mc.field_1724.method_24828() && mc.field_1690.field_1832.method_1434()) {
                class_243 v = mc.field_1724.method_18798();
                mc.field_1724.method_18800(v.field_1352, 0, v.field_1350);
            }
        }
    }

    public static class Jetpack extends Mod {
        final Setting.Num power = num("Power", 0.5, 0.1, 2);
        public Jetpack() { super("Jetpack", "Trzymaj skok w powietrzu, zeby lecec w gore", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.field_1690.field_1903.method_1434() && !mc.field_1724.method_24828()) {
                class_243 v = mc.field_1724.method_18798();
                mc.field_1724.method_18800(v.field_1352, power.d(), v.field_1350);
            }
        }
    }

    public static class WaterSpeed extends Mod {
        final Setting.Num speed = num("Speed", 1.5, 0.5, 4);
        public WaterSpeed() { super("WaterSpeed", "Szybsze plywanie", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.field_1724.method_5799() && Util.moving()) Util.setHorizontalSpeed(0.17 * speed.d());
        }
    }

    public static class AutoSwim extends Mod {
        boolean set;
        public AutoSwim() { super("AutoSwim", "Automatycznie plyniesz w gore w wodzie", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.field_1724.method_5799()) { mc.field_1690.field_1903.method_23481(true); set = true; }
            else if (set) { mc.field_1690.field_1903.method_23481(false); set = false; }
        }
        @Override public void onDisable() { if (set) mc.field_1690.field_1903.method_23481(false); set = false; }
    }

    public static class Dash extends OneShot {
        final Setting.Num power = num("Power", 1.6, 0.5, 5);
        public Dash() { super("Dash", "Jednorazowy zryw w kierunku patrzenia (bind!)", Category.MOVEMENT); }
        @Override protected void run() {
            class_243 l = mc.field_1724.method_5720();
            mc.field_1724.method_18800(l.field_1352 * power.d(), 0.25, l.field_1350 * power.d());
        }
    }

    public static class Launch extends OneShot {
        final Setting.Num power = num("Power", 1.8, 0.5, 6);
        public Launch() { super("Launch", "Jednorazowy wystrzal w gore (bind!)", Category.MOVEMENT); }
        @Override protected void run() {
            class_243 v = mc.field_1724.method_18798();
            mc.field_1724.method_18800(v.field_1352, power.d(), v.field_1350);
        }
    }

    public static class RocketBoost extends OneShot {
        public RocketBoost() { super("RocketBoost", "Uzywa fajerwerku z hotbara (lot na elytrach)", Category.MOVEMENT); }
        @Override protected void run() {
            int s = Util.findHotbar(i -> i.method_31574(class_1802.field_8639));
            if (s < 0) Util.info("§cBrak fajerwerku w hotbarze"); else Util.useItem(s);
        }
    }
}
