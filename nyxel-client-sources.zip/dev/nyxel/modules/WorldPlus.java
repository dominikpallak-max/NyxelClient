package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import java.util.*;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2636;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3481;
import net.minecraft.class_3965;

public final class WorldPlus {
    private WorldPlus() {}

    public static void register() {
        ModuleManager.reg(new Search());
        ModuleManager.reg(new AutoHarvest());
        ModuleManager.reg(new AutoLumber());
        ModuleManager.reg(new OreFinder());
        ModuleManager.reg(new SpawnerFinder());
        ModuleManager.reg(new AutoTunnel());
        ModuleManager.reg(new Lawnmower());
        ModuleManager.reg(new AutoBonemeal());
    }

    /** Wszystkie pozycje w kuli o promieniu r spelniajace warunek, od najblizszej. */
    static List<class_2338> scan(double r, Predicate<class_2680> f) {
        List<class_2338> out = new ArrayList<>();
        class_2338 c = mc().field_1724.method_24515();
        class_243 eye = mc().field_1724.method_33571();
        int ri = (int) Math.ceil(r);
        for (int x = -ri; x <= ri; x++) for (int y = -ri; y <= ri; y++) for (int z = -ri; z <= ri; z++) {
            class_2338 p = c.method_10069(x, y, z);
            if (eye.method_1022(class_243.method_24953(p)) > r) continue;
            if (f.test(mc().field_1687.method_8320(p))) out.add(p);
        }
        out.sort(Comparator.comparingDouble(p -> eye.method_1025(class_243.method_24953(p))));
        return out;
    }
    private static net.minecraft.class_310 mc() { return net.minecraft.class_310.method_1551(); }

    public static class AutoHarvest extends Mod {
        final Setting.Num range = num("Range", 4.5, 1, 6);
        public AutoHarvest() { super("AutoHarvest", "Zbiera dojrzale uprawy w poblizu", Category.WORLD); }
        @Override public void onTick() {
            var l = scan(range.d(), s -> s.method_26204() instanceof class_2302 c && c.method_9825(s));
            if (!l.isEmpty()) Util.mine(l.get(0));
        }
    }

    public static class AutoLumber extends Mod {
        final Setting.Num range = num("Range", 4.5, 1, 6);
        public AutoLumber() { super("AutoLumber", "Scina pnie drzew w poblizu", Category.WORLD); }
        @Override public void onTick() {
            var l = scan(range.d(), s -> s.method_26164(class_3481.field_15475));
            if (!l.isEmpty()) Util.mine(l.get(0));
        }
    }

    /** Wyszukiwarka blokow: wpisz nazwy blokow po przecinku (np. diamond_ore,ancient_debris), lista + strzalka na HUD. */
    public static class Search extends Mod {
        final Setting.Str blocks = str("Blocks", "diamond_ore,ancient_debris");
        final Setting.Num radius = numI("Radius", 20, 4, 32);
        final Setting.Num maxResults = numI("MaxResults", 5, 1, 10);
        private final List<class_2338> hits = new ArrayList<>();
        private final Set<String> wanted = new HashSet<>();

        public Search() { super("Search", "Szuka wybranych blokow w poblizu (lista + strzalka na ekranie)", Category.WORLD); }

        @Override public void onTick() {
            if (mc.field_1724.field_6012 % 20 != 0) return;
            wanted.clear();
            for (String b : blocks.get().toLowerCase().split(",")) { b = b.trim(); if (!b.isEmpty()) wanted.add(b.replace("minecraft:", "")); }
            hits.clear();
            if (wanted.isEmpty()) return;
            for (class_2338 p : scan(radius.d(), st -> wanted.contains(
                    net.minecraft.class_7923.field_41175.method_10221(st.method_26204()).method_12832()))) {
                hits.add(p);
                if (hits.size() >= maxResults.i()) break;
            }
        }

        @Override public void onHud(net.minecraft.class_332 ctx) {
            int y = 4, w = ctx.method_51421();
            for (class_2338 p : hits) {
                double dx = p.method_10263() + 0.5 - mc.field_1724.method_23317(), dz = p.method_10260() + 0.5 - mc.field_1724.method_23321();
                double rel = net.minecraft.class_3532.method_15338(Math.toDegrees(Math.atan2(-dx, dz)) - mc.field_1724.method_36454());
                String ar = Math.abs(rel) < 45 ? "\u2191" : Math.abs(rel) > 135 ? "\u2193" : rel > 0 ? "\u2192" : "\u2190";
                String t = ar + " " + p.method_10263() + " " + p.method_10264() + " " + p.method_10260()
                        + " (" + (int) Math.sqrt(dx * dx + dz * dz) + "m)";
                ctx.method_51433(mc.field_1772, t, w - mc.field_1772.method_1727(t) - 4, y, 0xFFC77DFF, true);
                y += 10;
            }
        }
    }

    public static class OreFinder extends Mod {
        final Setting.Num radius = numI("Radius", 14, 4, 32);
        final Setting.Bool diamond = bool("Diamond", true), debris = bool("AncientDebris", true),
                emerald = bool("Emerald", true), gold = bool("Gold", false);
        private final Set<Long> seen = new HashSet<>();
        public OreFinder() { super("OreFinder", "Pisze na czacie koordynaty rud w poblizu", Category.WORLD); }
        @Override public void onEnable() { seen.clear(); }
        @Override public void onTick() {
            if (mc.field_1724.field_6012 % 40 != 0) return;
            int n = 0;
            for (class_2338 p : scan(radius.d(), this::wanted)) {
                if (!seen.add(p.method_10063())) continue;
                Util.info("§b" + mc.field_1687.method_8320(p).method_26204().method_9518().getString() + " §fna "
                        + p.method_10263() + " " + p.method_10264() + " " + p.method_10260());
                if (++n >= 5) break;
            }
        }
        private boolean wanted(class_2680 s) {
            return (diamond.get() && s.method_26164(class_3481.field_28989)) || (debris.get() && s.method_27852(class_2246.field_22109))
                    || (emerald.get() && s.method_26164(class_3481.field_29194)) || (gold.get() && s.method_26164(class_3481.field_23062));
        }
    }

    public static class SpawnerFinder extends Mod {
        private final Set<Long> seen = new HashSet<>();
        public SpawnerFinder() { super("SpawnerFinder", "Wykrywa spawnery w zaladowanych chunkach", Category.WORLD); }
        @Override public void onEnable() { seen.clear(); }
        @Override public void onTick() {
            if (mc.field_1724.field_6012 % 40 != 0) return;
            int pcx = mc.field_1724.method_31477() >> 4, pcz = mc.field_1724.method_31479() >> 4;
            int r = Math.min(mc.field_1690.method_42503().method_41753(), 32);
            for (int cx = pcx - r; cx <= pcx + r; cx++) for (int cz = pcz - r; cz <= pcz + r; cz++) {
                class_2818 ch = mc.field_1687.method_2935().method_21730(cx, cz);
                if (ch == null) continue;
                for (class_2586 be : ch.method_12214().values()) {
                    if (be instanceof class_2636 && seen.add(be.method_11016().method_10063()))
                        Util.info("§6Spawner §fna " + be.method_11016().method_10263() + " " + be.method_11016().method_10264() + " " + be.method_11016().method_10260());
                }
            }
        }
    }

    public static class AutoTunnel extends Mod {
        final Setting.Num length = numI("Length", 3, 1, 5);
        final Setting.Bool walk = bool("Walk", true);
        public AutoTunnel() { super("AutoTunnel", "Kopie tunel 1x2 przed toba", Category.WORLD); }
        @Override public void onDisable() { mc.field_1690.field_1894.method_23481(false); }
        @Override public void onTick() {
            class_2350 d = mc.field_1724.method_5735();
            class_2338 b = mc.field_1724.method_24515();
            boolean mining = false;
            for (int k = 1; k <= length.i() && !mining; k++) {
                for (class_2338 p : new class_2338[]{b.method_10079(d, k), b.method_10079(d, k).method_10084()}) {
                    class_2680 s = mc.field_1687.method_8320(p);
                    if (!s.method_26215() && s.method_26227().method_15769() && s.method_26214(mc.field_1687, p) >= 0) { Util.mine(p); mining = true; break; }
                }
            }
            if (walk.get()) mc.field_1690.field_1894.method_23481(!mining);
        }
    }

    public static class Lawnmower extends Mod {
        final Setting.Num range = num("Range", 4.5, 1, 6);
        public Lawnmower() { super("Lawnmower", "Wycina trawe, kwiaty i krzaki wokol", Category.WORLD); }
        @Override public void onTick() {
            int n = 0;
            for (class_2338 p : scan(range.d(), s -> !s.method_26215() && s.method_26164(class_3481.field_44471) && s.method_26227().method_15769())) {
                Util.mine(p);
                if (++n >= 4) break;
            }
        }
    }

    public static class AutoBonemeal extends Mod {
        final Setting.Num range = num("Range", 4.5, 1, 6);
        public AutoBonemeal() { super("AutoBonemeal", "Uzywa mączki kostnej na niedojrzalych uprawach", Category.WORLD); }
        @Override public void onTick() {
            if (mc.field_1724.field_6012 % 3 != 0) return;
            int slot = Util.findHotbar(s -> s.method_31574(class_1802.field_8324));
            if (slot < 0) return;
            var l = scan(range.d(), s -> s.method_26204() instanceof class_2302 c && !c.method_9825(s));
            if (l.isEmpty()) return;
            class_2338 p = l.get(0);
            int prev = mc.field_1724.method_31548().method_67532();
            mc.field_1724.method_31548().method_61496(slot);
            mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, new class_3965(class_243.method_24953(p), class_2350.field_11036, p, false));
            mc.field_1724.method_6104(class_1268.field_5808);
            mc.field_1724.method_31548().method_61496(prev);
        }
    }
}
