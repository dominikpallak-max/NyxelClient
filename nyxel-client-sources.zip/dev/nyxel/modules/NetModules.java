package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.PacketHooks;
import dev.nyxel.util.Util;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2827;
import net.minecraft.class_2828;
import net.minecraft.class_332;

/** Moduly sieciowe: FakeLag (opoznianie pakietow) i Desync (klient != serwer). */
public final class NetModules {
    private NetModules() {}

    public static void register() {
        ModuleManager.reg(new FakeLag());
        ModuleManager.reg(new Desync());
    }

    private static void hudLine(class_332 ctx, String text, int yOff) {
        int w = mc().field_1772.method_1727(text);
        ctx.method_51433(mc().field_1772, text, ctx.method_51421() / 2 - w / 2,
                ctx.method_51443() / 2 + yOff, 0xFFC77DFF, true);
    }
    private static net.minecraft.class_310 mc() { return net.minecraft.class_310.method_1551(); }
    private static class_243 pos() { var p = mc().field_1724; return new class_243(p.method_23317(), p.method_23318(), p.method_23321()); }

    // ------------------------------------------------------------------
    public static class FakeLag extends Mod {
        final Setting.Mode mode = mode("Mode", "Constant", "Constant", "Hold");
        final Setting.Num delay = numI("DelayMs", 400, 50, 5000);
        final Setting.Num max = numI("MaxPackets", 300, 20, 2000);
        final Setting.Bool keepAlive = bool("DelayKeepAlive", false);
        final Setting.Bool flushAttack = bool("FlushOnAttack", true);
        final Setting.Bool flushHurt = bool("FlushOnHurt", true);
        final Setting.Bool hud = bool("ShowQueue", true);
        private final List<class_2596<?>> queue = new ArrayList<>();
        private long last;

        public FakeLag() {
            super("FakeLag", "Opoznia pakiety ruchu - serwer widzi cie z lagiem", Category.MOVEMENT);
            PacketHooks.FILTERS.add(this::filter);
        }

        private boolean filter(class_2596<?> p) {
            if (!enabled || mc.field_1724 == null) return false;
            if (flushAttack.get() && p instanceof class_2824) { flush(); return false; }
            boolean q = p instanceof class_2828 || (keepAlive.get() && p instanceof class_2827);
            if (!q) return false;
            synchronized (queue) { queue.add(p); }
            return true;
        }

        public void flush() {
            List<class_2596<?>> snap;
            synchronized (queue) { snap = new ArrayList<>(queue); queue.clear(); }
            last = System.currentTimeMillis();
            for (class_2596<?> p : snap) PacketHooks.sendRaw(p);
        }

        @Override public void onEnable() { last = System.currentTimeMillis(); }
        @Override public void onDisable() { flush(); }

        @Override public void onTick() {
            boolean due = mode.is("Constant") && System.currentTimeMillis() - last >= delay.i();
            if (flushHurt.get() && mc.field_1724.field_6235 > 0) due = true;
            int size; synchronized (queue) { size = queue.size(); }
            if (size >= max.i()) due = true;
            if (due) flush();
        }

        @Override public void onHud(class_332 ctx) {
            if (!hud.get()) return;
            int size; synchronized (queue) { size = queue.size(); }
            hudLine(ctx, "FakeLag: " + size + " pakietow w kolejce", 24);
        }
    }

    // ------------------------------------------------------------------
    public static class Desync extends Mod {
        final Setting.Mode onDisable = mode("OnDisable", "Return", "Return", "Sync");
        final Setting.Bool hud = bool("ShowInfo", true);
        private class_243 serverPos, lastPos;

        public Desync() {
            super("Desync", "Klient sie rusza, serwer zostaje na starej pozycji", Category.MOVEMENT);
            PacketHooks.FILTERS.add(p -> enabled && mc.field_1724 != null && p instanceof class_2828);
        }

        @Override public void onEnable() {
            if (mc.field_1724 == null) return;
            serverPos = pos();
            lastPos = serverPos;
        }

        @Override public void onTick() {
            class_243 now = pos();
            // duzy skok = teleport od serwera (rubberband) -> serwer i klient znowu zgodne
            if (lastPos != null && now.method_1022(lastPos) > 20) serverPos = now;
            lastPos = now;
        }

        @Override public void onDisable() {
            if (mc.field_1724 == null || serverPos == null) return;
            if (onDisable.is("Return")) {
                mc.field_1724.method_33574(serverPos);
                mc.field_1724.method_18799(class_243.field_1353);
            }
            // "Sync": nastepne pakiety ruchu zglosza aktualna pozycje (serwer moze cofnac)
            serverPos = null;
        }

        @Override public void onHud(class_332 ctx) {
            if (!hud.get() || serverPos == null || mc.field_1724 == null) return;
            double d = pos().method_1022(serverPos);
            hudLine(ctx, String.format("Desync: %.1f bloku od pozycji serwera (%.0f %.0f %.0f)",
                    d, serverPos.field_1352, serverPos.field_1351, serverPos.field_1350), 24);
        }
    }
}
