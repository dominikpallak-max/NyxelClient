package dev.nyxel.modules;

import dev.nyxel.core.*;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1429;
import net.minecraft.class_1542;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_332;

public final class RenderModules {
    private RenderModules() {}

    public static void register() {
        ModuleManager.reg(new ESP());
        ModuleManager.reg(new Fullbright());
        ModuleManager.reg(new Tracers());
        ModuleManager.reg(new Freelook());
    }

    public static class ESP extends Mod {
        static ESP inst;
        final Setting.Bool players = bool("Players", true), hostile = bool("Hostile", true),
                animals = bool("Animals", false), items = bool("Items", true);
        public ESP() { super("ESP", "Kontur encji widoczny przez sciany", Category.RENDER); inst = this; }
        /** Wolane z EntityMixin. */
        public static boolean shouldGlow(class_1297 e) {
            if (inst == null || !inst.enabled || e == mc.field_1724) return false;
            if (e instanceof class_1657) return inst.players.get();
            if (e instanceof class_1588) return inst.hostile.get();
            if (e instanceof class_1429) return inst.animals.get();
            if (e instanceof class_1542) return inst.items.get();
            return false;
        }
    }

    public static class Fullbright extends Mod {
        public Fullbright() { super("Fullbright", "Pelna jasnosc (nocne widzenie po stronie klienta)", Category.RENDER); }
        @Override public void onTick() {
            mc.field_1724.method_6092(new class_1293(class_1294.field_5925, 400, 0, false, false, false));
        }
        @Override public void onDisable() { if (mc.field_1724 != null) mc.field_1724.method_6016(class_1294.field_5925); }
    }

    /** Freelook: kamera obraca sie niezaleznie od kierunku patrzenia gracza (obsluga w CameraMixin/EntityMixin). */
    public static class Freelook extends Mod {
        public static boolean active;
        public static float yaw, pitch;
        public Freelook() { super("Freelook", "Rozgladanie sie kamera bez zmiany kierunku ruchu/patrzenia", Category.RENDER); }
        @Override public void onEnable() {
            if (mc.field_1724 == null) return;
            yaw = mc.field_1724.method_36454();
            pitch = mc.field_1724.method_36455();
            active = true;
        }
        @Override public void onDisable() { active = false; }
    }

    /** Tracery 2D: linie od dolu ekranu do encji (rzutowanie wg yaw/pitch/FOV kamery). */
    public static class Tracers extends Mod {
        final Setting.Bool players = bool("Players", true), hostile = bool("Hostile", false),
                animals = bool("Animals", false), items = bool("Items", false);
        final Setting.Num range = numI("Range", 128, 8, 512);
        final Setting.Bool friendsGreen = bool("FriendsGreen", true);

        public Tracers() { super("Tracers", "Linie do graczy/mobow na ekranie", Category.RENDER); }

        @Override public void onHud(class_332 ctx) {
            if (mc.field_1687 == null) return;
            int w = ctx.method_51421(), h = ctx.method_51443();
            float yawDeg = Freelook.active ? Freelook.yaw : mc.field_1724.method_36454();
            float pitchDeg = Freelook.active ? Freelook.pitch : mc.field_1724.method_36455();
            double y = Math.toRadians(yawDeg), p = Math.toRadians(pitchDeg);
            double fx = -Math.sin(y) * Math.cos(p), fy = -Math.sin(p), fz = Math.cos(y) * Math.cos(p);
            double rx = -Math.cos(y), ry = 0, rz = -Math.sin(y);
            double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;
            double fovY = Math.toRadians(mc.field_1690.method_41808().method_41753());
            double f = (h / 2.0) / Math.tan(fovY / 2.0);
            var eye = mc.field_1724.method_33571();
            for (class_1297 e : mc.field_1687.method_18112()) {
                if (e == mc.field_1724) continue;
                int col;
                if (e instanceof class_1657 pl) {
                    if (!players.get()) continue;
                    col = (friendsGreen.get() && dev.nyxel.util.Util.isFriend(pl)) ? 0xFF55FF55 : 0xFFC77DFF;
                } else if (e instanceof class_1588) { if (!hostile.get()) continue; col = 0xFFFF5555; }
                else if (e instanceof class_1429) { if (!animals.get()) continue; col = 0xFF55AAFF; }
                else if (e instanceof class_1542) { if (!items.get()) continue; col = 0xFFFFFF55; }
                else continue;
                if (mc.field_1724.method_5739(e) > range.d()) continue;
                double dx = e.method_23317() - eye.field_1352, dy = e.method_23318() + e.method_17682() / 2 - eye.field_1351,
                        dz = e.method_23321() - eye.field_1350;
                double zc = dx * fx + dy * fy + dz * fz;
                double xc = dx * rx + dy * ry + dz * rz;
                double yc = dx * ux + dy * uy + dz * uz;
                double sx, sy;
                if (zc > 0.05) { sx = w / 2.0 + xc / zc * f; sy = h / 2.0 - yc / zc * f; }
                else { double l = Math.max(1e-3, Math.hypot(xc, yc)); sx = w / 2.0 + xc / l * w; sy = h / 2.0 - yc / l * w; }
                line(ctx, w / 2, h, (int) sx, (int) sy, col, w, h);
            }
        }

        private static void line(class_332 ctx, int x0, int y0, int x1, int y1, int col, int w, int h) {
            int steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
            if (steps == 0) return;
            for (int i = 0; i <= steps; i += 1) {
                int x = x0 + (x1 - x0) * i / steps, y = y0 + (y1 - y0) * i / steps;
                if (x < 0 || y < 0 || x >= w || y >= h) continue;
                ctx.method_25294(x, y, x + 1, y + 1, col);
            }
        }
    }
}
