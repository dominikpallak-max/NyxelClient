package dev.nyxel.mixin;

import dev.nyxel.modules.RenderModules;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Freelook: po zwyklym update kamery nadpisuje jej rotacje wartosciami z Freelook. */
@Mixin(class_4184.class)
public abstract class CameraMixin {
    @Shadow protected abstract void method_19325(float yaw, float pitch);

    @Inject(method = "method_19321", at = @At("RETURN"))
    private void nyxel$freelook(CallbackInfo ci) {
        if (RenderModules.Freelook.active) method_19325(RenderModules.Freelook.yaw, RenderModules.Freelook.pitch);
    }
}
