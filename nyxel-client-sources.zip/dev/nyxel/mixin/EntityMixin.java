package dev.nyxel.mixin;

import dev.nyxel.modules.RenderModules;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** ESP: wymusza glow na wybranych encjach. Freelook: ruch myszy kreci kamera zamiast graczem. */
@Mixin(class_1297.class)
public abstract class EntityMixin {
    @Inject(method = "method_5851", at = @At("RETURN"), cancellable = true)
    private void nyxel$glow(CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValueZ() && RenderModules.ESP.shouldGlow((class_1297) (Object) this)) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "method_5872", at = @At("HEAD"), cancellable = true)
    private void nyxel$look(double dx, double dy, CallbackInfo ci) {
        if (!RenderModules.Freelook.active || (Object) this != class_310.method_1551().field_1724) return;
        RenderModules.Freelook.yaw += (float) dx * 0.15F;
        RenderModules.Freelook.pitch = Math.max(-90F, Math.min(90F, RenderModules.Freelook.pitch + (float) dy * 0.15F));
        ci.cancel();
    }
}
