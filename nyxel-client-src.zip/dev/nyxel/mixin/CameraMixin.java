package dev.nyxel.mixin;

import dev.nyxel.modules.RenderPlus;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** FreeLook: po aktualizacji kamery nadpisuje jej kat (tylko widok klienta, nie rotacja gracza). */
@Mixin(class_4184.class)
public abstract class CameraMixin {
    @Shadow protected abstract void method_19325(float yaw, float pitch);

    @Inject(method = "method_19321", at = @At("TAIL"), require = 0)
    private void nyxel$freelook(CallbackInfo ci) {
        if (RenderPlus.FreeLook.active()) method_19325(RenderPlus.FreeLook.yaw, RenderPlus.FreeLook.pitch);
    }
}
