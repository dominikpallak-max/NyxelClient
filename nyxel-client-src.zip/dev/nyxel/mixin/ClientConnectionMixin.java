package dev.nyxel.mixin;

import dev.nyxel.util.PacketHooks;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2535.class)
public abstract class ClientConnectionMixin {
    @Inject(method = "method_10743", at = @At("HEAD"), cancellable = true)
    private void nyxel$send(class_2596<?> packet, CallbackInfo ci) {
        if (PacketHooks.intercept(packet)) ci.cancel();
    }
}
