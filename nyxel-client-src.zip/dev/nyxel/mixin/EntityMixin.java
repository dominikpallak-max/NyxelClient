package dev.nyxel.mixin;

import dev.nyxel.modules.RenderModules;
import dev.nyxel.modules.RenderPlus;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** ESP: wymusza efekt glow (kontur widoczny przez sciany) na wybranych encjach. */
@Mixin(class_1297.class)
public abstract class EntityMixin {
    @Inject(method = "isGlowing", at = @At("RETURN"), cancellable = true)
    private void nyxel$glow(CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValueZ() && RenderModules.ESP.shouldGlow((class_1297) (Object) this)) {
            cir.setReturnValue(true);
        }
    }

    /** FreeLook: ruch myszy steruje kamera zamiast graczem. */
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true, require = 0)
    private void nyxel$look(double dx, double dy, CallbackInfo ci) {
        if ((Object) this == net.minecraft.class_310.method_1551().field_1724 && RenderPlus.FreeLook.look(dx, dy)) ci.cancel();
    }
}
