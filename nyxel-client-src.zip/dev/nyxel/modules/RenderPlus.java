package dev.nyxel.modules;

import dev.nyxel.core.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_1429;
import net.minecraft.class_1542;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_332;
import net.minecraft.class_310;

/** Moduly "legit-look" zamiast widgetow HUD: FreeLook, Tracers, Search. (Widgety ArmorHUD/Keystrokes/... usuniete.) */
public final class RenderPlus {
    private RenderPlus() {}
    private static final class_310 mc = class_310.method_1551();

    public static void register() {
        ModuleManager.reg(new FreeLook());
        ModuleManager.reg(new Tracers());
        ModuleManager.reg(new Search());
    }

    // ------------------------------------------------------------------ rzutowanie 3D -> ekran (2D)
    /** @return {sx, sy, behind(0/1)} albo null. Kamera = oczy gracza, kierunek = FreeLook albo normalny. */
    static double[] project(class_243 t, int w, int h) {
        var p = mc.field_1724;
        float yawD = FreeLook.active() ? FreeLook.yaw : p.method_36454();
        float pitD = FreeLook.active() ? FreeLook.pitch : p.method_36455();
        double yaw = Math.toRadians(yawD), pit = Math.toRadians(pitD);
        double fx = -Math.sin(yaw) * Math.cos(pit), fy = -Math.sin(pit), fz = Math.cos(yaw) * Math.cos(pit);
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        double ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy;
        class_243 e = p.method_33571();
        double dx = t.field_1352 - e.field_1352, dy = t.field_1351 - e.field_1351, dz = t.field_1350 - e.field_1350;
        double z = dx * fx + dy * fy + dz * fz, x = dx * rx + dz * rz, y = dx * ux + dy * uy + dz * uz;
        double f = (h / 2.0) / Math.tan(Math.toRadians(mc.field_1690.method_41808().method_41753()) / 2.0);
        boolean behind = z <= 0.05;
        if (behind) { x = -x * 1000; y = -y * 1000; z = 1; }
        double sx = w / 2.0 + x / z * f, sy = h / 2.0 - y / z * f;
        double m = 6;
        sx = Math.max(m, Math.min(w - m, sx));
        sy = Math.max(m, Math.min(h - m, sy));
        return new double[]{sx, sy, behind ? 1 : 0};
    }

    static void line(class_332 c, int x0, int y0, int x1, int y1, int col) {
        int n = (int) Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        if (n == 0) return;
        for (int i = 0; i <= n; i += 1) {
            int x = x0 + (x1 - x0) * i / n, y = y0 + (y1 - y0) * i / n;
            c.method_25294(x, y, x + 1, y + 1, col);
        }
    }

    // ------------------------------------------------------------------ FreeLook
    /** Rozglada sie kamera bez zmiany rotacji gracza (rotacja wysylana na serwer pozostaje taka jak byla). */
    public static class FreeLook extends Mod {
        public static float yaw, pitch;
        static FreeLook inst;
        public FreeLook() { super("FreeLook", "Rozgladanie sie kamera bez obracania postaci", Category.RENDER); inst = this; }
        public static boolean active() { return inst != null && inst.enabled && mc.field_1724 != null; }
        @Override public void onEnable() {
            if (mc.field_1724 != null) { yaw = mc.field_1724.method_36454(); pitch = mc.field_1724.method_36455(); }
        }
        /** Wolane z mixina: zwraca true, gdy ruch myszy ma isc do kamery, a nie do gracza. */
        public static boolean look(double dx, double dy) {
            if (!active()) return false;
            yaw += (float) dx * 0.15f;
            pitch = Math.max(-90f, Math.min(90f, pitch + (float) dy * 0.15f));
            return true;
        }
    }

    // ------------------------------------------------------------------ Tracers
    public static class Tracers extends Mod {
        final Setting.Bool players = bool("Players", true), hostile = bool("Hostile", false),
                animals = bool("Animals", false), items = bool("Items", false), friends = bool("Friends", true);
        final Setting.Num range = numI("Range", 128, 8, 512);
        public Tracers() { super("Tracers", "Linie od srodka ekranu do graczy/mobow", Category.RENDER); }
        @Override public void onHud(class_332 c) {
            int w = c.method_51421(), h = c.method_51443();
            for (class_1297 e : mc.field_1687.method_18112()) {
                if (e == mc.field_1724) continue;
                int col;
                if (e instanceof class_1657 p) {
                    if (!players.get()) continue;
                    col = dev.nyxel.util.Util.isFriend(p) ? (friends.get() ? 0xFF5CFF8A : 0) : 0xFFFF4D6D;
                } else if (e instanceof class_1588) { if (!hostile.get()) continue; col = 0xFFFFA24D; }
                else if (e instanceof class_1429) { if (!animals.get()) continue; col = 0xFF6AD7FF; }
                else if (e instanceof class_1542) { if (!items.get()) continue; col = 0xFFFFE066; }
                else continue;
                if (col == 0 || mc.field_1724.method_5739(e) > range.d()) continue;
                double[] s = project(e.method_33571().method_1023(0, -e.method_17682() / 2.0, 0), w, h);
                line(c, w / 2, h / 2, (int) s[0], (int) s[1], col);
                c.method_25294((int) s[0] - 1, (int) s[1] - 1, (int) s[0] + 2, (int) s[1] + 2, col);
            }
        }
    }

    // ------------------------------------------------------------------ Search (blokowa wyszukiwarka)
    public static class Search extends Mod {
        final Setting.Str blocks = str("Blocks", "diamond_ore,deepslate_diamond_ore,ancient_debris");
        final Setting.Num range = numI("Range", 24, 4, 64);
        final Setting.Bool tracer = bool("Tracer", false);
        private final List<class_2338> found = new ArrayList<>();
        private final Map<net.minecraft.class_2248, Boolean> cache = new HashMap<>();
        private String lastSpec = "";
        public Search() { super("Search", "Wyszukuje wybrane bloki (.set Search Blocks id,id) i oznacza je na ekranie", Category.RENDER); }

        private boolean wanted(net.minecraft.class_2248 b) {
            return cache.computeIfAbsent(b, k -> {
                String key = net.minecraft.class_7923.field_41175.method_10221(k).method_12832();
                String id = key.substring(key.lastIndexOf('.') + 1);
                for (String s : blocks.get().split(",")) if (s.trim().equalsIgnoreCase(id)) return true;
                return false;
            });
        }

        @Override public void onTick() {
            if (!lastSpec.equals(blocks.get())) { lastSpec = blocks.get(); cache.clear(); found.clear(); }
            if (mc.field_1724.field_6012 % 20 != 0) return;
            List<class_2338> out = new ArrayList<>();
            class_2338 c = mc.field_1724.method_24515();
            int r = range.i();
            for (int x = -r; x <= r && out.size() < 300; x++)
                for (int y = -r; y <= r; y++)
                    for (int z = -r; z <= r; z++) {
                        class_2338 p = c.method_10069(x, y, z);
                        var st = mc.field_1687.method_8320(p);
                        if (st.method_26215()) continue;
                        if (wanted(st.method_26204())) out.add(p);
                    }
            synchronized (found) { found.clear(); found.addAll(out); }
        }

        @Override public void onHud(class_332 c) {
            int w = c.method_51421(), h = c.method_51443();
            List<class_2338> snap;
            synchronized (found) { snap = new ArrayList<>(found); }
            for (class_2338 p : snap) {
                double[] s = project(class_243.method_24953(p), w, h);
                if (s[2] == 1) continue;
                int x = (int) s[0], y = (int) s[1];
                c.method_25294(x - 2, y - 2, x + 3, y + 3, 0xFFC77DFF);
                if (tracer.get()) line(c, w / 2, h / 2, x, y, 0x88C77DFF);
            }
        }
    }
}
