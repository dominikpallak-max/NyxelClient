package dev.nyxel.modules;

import dev.nyxel.NyxelClient;
import dev.nyxel.core.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1429;
import net.minecraft.class_1542;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_332;
import net.minecraft.class_640;

public final class RenderModules {
    private RenderModules() {}

    public static void register() {
        ModuleManager.reg(new ESP());
        ModuleManager.reg(new Fullbright());
        ModuleManager.reg(new Hud());
    }

    public static class ESP extends Mod {
        static ESP inst;
        final Setting.Bool players = bool("Players", true), hostile = bool("Hostile", true),
                animals = bool("Animals", false), items = bool("Items", true);
        public ESP() { super("ESP", "Kontur encji widoczny przez sciany", Category.RENDER); inst = this; }
        /** Wolane z EntityMixin. */
        public static boolean shouldGlow(class_1297 e) {
            if (inst == null || !inst.enabled || e == mc.field_1724) return false;
            if (e instanceof class_1657) return inst.players.get();
            if (e instanceof class_1588) return inst.hostile.get();
            if (e instanceof class_1429) return inst.animals.get();
            if (e instanceof class_1542) return inst.items.get();
            return false;
        }
    }

    public static class Fullbright extends Mod {
        public Fullbright() { super("Fullbright", "Pelna jasnosc (nocne widzenie po stronie klienta)", Category.RENDER); }
        @Override public void onTick() {
            mc.field_1724.method_6092(new class_1293(class_1294.field_5925, 400, 0, false, false, false));
        }
        @Override public void onDisable() { if (mc.field_1724 != null) mc.field_1724.method_6016(class_1294.field_5925); }
    }

    public static class Hud extends Mod {
        final Setting.Bool watermark = bool("Watermark", true), coords = bool("Coords", true),
                fps = bool("FPS", true), ping = bool("Ping", true), arrayList = bool("ArrayList", true);
        static final int PURPLE = 0xFFB45CFF, WHITE = 0xFFFFFFFF, GRAY = 0xFFB8B8C8;

        public Hud() { super("HUD", "Znak wodny, koordynaty, FPS, ping i lista modulow", Category.RENDER); enabled = true; }

        @Override public void onHud(class_332 ctx) {
            var tr = mc.field_1772;
            int y = 4;
            if (watermark.get()) {
                ctx.method_51433(tr, NyxelClient.NAME, 4, y, PURPLE, true);
                ctx.method_51433(tr, "v" + NyxelClient.VERSION, 6 + tr.method_1727(NyxelClient.NAME), y, GRAY, true);
                y += 11;
            }
            if (coords.get()) {
                ctx.method_51433(tr, String.format("XYZ %.1f %.1f %.1f", mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()), 4, y, WHITE, true);
                y += 10;
            }
            if (fps.get()) { ctx.method_51433(tr, "FPS " + mc.method_47599(), 4, y, WHITE, true); y += 10; }
            if (ping.get() && mc.method_1562() != null) {
                class_640 e = mc.method_1562().method_2871(mc.field_1724.method_5667());
                if (e != null) ctx.method_51433(tr, "Ping " + e.method_2959() + "ms", 4, y, WHITE, true);
            }
            if (arrayList.get()) {
                List<Mod> on = new ArrayList<>();
                for (Mod m : ModuleManager.ALL) if (m.enabled && m != this) on.add(m);
                on.sort(Comparator.comparingInt((Mod m) -> -tr.method_1727(m.name)));
                int ry = 4, w = ctx.method_51421();
                for (Mod m : on) {
                    ctx.method_51433(tr, m.name, w - tr.method_1727(m.name) - 4, ry, PURPLE, true);
                    ry += 10;
                }
            }
        }
    }
}
