package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1747;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2589;
import net.minecraft.class_2601;
import net.minecraft.class_2611;
import net.minecraft.class_2609;
import net.minecraft.class_2614;
import net.minecraft.class_2627;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3719;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.*;

public final class WorldModules {
    private WorldModules() {}

    public static void register() {
        ModuleManager.reg(new StashFinder());
        ModuleManager.reg(new Nuker());
        ModuleManager.reg(new Scaffold());
    }

    /**
     * Skanuje zaladowane chunki i raportuje te z kontenerami (stashe/bazy).
     * Config: Radius (w blokach od gracza), typy kontenerow, kierunek auto-marszu.
     * Uwaga: klient widzi tylko chunki zaladowane (render distance) - dalszy obszar skanuje sie w miare marszu (Direction).
     */
    public static class StashFinder extends Mod {
        public static final List<String> log = new ArrayList<>();
        final Setting.Num radius = numI("Radius", 1000, 16, 100000);
        final Setting.Num minContainers = numI("MinContainers", 4, 1, 60);
        final Setting.Bool chests = bool("Chests", true), ender = bool("EnderChests", false),
                barrels = bool("Barrels", true), shulkers = bool("Shulkers", true),
                hoppers = bool("Hoppers", false), dispensers = bool("DispDroppers", false),
                furnaces = bool("Furnaces", false), brewing = bool("BrewingStands", false);
        final Setting.Bool shulkerAlert = bool("ShulkerAlert", true);
        final Setting.Mode direction = mode("Direction", "Off", "Off", "North", "South", "East", "West",
                "NorthEast", "NorthWest", "SouthEast", "SouthWest");
        final Setting.Bool arrow = bool("ShowArrow", true);
        final Setting.Bool chat = bool("ChatAlert", true);
        final Setting.Bool save = bool("SaveToFile", true);
        private final Set<Long> seen = new HashSet<>();
        private Object lastWorld;
        private double startX, startZ;

        public StashFinder() { super("StashFinder", "Wyszukuje chunki z kontenerami (typy, promien, kierunek - w configu)", Category.WORLD); }

        @Override public void onEnable() {
            seen.clear();
            if (mc.field_1724 != null) { startX = mc.field_1724.method_23317(); startZ = mc.field_1724.method_23321(); }
        }

        @Override public void onDisable() {
            if (!direction.is("Off")) mc.field_1690.field_1894.method_23481(false);
        }

        private float yawFor(String d) {
            return switch (d) {
                case "South" -> 0f; case "SouthWest" -> 45f; case "West" -> 90f; case "NorthWest" -> 135f;
                case "North" -> 180f; case "NorthEast" -> -135f; case "East" -> -90f; default -> -45f; // SouthEast
            };
        }

        private static String arrowFor(String d) {
            return switch (d) {
                case "North" -> "\u2191"; case "South" -> "\u2193"; case "East" -> "\u2192"; case "West" -> "\u2190";
                case "NorthEast" -> "\u2197"; case "NorthWest" -> "\u2196"; case "SouthEast" -> "\u2198"; case "SouthWest" -> "\u2199";
                default -> "";
            };
        }

        private boolean counts(class_2586 be) {
            return (chests.get() && be instanceof class_2595)
                    || (ender.get() && be instanceof class_2611)
                    || (barrels.get() && be instanceof class_3719)
                    || (shulkers.get() && be instanceof class_2627)
                    || (hoppers.get() && be instanceof class_2614)
                    || (dispensers.get() && be instanceof class_2601)
                    || (furnaces.get() && be instanceof class_2609)
                    || (brewing.get() && be instanceof class_2589);
        }

        @Override public void onTick() {
            // auto-marsz w wybranym kierunku
            if (!direction.is("Off")) {
                mc.field_1724.method_36456(yawFor(direction.get()));
                mc.field_1690.field_1894.method_23481(true);
            }
            if (mc.field_1724.field_6012 % 20 != 0) return;
            if (lastWorld != mc.field_1687) { seen.clear(); lastWorld = mc.field_1687; }
            double px = mc.field_1724.method_23317(), pz = mc.field_1724.method_23321();
            int pcx = mc.field_1724.method_31477() >> 4, pcz = mc.field_1724.method_31479() >> 4;
            int rChunks = (int) Math.ceil(radius.d() / 16.0);
            int r = Math.min(rChunks, Math.max(mc.field_1690.method_42503().method_41753(), 2) + 2);
            double rad2 = radius.d() * radius.d();
            for (int cx = pcx - r; cx <= pcx + r; cx++) {
                for (int cz = pcz - r; cz <= pcz + r; cz++) {
                    double dx = cx * 16 + 8 - px, dz = cz * 16 + 8 - pz;
                    if (dx * dx + dz * dz > rad2) continue;
                    long key = ((long) cx << 32) ^ (cz & 0xFFFFFFFFL);
                    if (seen.contains(key)) continue;
                    class_2818 chunk = mc.field_1687.method_2935().method_21730(cx, cz);
                    if (chunk == null) continue;
                    int total = 0, sh = 0;
                    for (class_2586 be : chunk.method_12214().values()) {
                        if (be instanceof class_2627) sh++;
                        if (counts(be)) total++;
                    }
                    if (total >= minContainers.i() || (shulkerAlert.get() && sh > 0)) {
                        seen.add(key);
                        report(cx, cz, total, sh);
                    }
                }
            }
        }

        @Override public void onHud(net.minecraft.class_332 c) {
            if (!arrow.get() || direction.is("Off")) return;
            String t = arrowFor(direction.get()) + " " + direction.get() + "  " + (int) Math.hypot(mc.field_1724.method_23317() - startX, mc.field_1724.method_23321() - startZ) + "m";
            c.method_51433(mc.field_1772, t, c.method_51421() / 2 - mc.field_1772.method_1727(t) / 2, 20, 0xFFC77DFF, true);
        }

        private void report(int cx, int cz, int total, int shulkers) {
            int x = cx * 16 + 8, z = cz * 16 + 8;
            String line = String.format("Stash? X=%d Z=%d  kontenery=%d shulkery=%d", x, z, total, shulkers);
            log.add(line);
            if (log.size() > 200) log.remove(0);
            if (chat.get()) Util.info("\u00a7d" + line);
            if (save.get()) {
                try {
                    String srv = mc.method_1558() != null ? mc.method_1558().field_3761 : "singleplayer";
                    var f = FabricLoader.getInstance().getConfigDir().resolve("nyxel/stashes.txt");
                    Files.createDirectories(f.getParent());
                    Files.writeString(f, srv + " | " + line + System.lineSeparator(),
                            StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                } catch (IOException ignored) {}
            }
        }
    }

    public static class Nuker extends Mod {
        final Setting.Num range = num("Range", 4, 1, 6);
        final Setting.Num perTick = numI("BlocksPerTick", 1, 1, 10);
        final Setting.Bool flatten = bool("OnlyAtOrAboveFeet", true);
        public Nuker() { super("Nuker", "Niszczy bloki wokol ciebie", Category.WORLD); }
        @Override public void onTick() {
            int r = (int) Math.ceil(range.d());
            class_2338 c = mc.field_1724.method_24515();
            class_243 eye = mc.field_1724.method_33571();
            List<class_2338> list = new ArrayList<>();
            for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
                class_2338 p = c.method_10069(x, y, z);
                if (flatten.get() && p.method_10264() < c.method_10264()) continue;
                if (eye.method_1022(class_243.method_24953(p)) > range.d()) continue;
                class_2680 s = mc.field_1687.method_8320(p);
                if (s.method_26215() || !s.method_26227().method_15769() || s.method_26214(mc.field_1687, p) < 0) continue;
                list.add(p);
            }
            list.sort(Comparator.comparingDouble(p -> eye.method_1025(class_243.method_24953(p))));
            int n = 0;
            for (class_2338 p : list) {
                if (n++ >= perTick.i()) break;
                if (mc.field_1724.method_68878()) mc.field_1761.method_2910(p, class_2350.field_11036);
                else mc.field_1761.method_2902(p, class_2350.field_11036);
                mc.field_1724.method_6104(net.minecraft.class_1268.field_5808);
            }
        }
    }

    public static class Scaffold extends Mod {
        final Setting.Bool rotate = bool("Rotate", false), tower = bool("Tower", true);
        public Scaffold() { super("Scaffold", "Stawia bloki pod toba podczas chodzenia", Category.WORLD); }
        @Override public void onTick() {
            int slot = Util.findHotbar(s -> s.method_7909() instanceof class_1747);
            if (slot < 0) return;
            class_2338 below = mc.field_1724.method_24515().method_10074();
            if (Util.place(below, slot, rotate.get()) && tower.get() && mc.field_1690.field_1903.method_1434() && !Util.moving()) {
                class_243 v = mc.field_1724.method_18798();
                mc.field_1724.method_18800(v.field_1352, 0.42, v.field_1350);
            }
        }
    }
}
