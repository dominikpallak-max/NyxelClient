package dev.nyxel.util;

import dev.nyxel.core.Config;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public final class Util {
    private static final class_310 mc = class_310.method_1551();

    private Util() {}

    public static void info(String s) {
        if (mc.field_1724 != null) mc.field_1724.method_7353(class_2561.method_43470("§dNyxelClient §7\u00bb §f" + s), false);
    }

    public static boolean isFriend(class_1657 p) { return Config.friends.contains(p.method_5477().getString()); }

    public static int findHotbar(Predicate<class_1799> p) {
        for (int i = 0; i < 9; i++) if (p.test(mc.field_1724.method_31548().method_5438(i))) return i;
        return -1;
    }

    /** Index w ekwipunku (0-8 hotbar, 9-35 glowny) -> numer slotu w playerScreenHandler. */
    public static int screenSlot(int invIndex) { return invIndex < 9 ? invIndex + 36 : invIndex; }

    public static void lookAt(class_243 t) {
        class_243 e = mc.field_1724.method_33571();
        double dx = t.field_1352 - e.field_1352, dy = t.field_1351 - e.field_1351, dz = t.field_1350 - e.field_1350;
        double h = Math.sqrt(dx * dx + dz * dz);
        mc.field_1724.method_36456((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
        mc.field_1724.method_36457((float) -Math.toDegrees(Math.atan2(dy, h)));
    }

    public static List<class_1309> targets(double range, boolean players, boolean hostile, boolean animals,
                                             boolean walls, boolean byHealth) {
        List<class_1309> out = new ArrayList<>();
        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1309 le) || e == mc.field_1724 || !le.method_5805() || le.method_7325()) continue;
            if (mc.field_1724.method_5739(le) > range) continue;
            boolean ok = (e instanceof class_1657 p && players && !isFriend(p))
                    || (e instanceof class_1588 && hostile)
                    || (e instanceof class_1429 && animals);
            if (!ok) continue;
            if (!walls && !mc.field_1724.method_6057(le)) continue;
            out.add(le);
        }
        out.sort(byHealth ? Comparator.comparingDouble(class_1309::method_6032)
                : Comparator.comparingDouble(x -> mc.field_1724.method_5739(x)));
        return out;
    }

    public static class_1657 nearestPlayer(double range) {
        class_1657 best = null; double bd = range;
        for (class_1657 p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724 || !p.method_5805() || p.method_7325() || isFriend(p)) continue;
            double d = mc.field_1724.method_5739(p);
            if (d <= bd) { bd = d; best = p; }
        }
        return best;
    }

    /** Stawia blok z podanego slotu hotbara na pos, opierajac sie o sasiedni blok. */
    public static boolean place(class_2338 pos, int slot, boolean rotate) {
        if (!mc.field_1687.method_8320(pos).method_45474()) return false;
        if (mc.field_1724.method_33571().method_1022(class_243.method_24953(pos)) > 5.0) return false;
        for (class_2350 d : class_2350.values()) {
            class_2338 n = pos.method_10093(d);
            if (mc.field_1687.method_8320(n).method_45474()) continue;
            class_2350 face = d.method_10153();
            class_243 hit = class_243.method_24953(n).method_1031(face.method_10148() * 0.5, face.method_10164() * 0.5, face.method_10165() * 0.5);
            int prev = mc.field_1724.method_31548().method_67532();
            mc.field_1724.method_31548().method_61496(slot);
            if (rotate) lookAt(hit);
            mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, new class_3965(hit, face, n, false));
            mc.field_1724.method_6104(class_1268.field_5808);
            mc.field_1724.method_31548().method_61496(prev);
            return true;
        }
        return false;
    }

    public static boolean moving() {
        return mc.field_1690.field_1894.method_1434() || mc.field_1690.field_1881.method_1434()
                || mc.field_1690.field_1913.method_1434() || mc.field_1690.field_1849.method_1434();
    }

    /** Ustawia predkosc pozioma wg klawiszy WASD i yaw, zachowujac Y. */
    public static void setHorizontalSpeed(double speed) {
        float f = (mc.field_1690.field_1894.method_1434() ? 1 : 0) - (mc.field_1690.field_1881.method_1434() ? 1 : 0);
        float s = (mc.field_1690.field_1913.method_1434() ? 1 : 0) - (mc.field_1690.field_1849.method_1434() ? 1 : 0);
        class_243 v = mc.field_1724.method_18798();
        if (f == 0 && s == 0) { mc.field_1724.method_18800(0, v.field_1351, 0); return; }
        double len = Math.sqrt(f * f + s * s);
        f /= len; s /= len;
        double yaw = Math.toRadians(mc.field_1724.method_36454());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        mc.field_1724.method_18800((-sin * f + cos * s) * speed, v.field_1351, (cos * f + sin * s) * speed);
    }

    /** Kopie/niszczenie bloku (creative = natychmiast, survival = postep co tick). */
    public static void mine(class_2338 p) {
        if (mc.field_1724.method_68878()) mc.field_1761.method_2910(p, class_2350.field_11036);
        else mc.field_1761.method_2902(p, class_2350.field_11036);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    /** Uzywa przedmiotu z danego slotu hotbara (perla, rakieta...) i wraca na poprzedni slot. */
    public static void useItem(int slot) {
        int prev = mc.field_1724.method_31548().method_67532();
        mc.field_1724.method_31548().method_61496(slot);
        mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
        mc.field_1724.method_31548().method_61496(prev);
    }

    public static void say(String m) {
        if (mc.method_1562() == null) return;
        if (m.startsWith("/")) mc.method_1562().method_45730(m.substring(1));
        else mc.method_1562().method_45729(m);
    }
}
