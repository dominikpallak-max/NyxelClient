package dev.nyxel.gui;

import dev.nyxel.NyxelClient;
import dev.nyxel.core.*;
import org.lwjgl.glfw.GLFW;

import java.util.EnumMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

/**
 * ClickGUI w stylu Meteora: kolumna na kategorie.
 * LPM na module = wlacz/wylacz, PPM = rozwin ustawienia. PPM na naglowku = zwin kolumne.
 * Wejscie jest odczytywane przez GLFW (niezalezne od zmian API ekranow).
 */
public class ClickGuiScreen extends class_437 {
    private static final int W = 84, ROW = 11, HEAD = 13;
    private static final int C_HEAD = 0xFF7B2FF7, C_BG = 0xE6140C22, C_ON = 0xFF5B2A9E, C_SET = 0xF01B1030,
            C_TEXT = 0xFFFFFFFF, C_DIM = 0xFFB8B0CC, C_ACC = 0xFFC77DFF, C_HOV = 0x28FFFFFF;

    private static final Map<Category, int[]> POS = new EnumMap<>(Category.class); // x, y, zwiniete
    private static final Set<Mod> EXPANDED = new HashSet<>();
    private static int scroll;

    private boolean lDown, lPrev, rDown, rPrev;
    private final boolean[] keyPrev = new boolean[400];
    private Mod binding;
    private Setting.Num dragNum;
    private Category dragWin;
    private int dragDX, dragDY;
    private Mod hovered;
    private Mod cfg;                       // modul, ktorego config jest teraz na ekranie
    private static int cfgX = 10, cfgY = 14;
    private boolean cfgDrag;
    private int cfgDX, cfgDY;

    public ClickGuiScreen() { super(class_2561.method_43470(NyxelClient.NAME)); }

    @Override protected void method_25426() {
        if (!POS.isEmpty()) return;
        int i = 0;
        for (Category c : Category.values()) { POS.put(c, new int[]{8 + i * (W + 4), 14, 0}); i++; }
    }

    @Override public boolean method_25421() { return false; }
    @Override public boolean method_25422() { return binding == null; }

    @Override public boolean method_25401(double x, double y, double h, double v) {
        scroll = Math.max(-700, Math.min(0, scroll + (int) (v * 16)));
        return true;
    }

    private static boolean in(int mx, int my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    @Override public void method_25394(class_332 ctx, int mx, int my, float delta) {
        long h = field_22787.method_22683().method_4490();
        lPrev = lDown; rPrev = rDown;
        lDown = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        rDown = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean lc = lDown && !lPrev, rc = rDown && !rPrev;
        if (!lDown) { dragNum = null; dragWin = null; }
        pollKeys(h);

                hovered = null;

        if (cfg != null) { renderConfig(ctx, mx, my, lc, rc); return; }

        for (Category cat : Category.values()) {
            int[] p = POS.get(cat);
            if (dragWin == cat && lDown) { p[0] = mx - dragDX; p[1] = my - dragDY - scroll; }
            int x = p[0], y = p[1] + scroll;
            ctx.method_25294(x, y, x + W, y + HEAD, C_HEAD);
            ctx.method_51433(field_22793, cat.label, x + 4, y + 3, C_TEXT, true);
            ctx.method_51433(field_22793, p[2] == 1 ? "+" : "-", x + W - 9, y + 3, C_TEXT, false);
            if (in(mx, my, x, y, W, HEAD)) {
                if (lc && dragWin == null) { dragWin = cat; dragDX = mx - x; dragDY = my - y; }
                if (rc) p[2] ^= 1;
            }
            int cy = y + HEAD;
            if (p[2] == 1) continue;
            for (Mod m : ModuleManager.in(cat)) {
                boolean hov = in(mx, my, x, cy, W, ROW);
                ctx.method_25294(x, cy, x + W, cy + ROW, m.enabled ? C_ON : C_BG);
                if (hov) ctx.method_25294(x, cy, x + W, cy + ROW, C_HOV);
                ctx.method_51433(field_22793, m.name, x + 4, cy + 2, m.enabled ? C_TEXT : C_DIM, false);
                if (!m.settings.isEmpty()) ctx.method_51433(field_22793, "+", x + W - 9, cy + 2, C_DIM, false);
                if (hov && dragWin == null) {
                    hovered = m;
                    if (lc) m.toggle();
                    if (rc) { cfg = m; }
                }
                cy += ROW;
            }
        }

        ctx.method_51433(field_22793, "LPM: wlacz  PPM: config", 4, field_22790 - 10, C_DIM, true);

        if (hovered != null) {
            String d = hovered.description;
            int w = field_22793.method_1727(d) + 8;
            int tx = Math.min(mx + 10, field_22789 - w - 2), ty = my + 12;
            ctx.method_25294(tx, ty, tx + w, ty + 14, 0xF0000000);
            ctx.method_51433(field_22793, d, tx + 4, ty + 3, C_ACC, false);
        }
    }

    /** Maly panel configu jednego modulu - caly pozostaly ClickGUI jest wtedy ukryty. */
    private void renderConfig(class_332 ctx, int mx, int my, boolean lc, boolean rc) {
        if (cfgDrag && lDown) { cfgX = mx - cfgDX; cfgY = my - cfgDY; } else cfgDrag = false;
        int x = cfgX, y = cfgY;
        ctx.method_25294(x, y, x + W, y + HEAD, C_HEAD);
        ctx.method_51433(field_22793, "< " + cfg.name, x + 4, y + 3, C_TEXT, true);
        if (in(mx, my, x, y, W, HEAD)) {
            if (lc) { cfgDrag = true; cfgDX = mx - x; cfgDY = my - y; }
            if (rc) { cfg = null; return; }
        }
        int cy = y + HEAD;
        boolean hov = in(mx, my, x, cy, W, ROW);
        ctx.method_25294(x, cy, x + W, cy + ROW, cfg.enabled ? C_ON : C_BG);
        ctx.method_51433(field_22793, cfg.enabled ? "Wlaczony" : "Wylaczony", x + 4, cy + 2, cfg.enabled ? C_TEXT : C_DIM, false);
        if (hov && lc) cfg.toggle();
        cy += ROW;
        drawSettings(ctx, cfg, x, cy, mx, my, lc, rc);
    }

    private int drawSettings(class_332 ctx, Mod m, int x, int cy, int mx, int my, boolean lc, boolean rc) {
        for (Setting<?> s : m.settings) {
            boolean hov = in(mx, my, x, cy, W, ROW);
            ctx.method_25294(x, cy, x + W, cy + ROW, C_SET);
            if (s instanceof Setting.Bool b) {
                ctx.method_51433(field_22793, " " + s.name, x + 4, cy + 2, C_TEXT, false);
                ctx.method_25294(x + W - 14, cy + 3, x + W - 5, cy + ROW - 3, b.get() ? C_ACC : 0xFF3A3050);
                if (hov && lc) b.toggle();
            } else if (s instanceof Setting.Num n) {
                int fw = (int) (W * n.ratio());
                ctx.method_25294(x, cy, x + fw, cy + ROW, 0x886B2FD0);
                ctx.method_51433(field_22793, " " + s.name + ": " + n.display(), x + 4, cy + 2, C_TEXT, false);
                if (hov && lc) dragNum = n;
                if (dragNum == n && lDown) n.setRatio((mx - x) / (double) W);
            } else if (s instanceof Setting.Mode md) {
                ctx.method_51433(field_22793, " " + s.name + ": ", x + 4, cy + 2, C_TEXT, false);
                ctx.method_51433(field_22793, md.get(), x + 4 + field_22793.method_1727(" " + s.name + ": "), cy + 3, C_ACC, false);
                if (hov && lc) md.cycle(1);
                if (hov && rc) md.cycle(-1);
            } else {
                ctx.method_51433(field_22793, " " + s.name + ": " + s.display(), x + 4, cy + 2, C_DIM, false);
            }
            cy += ROW;
        }
        // bind
        boolean hov = in(mx, my, x, cy, W, ROW);
        ctx.method_25294(x, cy, x + W, cy + ROW, C_SET);
        String bt = binding == m ? "<klawisz, ESC=brak>" : " Bind: " + keyName(m.bind);
        ctx.method_51433(field_22793, bt, x + 4, cy + 2, binding == m ? C_ACC : C_TEXT, false);
        if (hov && lc) binding = m;
        return cy + ROW;
    }

    private void pollKeys(long h) {
        for (int k = 32; k < keyPrev.length; k++) {
            boolean d = GLFW.glfwGetKey(h, k) == GLFW.GLFW_PRESS;
            if (d && !keyPrev[k] && binding != null) {
                binding.bind = k == GLFW.GLFW_KEY_ESCAPE ? -1 : k;
                binding = null;
            }
            keyPrev[k] = d;
        }
    }

    public static String keyName(int k) {
        if (k < 0) return "brak";
        String n = GLFW.glfwGetKeyName(k, 0);
        if (n != null) return n.toUpperCase();
        return switch (k) {
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCTRL";
            case GLFW.GLFW_KEY_LEFT_ALT -> "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "RALT";
            case GLFW.GLFW_KEY_TAB -> "TAB";
            case GLFW.GLFW_KEY_ENTER -> "ENTER";
            case GLFW.GLFW_KEY_UP -> "UP";
            case GLFW.GLFW_KEY_DOWN -> "DOWN";
            case GLFW.GLFW_KEY_LEFT -> "LEFT";
            case GLFW.GLFW_KEY_RIGHT -> "RIGHT";
            default -> (k >= GLFW.GLFW_KEY_F1 && k <= GLFW.GLFW_KEY_F12) ? "F" + (k - GLFW.GLFW_KEY_F1 + 1) : "KEY" + k;
        };
    }
}
