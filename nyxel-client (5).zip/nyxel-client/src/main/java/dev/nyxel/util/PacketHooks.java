package dev.nyxel.util;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Predicate;
import net.minecraft.class_2596;
import net.minecraft.class_310;

/** Wspolny hak na pakiety wychodzace. Filtr zwracajacy true = pakiet przechwycony (nie idzie na serwer). */
public final class PacketHooks {
    public static final List<Predicate<class_2596<?>>> FILTERS = new CopyOnWriteArrayList<>();
    private static volatile boolean bypass;

    private PacketHooks() {}

    /** Wolane z mixina. true = anuluj wysylke. */
    public static boolean intercept(class_2596<?> p) {
        if (bypass) return false;
        for (Predicate<class_2596<?>> f : FILTERS) if (f.test(p)) return true;
        return false;
    }

    /** Wysyla pakiet z pominieciem filtrow (np. przy zwalnianiu kolejki). */
    public static void sendRaw(class_2596<?> p) {
        var h = class_310.method_1551().method_1562();
        if (h == null) return;
        bypass = true;
        try { h.method_52787(p); } finally { bypass = false; }
    }
}
