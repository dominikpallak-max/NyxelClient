package dev.nyxel.core;

import com.google.gson.*;
import dev.nyxel.NyxelClient;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

/** Profile/configi w .minecraft/config/nyxel/<nazwa>.json */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static final Set<String> friends = new LinkedHashSet<>();

    private Config() {}

    public static Path dir() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("nyxel");
        try { Files.createDirectories(p); } catch (IOException ignored) {}
        return p;
    }

    private static Path file(String name) { return dir().resolve(name.replaceAll("[^a-zA-Z0-9_-]", "") + ".json"); }

    public static boolean save(String name) {
        try {
            JsonObject root = new JsonObject();
            root.addProperty("guiKey", ModuleManager.guiKey);
            root.addProperty("toggleMessages", NyxelClient.toggleMessages);
            JsonArray fr = new JsonArray();
            friends.forEach(fr::add);
            root.add("friends", fr);
            JsonObject mods = new JsonObject();
            for (Mod m : ModuleManager.ALL) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.enabled);
                o.addProperty("bind", m.bind);
                JsonObject s = new JsonObject();
                for (Setting<?> st : m.settings) s.add(st.name, st.toJson());
                o.add("settings", s);
                mods.add(m.name, o);
            }
            root.add("modules", mods);
            Files.writeString(file(name), GSON.toJson(root));
            return true;
        } catch (Exception e) { NyxelClient.LOG.error("Zapis configu", e); return false; }
    }

    /** applyEnabled=false przy starcie gry (modul nie wlacza sie bez swiata). */
    public static boolean load(String name, boolean applyEnabled) {
        Path f = file(name);
        if (!Files.exists(f)) return false;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            if (root.has("guiKey")) ModuleManager.guiKey = root.get("guiKey").getAsInt();
            if (root.has("toggleMessages")) NyxelClient.toggleMessages = root.get("toggleMessages").getAsBoolean();
            friends.clear();
            if (root.has("friends")) root.getAsJsonArray("friends").forEach(e -> friends.add(e.getAsString()));
            JsonObject mods = root.getAsJsonObject("modules");
            if (mods != null) for (Mod m : ModuleManager.ALL) {
                if (!mods.has(m.name)) continue;
                JsonObject o = mods.getAsJsonObject(m.name);
                if (o.has("bind")) m.bind = o.get("bind").getAsInt();
                if (o.has("settings")) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (Setting<?> st : m.settings) if (s.has(st.name)) {
                        try { st.fromJson(s.get(st.name)); } catch (Exception ignored) {}
                    }
                }
                if (applyEnabled && o.has("enabled")) m.setEnabled(o.get("enabled").getAsBoolean());
            }
            return true;
        } catch (Exception e) { NyxelClient.LOG.error("Wczytanie configu", e); return false; }
    }

    public static List<String> list() {
        List<String> l = new ArrayList<>();
        try (Stream<Path> s = Files.list(dir())) {
            s.map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".json"))
                    .map(n -> n.substring(0, n.length() - 5)).sorted().forEach(l::add);
        } catch (IOException ignored) {}
        return l;
    }
}
