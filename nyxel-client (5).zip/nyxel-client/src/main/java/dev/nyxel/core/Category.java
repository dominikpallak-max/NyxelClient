package dev.nyxel.core;

public enum Category {
    COMBAT("Combat"), PLAYER("Player"), MOVEMENT("Movement"), RENDER("Render"), WORLD("World"), MISC("Misc");

    public final String label;
    Category(String label) { this.label = label; }
}
