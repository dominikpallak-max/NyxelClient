package dev.nyxel.core;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.List;
import java.util.Locale;

public abstract class Setting<T> {
    public final String name;
    protected T value;
    protected final T def;

    protected Setting(String name, T def) { this.name = name; this.def = def; this.value = def; }

    public T get() { return value; }
    public void reset() { value = def; }
    public abstract JsonElement toJson();
    public abstract void fromJson(JsonElement e);
    public abstract String display();
    /** Ustawienie z komendy .set */
    public abstract boolean parse(String s);

    // ------------------------------------------------------------------
    public static class Bool extends Setting<Boolean> {
        public Bool(String n, boolean d) { super(n, d); }
        public void set(boolean v) { value = v; }
        public void toggle() { value = !value; }
        public JsonElement toJson() { return new JsonPrimitive(value); }
        public void fromJson(JsonElement e) { value = e.getAsBoolean(); }
        public String display() { return value ? "ON" : "OFF"; }
        public boolean parse(String s) {
            if (s.equalsIgnoreCase("true") || s.equals("1") || s.equalsIgnoreCase("on")) { value = true; return true; }
            if (s.equalsIgnoreCase("false") || s.equals("0") || s.equalsIgnoreCase("off")) { value = false; return true; }
            return false;
        }
    }

    public static class Num extends Setting<Double> {
        public final double min, max;
        public final boolean integer;
        public Num(String n, double d, double min, double max, boolean integer) {
            super(n, d); this.min = min; this.max = max; this.integer = integer;
        }
        public void set(double v) {
            v = Math.max(min, Math.min(max, v));
            value = integer ? (double) Math.round(v) : Math.round(v * 100.0) / 100.0;
        }
        public void setRatio(double r) { set(min + (max - min) * Math.max(0, Math.min(1, r))); }
        public double ratio() { return (value - min) / (max - min); }
        public int i() { return (int) Math.round(value); }
        public double d() { return value; }
        public float f() { return value.floatValue(); }
        public JsonElement toJson() { return new JsonPrimitive(value); }
        public void fromJson(JsonElement e) { set(e.getAsDouble()); }
        public String display() { return integer ? String.valueOf(i()) : String.format(Locale.ROOT, "%.2f", value); }
        public boolean parse(String s) {
            try { set(Double.parseDouble(s.replace(',', '.'))); return true; } catch (NumberFormatException ex) { return false; }
        }
    }

    public static class Mode extends Setting<String> {
        public final List<String> options;
        public Mode(String n, String d, String... opts) { super(n, d); this.options = List.of(opts); }
        public boolean is(String s) { return value.equalsIgnoreCase(s); }
        public void cycle(int dir) {
            int i = options.indexOf(value);
            i = (i + dir + options.size()) % options.size();
            value = options.get(i);
        }
        public JsonElement toJson() { return new JsonPrimitive(value); }
        public void fromJson(JsonElement e) { parse(e.getAsString()); }
        public String display() { return value; }
        public boolean parse(String s) {
            for (String o : options) if (o.equalsIgnoreCase(s)) { value = o; return true; }
            return false;
        }
    }

    public static class Str extends Setting<String> {
        public Str(String n, String d) { super(n, d); }
        public void set(String v) { value = v; }
        public JsonElement toJson() { return new JsonPrimitive(value); }
        public void fromJson(JsonElement e) { value = e.getAsString(); }
        public String display() { return value.length() > 14 ? value.substring(0, 13) + "…" : value; }
        public boolean parse(String s) { value = s; return true; }
    }
}
