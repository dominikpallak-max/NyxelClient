package dev.nyxel.core;

import dev.nyxel.NyxelClient;
import dev.nyxel.util.Util;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_332;

/** Bazowa klasa modulu (nazwa Mod zeby nie kolidowac z java.lang.Module). */
public abstract class Mod {
    protected static final class_310 mc = class_310.method_1551();

    public final String name, description;
    public final Category category;
    public boolean enabled;
    public int bind = -1;
    public final List<Setting<?>> settings = new ArrayList<>();

    protected Mod(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }

    protected Setting.Bool bool(String n, boolean d) { return add(new Setting.Bool(n, d)); }
    protected Setting.Num num(String n, double d, double min, double max) { return add(new Setting.Num(n, d, min, max, false)); }
    protected Setting.Num numI(String n, int d, int min, int max) { return add(new Setting.Num(n, d, min, max, true)); }
    protected Setting.Mode mode(String n, String d, String... o) { return add(new Setting.Mode(n, d, o)); }
    protected Setting.Str str(String n, String d) { return add(new Setting.Str(n, d)); }
    private <S extends Setting<?>> S add(S s) { settings.add(s); return s; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean v) {
        if (v == enabled) return;
        enabled = v;
        try { if (v) onEnable(); else onDisable(); } catch (Throwable t) { NyxelClient.LOG.error("Modul {}", name, t); }
        if (mc.field_1724 != null && NyxelClient.toggleMessages) Util.info(name + (v ? " §aON" : " §cOFF"));
    }

    public Setting<?> setting(String n) {
        for (Setting<?> s : settings) if (s.name.equalsIgnoreCase(n)) return s;
        return null;
    }

    public void onEnable() {}
    public void onDisable() {}
    /** Wolane co tick, tylko gdy gracz i swiat istnieja. */
    public void onTick() {}
    public void onHud(class_332 ctx) {}
}
