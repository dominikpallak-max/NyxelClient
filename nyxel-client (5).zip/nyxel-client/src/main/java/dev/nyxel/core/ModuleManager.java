package dev.nyxel.core;

import dev.nyxel.NyxelClient;
import dev.nyxel.gui.ClickGuiScreen;
import dev.nyxel.modules.*;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class ModuleManager {
    private static final class_310 mc = class_310.method_1551();
    public static final List<Mod> ALL = new ArrayList<>();
    private static final boolean[] keyPrev = new boolean[400];
    public static int guiKey = GLFW.GLFW_KEY_RIGHT_SHIFT;

    private ModuleManager() {}

    public static void init() {
        CombatModules.register();
        PlayerModules.register();
        MovementModules.register();
        RenderModules.register();
        WorldModules.register();
        MiscModules.register();
        NetModules.register();
        CombatPlus.register();
        MovementPlus.register();
        PlayerPlus.register();
        WorldPlus.register();
        MiscPlus.register();
        ALL.sort(Comparator.comparing(m -> m.name));
        NyxelClient.LOG.info("Nyxel: zaladowano {} modulow", ALL.size());
    }

    public static <M extends Mod> M reg(M m) { ALL.add(m); return m; }

    public static Mod get(String name) {
        for (Mod m : ALL) if (m.name.equalsIgnoreCase(name)) return m;
        return null;
    }

    public static List<Mod> in(Category c) {
        List<Mod> l = new ArrayList<>();
        for (Mod m : ALL) if (m.category == c) l.add(m);
        return l;
    }

    public static void panic() { for (Mod m : ALL) if (m.enabled) m.setEnabled(false); }

    public static void tick() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        pollKeys();
        for (Mod m : ALL) {
            if (!m.enabled) continue;
            try { m.onTick(); } catch (Throwable t) { NyxelClient.LOG.error("Blad w {}", m.name, t); }
        }
    }

    private static void pollKeys() {
        long h = mc.method_22683().method_4490();
        boolean free = mc.field_1755 == null;
        for (int k = 32; k < keyPrev.length; k++) {
            boolean used = k == guiKey;
            if (!used) for (Mod m : ALL) if (m.bind == k) { used = true; break; }
            if (!used) { keyPrev[k] = false; continue; }
            boolean down = GLFW.glfwGetKey(h, k) == GLFW.GLFW_PRESS;
            if (down && !keyPrev[k] && free) {
                if (k == guiKey) mc.method_1507(new ClickGuiScreen());
                else for (Mod m : ALL) if (m.bind == k) m.toggle();
            }
            keyPrev[k] = down;
        }
    }

    public static void renderHud(class_332 ctx) {
        if (mc.field_1724 == null || mc.field_1690.field_1842) return;
        for (Mod m : ALL) if (m.enabled) {
            try { m.onHud(ctx); } catch (Throwable t) { NyxelClient.LOG.error("HUD {}", m.name, t); }
        }
    }
}
