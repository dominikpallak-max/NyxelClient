package dev.nyxel.mixin;

import dev.nyxel.modules.RenderModules;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** ESP (glow) + Freelook (przechwycenie ruchu myszy). */
@Mixin(class_1297.class)
public abstract class EntityMixin {
    @Inject(method = "isGlowing", at = @At("RETURN"), cancellable = true)
    private void nyxel$glow(CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValueZ() && RenderModules.ESP.shouldGlow((class_1297) (Object) this)) {
            cir.setReturnValue(true);
        }
    }

    /** Entity.changeLookDirection(double, double) = method_5872. require=0: zla nazwa nie wywali gry, tylko wylaczy Freelook. */
    @Inject(method = "method_5872", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private void nyxel$freelook(double dx, double dy, CallbackInfo ci) {
        if (RenderModules.Freelook.active && (Object) this == class_310.method_1551().field_1724) {
            RenderModules.Freelook.rotate(dx, dy);
            ci.cancel();
        }
    }
}
