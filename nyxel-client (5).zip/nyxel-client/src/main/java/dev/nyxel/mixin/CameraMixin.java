package dev.nyxel.mixin;

import dev.nyxel.modules.RenderModules;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Freelook: po aktualizacji kamery nadpisuje jej rotacje (yaw/pitch niezalezne od gracza). */
@Mixin(class_4184.class)
public abstract class CameraMixin {
    /** Camera.setRotation(float yaw, float pitch) = method_19325 */
    @Shadow(remap = false) protected abstract void method_19325(float yaw, float pitch);

    /** Camera.update(...) = method_19321 */
    @Inject(method = "method_19321", at = @At("TAIL"), remap = false, require = 0)
    private void nyxel$cam(CallbackInfo ci) {
        if (RenderModules.Freelook.active) method_19325(RenderModules.Freelook.camYaw, RenderModules.Freelook.camPitch);
    }
}
