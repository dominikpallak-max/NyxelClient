package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import java.util.*;

public final class MiscPlus {
    private MiscPlus() {}

    public static void register() {
        ModuleManager.reg(new VisualRange());
        ModuleManager.reg(new DeathCoords());
        ModuleManager.reg(new AutoLogin());
        ModuleManager.reg(new AutoReply());
        ModuleManager.reg(new AutoTPA());
        ModuleManager.reg(new Twerk());
        ModuleManager.reg(new Spinbot());
        ModuleManager.reg(new Derp());
        ModuleManager.reg(new ShareCoords());
        ModuleManager.reg(new DropAll());
        ModuleManager.reg(new AutoCommand());
        ModuleManager.reg(new CycleHotbar());
    }

    public static class VisualRange extends Mod {
        private final Set<UUID> known = new HashSet<>();
        public VisualRange() { super("VisualRange", "Alert na czacie, gdy gracz wejdzie/wyjdzie z zasiegu renderu", Category.MISC); }
        @Override public void onEnable() { known.clear(); }
        @Override public void onTick() {
            if (mc.field_1724.field_6012 % 10 != 0) return;
            Set<UUID> now = new HashSet<>();
            for (class_1657 p : mc.field_1687.method_18456()) {
                if (p == mc.field_1724) continue;
                now.add(p.method_5667());
                if (known.add(p.method_5667()))
                    Util.info("§a+ §f" + p.method_5477().getString() + " §7(" + (int) mc.field_1724.method_5739(p) + "m)");
            }
            known.removeIf(u -> {
                if (now.contains(u)) return false;
                Util.info("§c- §fgracz opuscil zasieg");
                return true;
            });
        }
    }

    public static class DeathCoords extends Mod {
        boolean was;
        public DeathCoords() { super("DeathCoords", "Zapisuje na czacie miejsce smierci", Category.MISC); }
        @Override public void onTick() {
            boolean dead = mc.field_1724.method_29504();
            if (dead && !was) Util.info(String.format("§cSmierc na §fX=%.0f Y=%.0f Z=%.0f", mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()));
            was = dead;
        }
    }

    public static class AutoLogin extends Mod {
        final Setting.Str command = str("Command", "/login haslo");
        final Setting.Num delay = numI("DelayTicks", 60, 20, 400);
        public AutoLogin() { super("AutoLogin", "Wysyla komende logowania po wejsciu na serwer (.set AutoLogin Command /login x)", Category.MISC); }
        @Override public void onTick() { if (mc.field_1724.field_6012 == delay.i()) Util.say(command.get()); }
    }

    public static class AutoReply extends Mod {
        final Setting.Str reply = str("Reply", "Nie ma mnie, wroce pozniej");
        final Setting.Num cooldown = numI("CooldownSec", 20, 5, 300);
        long last;
        public AutoReply() {
            super("AutoReply", "Odpisuje, gdy ktos napisze twoj nick (wiadomosci systemowe/plugin chat)", Category.MISC);
            ClientReceiveMessageEvents.GAME.register((msg, overlay) -> {
                if (!enabled || overlay || mc.field_1724 == null) return;
                String s = msg.getString();
                if (s.contains(reply.get()) || !s.contains(mc.field_1724.method_5477().getString())) return;
                long now = System.currentTimeMillis();
                if (now - last < cooldown.i() * 1000L) return;
                last = now;
                Util.say(reply.get());
            });
        }
    }

    public static class AutoTPA extends Mod {
        final Setting.Bool onlyFriends = bool("OnlyFriends", true);
        long last;
        public AutoTPA() {
            super("AutoTPA", "Akceptuje prosby o teleport (domyslnie tylko od przyjaciol)", Category.MISC);
            ClientReceiveMessageEvents.GAME.register((msg, overlay) -> {
                if (!enabled || overlay || mc.field_1724 == null) return;
                String s = msg.getString(), l = s.toLowerCase();
                if (!(l.contains("tpa") || l.contains("teleport"))) return;
                if (onlyFriends.get() && Config.friends.stream().noneMatch(s::contains)) return;
                long now = System.currentTimeMillis();
                if (now - last < 3000) return;
                last = now;
                Util.say("/tpaccept");
            });
        }
    }

    public static class Twerk extends Mod {
        final Setting.Num speed = numI("Period", 4, 2, 20);
        public Twerk() { super("Twerk", "Szybko przysiadasz i wstajesz", Category.MISC); }
        @Override public void onTick() { mc.field_1690.field_1832.method_23481(mc.field_1724.field_6012 % speed.i() < speed.i() / 2); }
        @Override public void onDisable() { mc.field_1690.field_1832.method_23481(false); }
    }

    public static class Spinbot extends Mod {
        final Setting.Num speed = num("Speed", 30, 5, 90);
        final Setting.Bool pitch = bool("PitchDown", false);
        public Spinbot() { super("Spinbot", "Kreci glowa (inni widza twoj obrot)", Category.MISC); }
        @Override public void onTick() {
            mc.field_1724.method_36456(mc.field_1724.method_36454() + speed.f());
            if (pitch.get()) mc.field_1724.method_36457(90f);
        }
    }

    public static class Derp extends Mod {
        final Random rnd = new Random();
        public Derp() { super("Derp", "Losowe ruchy glowa", Category.MISC); }
        @Override public void onTick() {
            mc.field_1724.method_36456(rnd.nextFloat() * 360f);
            mc.field_1724.method_36457((rnd.nextFloat() - 0.5f) * 180f);
        }
    }

    public static class ShareCoords extends OneShot {
        public ShareCoords() { super("ShareCoords", "Wysyla swoje koordynaty na czat", Category.MISC); }
        @Override protected void run() {
            Util.say(String.format("Moje koordy: %.0f %.0f %.0f", mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()));
        }
    }

    public static class DropAll extends OneShot {
        public DropAll() { super("DropAll", "Wyrzuca caly ekwipunek (uwaga!)", Category.MISC); }
        @Override protected void run() {
            for (int i = 0; i < 36; i++)
                if (!mc.field_1724.method_31548().method_5438(i).method_7960())
                    mc.field_1761.method_2906(0, Util.screenSlot(i), 1, class_1713.field_7795, mc.field_1724);
        }
    }

    public static class AutoCommand extends Mod {
        final Setting.Str command = str("Command", "/sethome");
        final Setting.Num delay = numI("DelayTicks", 600, 20, 12000);
        public AutoCommand() { super("AutoCommand", "Wysyla komende co jakis czas (.set AutoCommand Command /x)", Category.MISC); }
        @Override public void onTick() { if (mc.field_1724.field_6012 % delay.i() == 0) Util.say(command.get()); }
    }

    public static class CycleHotbar extends Mod {
        final Setting.Num delay = numI("DelayTicks", 10, 1, 100);
        public CycleHotbar() { super("CycleHotbar", "Przelacza sloty hotbara po kolei", Category.MISC); }
        @Override public void onTick() {
            if (mc.field_1724.field_6012 % delay.i() == 0)
                mc.field_1724.method_31548().method_61496((mc.field_1724.method_31548().method_67532() + 1) % 9);
        }
    }
}
