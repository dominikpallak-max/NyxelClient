package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import org.lwjgl.glfw.GLFW;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_465;
import net.minecraft.class_471;
import net.minecraft.class_7923;

public final class PlayerPlus {
    private PlayerPlus() {}

    public static void register() {
        ModuleManager.reg(new AutoReplenish());
        ModuleManager.reg(new AutoDrop());
        ModuleManager.reg(new XPThrower());
        ModuleManager.reg(new InvMove());
        ModuleManager.reg(new AutoMine());
        ModuleManager.reg(new AutoUse());
        ModuleManager.reg(new RotationLock());
        ModuleManager.reg(new OffhandSwap());
    }

    public static class AutoReplenish extends Mod {
        final Setting.Num threshold = numI("Threshold", 8, 1, 32);
        int timer;
        public AutoReplenish() { super("AutoReplenish", "Uzupelnia konczace sie stacki w hotbarze", Category.PLAYER); }
        @Override public void onTick() {
            if (timer-- > 0 || mc.field_1755 != null) return;
            for (int i = 0; i < 9; i++) {
                class_1799 h = mc.field_1724.method_31548().method_5438(i);
                if (h.method_7960() || !h.method_7946() || h.method_7947() > threshold.i() || h.method_7947() >= h.method_7914()) continue;
                for (int j = 9; j < 36; j++) {
                    class_1799 s = mc.field_1724.method_31548().method_5438(j);
                    if (!s.method_7960() && class_1799.method_31577(h, s)) {
                        mc.field_1761.method_2906(0, j, i, class_1713.field_7791, mc.field_1724);
                        timer = 4;
                        return;
                    }
                }
            }
        }
    }

    public static class AutoDrop extends Mod {
        final Setting.Str items = str("Items", "dirt,cobblestone,gravel,rotten_flesh,spider_eye,andesite,diorite,granite");
        final Setting.Num delay = numI("DelayTicks", 2, 0, 20);
        int timer;
        public AutoDrop() { super("AutoDrop", "Wyrzuca niechciane przedmioty (.set AutoDrop Items dirt,gravel)", Category.PLAYER); }
        @Override public void onTick() {
            if (timer-- > 0 || mc.field_1755 != null) return;
            Set<String> junk = new HashSet<>(Arrays.asList(items.get().toLowerCase().replace(" ", "").split(",")));
            for (int i = 0; i < 36; i++) {
                class_1799 s = mc.field_1724.method_31548().method_5438(i);
                if (s.method_7960()) continue;
                if (junk.contains(class_7923.field_41178.method_10221(s.method_7909()).method_12832())) {
                    mc.field_1761.method_2906(0, Util.screenSlot(i), 1, class_1713.field_7795, mc.field_1724);
                    timer = delay.i();
                    return;
                }
            }
        }
    }

    public static class XPThrower extends Mod {
        final Setting.Num delay = numI("DelayTicks", 3, 1, 20);
        int prev = -1;
        public XPThrower() { super("XPThrower", "Rzuca butelki XP w dol (naprawia ekwipunek)", Category.PLAYER); }
        @Override public void onEnable() { prev = -1; }
        @Override public void onDisable() { if (prev >= 0 && mc.field_1724 != null) mc.field_1724.method_31548().method_61496(prev); prev = -1; }
        @Override public void onTick() {
            int s = Util.findHotbar(i -> i.method_31574(class_1802.field_8287));
            if (s < 0) return;
            if (prev < 0) prev = mc.field_1724.method_31548().method_67532();
            mc.field_1724.method_31548().method_61496(s);
            mc.field_1724.method_36457(90f);
            if (mc.field_1724.field_6012 % delay.i() == 0) Util.useItem(s);
        }
    }

    public static class InvMove extends Mod {
        public InvMove() { super("InvMove", "Ruch (WASD, skok) przy otwartym ekwipunku", Category.PLAYER); }
        private static void sync(long h, class_304 k) {
            int code = class_3675.method_15981(k.method_1428()).method_1444();
            k.method_23481(GLFW.glfwGetKey(h, code) == GLFW.GLFW_PRESS);
        }
        @Override public void onTick() {
            if (!(mc.field_1755 instanceof class_465<?>) || mc.field_1755 instanceof class_471) return;
            long h = mc.method_22683().method_4490();
            sync(h, mc.field_1690.field_1894); sync(h, mc.field_1690.field_1881);
            sync(h, mc.field_1690.field_1913); sync(h, mc.field_1690.field_1849); sync(h, mc.field_1690.field_1903);
        }
    }

    public static class AutoMine extends Mod {
        public AutoMine() { super("AutoMine", "Trzyma LPM za ciebie (kopanie/bicie)", Category.PLAYER); }
        @Override public void onTick() { mc.field_1690.field_1886.method_23481(true); }
        @Override public void onDisable() { mc.field_1690.field_1886.method_23481(false); }
    }

    public static class AutoUse extends Mod {
        public AutoUse() { super("AutoUse", "Trzyma PPM za ciebie (jedzenie, luk, stawianie)", Category.PLAYER); }
        @Override public void onTick() { mc.field_1690.field_1904.method_23481(true); }
        @Override public void onDisable() { mc.field_1690.field_1904.method_23481(false); }
    }

    public static class RotationLock extends Mod {
        final Setting.Num step = num("YawStep", 45, 15, 90);
        final Setting.Bool pitch = bool("LockPitch", false);
        public RotationLock() { super("RotationLock", "Zaokragla yaw do stalych katow (prosta jazda/budowanie)", Category.PLAYER); }
        @Override public void onTick() {
            float st = step.f();
            mc.field_1724.method_36456(Math.round(mc.field_1724.method_36454() / st) * st);
            if (pitch.get()) mc.field_1724.method_36457(0f);
        }
    }

    public static class OffhandSwap extends OneShot {
        public OffhandSwap() { super("OffhandSwap", "Zamienia przedmiot z reki z druga reka (bind!)", Category.PLAYER); }
        @Override protected void run() {
            mc.field_1761.method_2906(0, 36 + mc.field_1724.method_31548().method_67532(), 40, class_1713.field_7791, mc.field_1724);
        }
    }
}
