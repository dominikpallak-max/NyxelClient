package dev.nyxel.modules;

import dev.nyxel.core.*;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1429;
import net.minecraft.class_1542;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_332;
import dev.nyxel.util.Util;

public final class RenderModules {
    private RenderModules() {}

    public static void register() {
        ModuleManager.reg(new ESP());
        ModuleManager.reg(new Fullbright());
        ModuleManager.reg(new Freelook());
        ModuleManager.reg(new Tracers());
    }

    public static class ESP extends Mod {
        static ESP inst;
        final Setting.Bool players = bool("Players", true), hostile = bool("Hostile", true),
                animals = bool("Animals", false), items = bool("Items", true);
        public ESP() { super("ESP", "Kontur encji widoczny przez sciany", Category.RENDER); inst = this; }
        /** Wolane z EntityMixin. */
        public static boolean shouldGlow(class_1297 e) {
            if (inst == null || !inst.enabled || e == mc.field_1724) return false;
            if (e instanceof class_1657) return inst.players.get();
            if (e instanceof class_1588) return inst.hostile.get();
            if (e instanceof class_1429) return inst.animals.get();
            if (e instanceof class_1542) return inst.items.get();
            return false;
        }
    }

    public static class Fullbright extends Mod {
        public Fullbright() { super("Fullbright", "Pelna jasnosc (nocne widzenie po stronie klienta)", Category.RENDER); }
        @Override public void onTick() {
            mc.field_1724.method_6092(new class_1293(class_1294.field_5925, 400, 0, false, false, false));
        }
        @Override public void onDisable() { if (mc.field_1724 != null) mc.field_1724.method_6016(class_1294.field_5925); }
    }

    /** Freelook: kamera obraca sie niezaleznie od gracza. Czysto kliencki - serwer nie dostaje zadnych zmian rotacji. */
    public static class Freelook extends Mod {
        public static volatile boolean active;
        public static float camYaw, camPitch;

        public Freelook() { super("Freelook", "Rozgladasz sie bez zmiany kierunku ruchu/rotacji gracza", Category.RENDER); }

        @Override public void onEnable() {
            if (mc.field_1724 == null) return;
            camYaw = mc.field_1724.method_36454();
            camPitch = mc.field_1724.method_36455();
            active = true;
        }

        @Override public void onDisable() {
            active = false;
        }

        /** Wolane z EntityMixin zamiast obrotu gracza (dx/dy = surowy ruch myszy). */
        public static void rotate(double dx, double dy) {
            camYaw += (float) dx * 0.15f;
            camPitch = Math.max(-90f, Math.min(90f, camPitch + (float) dy * 0.15f));
        }
    }

    /** Tracers: linie od srodka ekranu do graczy/mobow (rysowane na ekranie, wiec bez ryzyka dla serwera). */
    public static class Tracers extends Mod {
        final Setting.Bool players = bool("Players", true), hostile = bool("Hostile", false), animals = bool("Animals", false);
        final Setting.Num dist = numI("MaxDistance", 128, 8, 512);
        final Setting.Num fov = numI("Fov", 70, 30, 110); // ustaw tak samo jak FOV w opcjach gry
        public Tracers() { super("Tracers", "Linie do graczy (i mobow) na ekranie", Category.RENDER); }

        @Override public void onHud(class_332 ctx) {
            if (mc.field_1687 == null) return;
            int w = ctx.method_51421(), h = ctx.method_51443();
            float yawD = Freelook.active ? Freelook.camYaw : mc.field_1724.method_36454();
            float pitchD = Freelook.active ? Freelook.camPitch : mc.field_1724.method_36455();
            double yaw = Math.toRadians(yawD), pitch = Math.toRadians(pitchD);
            double cp = Math.cos(pitch), sp = Math.sin(pitch), cy = Math.cos(yaw), sy = Math.sin(yaw);
            double fx = -sy * cp, fy = -sp, fz = cy * cp;      // przod
            double rx = -cy, ry = 0, rz = -sy;                  // prawo
            double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx; // gora = prawo x przod
            double scale = (h / 2.0) / Math.tan(Math.toRadians(fov.d()) / 2.0);
            var eye = mc.field_1724.method_33571();
            for (class_1297 e : mc.field_1687.method_18112()) {
                if (e == mc.field_1724 || mc.field_1724.method_5739(e) > dist.d()) continue;
                int color;
                if (e instanceof class_1657 p) {
                    if (!players.get()) continue;
                    color = Util.isFriend(p) ? 0xFF55FF55 : 0xFFC77DFF;
                } else if (e instanceof class_1588) {
                    if (!hostile.get()) continue;
                    color = 0xFFFF5555;
                } else if (e instanceof class_1429) {
                    if (!animals.get()) continue;
                    color = 0xFFFFFF55;
                } else continue;
                double dx = e.method_23317() - eye.field_1352, dy = e.method_23318() + 0.9 - eye.field_1351, dz = e.method_23321() - eye.field_1350;
                double x = dx * rx + dy * ry + dz * rz, y = dx * ux + dy * uy + dz * uz, z = dx * fx + dy * fy + dz * fz;
                if (z < 0.05) { x = -x; y = -y; z = 0.05; }   // za plecami: kieruj linie ku krawedzi
                double sx = w / 2.0 + x / z * scale, sy2 = h / 2.0 - y / z * scale;
                sx = Math.max(2, Math.min(w - 2, sx)); sy2 = Math.max(2, Math.min(h - 2, sy2));
                double lx = sx - w / 2.0, ly = sy2 - h / 2.0;
                int n = (int) Math.max(Math.abs(lx), Math.abs(ly));
                for (int i = 0; i <= n; i += 1) {
                    int px = (int) (w / 2.0 + lx * i / Math.max(1, n)), py = (int) (h / 2.0 + ly * i / Math.max(1, n));
                    ctx.method_25294(px, py, px + 1, py + 1, color);
                }
            }
        }
    }
}
