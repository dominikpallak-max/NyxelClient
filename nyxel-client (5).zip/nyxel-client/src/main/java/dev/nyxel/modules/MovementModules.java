package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import net.minecraft.class_1324;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_5134;

public final class MovementModules {
    private MovementModules() {}

    public static void register() {
        ModuleManager.reg(new Sprint());
        ModuleManager.reg(new Flight());
        ModuleManager.reg(new Speed());
        ModuleManager.reg(new Step());
        ModuleManager.reg(new NoFall());
        ModuleManager.reg(new Spider());
        ModuleManager.reg(new AutoJump());
        ModuleManager.reg(new Parkour());
        ModuleManager.reg(new Glide());
        ModuleManager.reg(new AirJump());
        ModuleManager.reg(new AntiVoid());
        ModuleManager.reg(new FastClimb());
    }

    public static class Sprint extends Mod {
        public Sprint() { super("Sprint", "Zawsze biegniesz do przodu", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.field_1690.field_1894.method_1434() && !mc.field_1724.field_5976
                    && !mc.field_1724.method_5715() && mc.field_1724.method_7344().method_7586() > 6)
                mc.field_1724.method_5728(true);
        }
    }

    public static class Flight extends Mod {
        final Setting.Mode mode = mode("Mode", "Velocity", "Velocity", "Abilities");
        final Setting.Num speed = num("Speed", 1.0, 0.1, 5);
        public Flight() { super("Flight", "Latanie", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mode.is("Abilities")) {
                mc.field_1724.method_31549().field_7478 = true;
                mc.field_1724.method_31549().field_7479 = true;
                mc.field_1724.method_31549().method_7248(speed.f() * 0.05f);
            } else {
                double vy = mc.field_1690.field_1903.method_1434() ? speed.d() * 0.5 : mc.field_1690.field_1832.method_1434() ? -speed.d() * 0.5 : 0;
                mc.field_1724.method_18800(0, vy, 0);
                Util.setHorizontalSpeed(speed.d() * 0.6);
            }
        }
        @Override public void onDisable() {
            if (mc.field_1724 != null && !mc.field_1724.method_68878() && !mc.field_1724.method_7325()) {
                mc.field_1724.method_31549().field_7478 = false;
                mc.field_1724.method_31549().field_7479 = false;
                mc.field_1724.method_31549().method_7248(0.05f);
            }
        }
    }

    public static class Speed extends Mod {
        final Setting.Num speed = num("Speed", 1.4, 0.5, 4);
        final Setting.Bool onlyGround = bool("OnlyOnGround", false);
        public Speed() { super("Speed", "Szybszy ruch poziomy", Category.MOVEMENT); }
        @Override public void onTick() {
            if (!Util.moving() || (onlyGround.get() && !mc.field_1724.method_24828())) return;
            Util.setHorizontalSpeed(0.2873 * speed.d());
        }
    }

    public static class Step extends Mod {
        final Setting.Num height = num("Height", 1.0, 0.6, 2.5);
        public Step() { super("Step", "Wchodzisz na wyzsze bloki bez skakania", Category.MOVEMENT); }
        @Override public void onTick() {
            class_1324 a = mc.field_1724.method_5996(class_5134.field_47761);
            if (a != null) a.method_6192(height.d());
        }
        @Override public void onDisable() {
            if (mc.field_1724 == null) return;
            class_1324 a = mc.field_1724.method_5996(class_5134.field_47761);
            if (a != null) a.method_6192(0.6);
        }
    }

    public static class NoFall extends Mod {
        public NoFall() { super("NoFall", "Brak obrazen od upadku", Category.MOVEMENT); }
        @Override public void onTick() {
            if (!mc.field_1724.method_24828() && mc.field_1724.method_18798().field_1351 < -0.5 && !mc.field_1724.method_6128())
                mc.method_1562().method_52787(new class_2828.class_5911(true, false));
        }
    }

    public static class Spider extends Mod {
        public Spider() { super("Spider", "Wspinasz sie po scianach", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.field_1724.field_5976 && Util.moving()) {
                class_243 v = mc.field_1724.method_18798();
                mc.field_1724.method_18800(v.field_1352, 0.2, v.field_1350);
            }
        }
    }

    public static class AutoJump extends Mod {
        public AutoJump() { super("AutoJump", "Skacze automatycznie podczas ruchu", Category.MOVEMENT); }
        @Override public void onTick() { if (mc.field_1724.method_24828() && Util.moving()) mc.field_1724.method_6043(); }
    }

    public static class Parkour extends Mod {
        public Parkour() { super("Parkour", "Skacze na krawedzi bloku", Category.MOVEMENT); }
        @Override public void onTick() {
            if (!mc.field_1724.method_24828() || mc.field_1724.method_5715() || mc.field_1690.field_1903.method_1434()) return;
            if (mc.field_1687.method_8587(mc.field_1724, mc.field_1724.method_5829().method_989(0, -0.5, 0).method_1009(-0.001, 0, -0.001)))
                mc.field_1724.method_6043();
        }
    }

    public static class Glide extends Mod {
        final Setting.Num fall = num("FallSpeed", 0.1, 0.01, 0.5);
        public Glide() { super("Glide", "Powolne opadanie", Category.MOVEMENT); }
        @Override public void onTick() {
            class_243 v = mc.field_1724.method_18798();
            if (!mc.field_1724.method_24828() && v.field_1351 < -fall.d()) mc.field_1724.method_18800(v.field_1352, -fall.d(), v.field_1350);
        }
    }

    public static class AirJump extends Mod {
        boolean prev;
        public AirJump() { super("AirJump", "Skok w powietrzu", Category.MOVEMENT); }
        @Override public void onTick() {
            boolean j = mc.field_1690.field_1903.method_1434();
            if (j && !prev && !mc.field_1724.method_24828()) mc.field_1724.method_6043();
            prev = j;
        }
    }

    public static class AntiVoid extends Mod {
        public AntiVoid() { super("AntiVoid", "Wyrzuca w gore przed wpadnieciem w pustke", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.field_1724.method_23318() < mc.field_1687.method_31607() + 1) {
                class_243 v = mc.field_1724.method_18798();
                mc.field_1724.method_18800(v.field_1352, 1.0, v.field_1350);
            }
        }
    }

    public static class FastClimb extends Mod {
        public FastClimb() { super("FastClimb", "Szybsze wspinanie po drabinach", Category.MOVEMENT); }
        @Override public void onTick() {
            if (mc.field_1724.method_6101() && Util.moving()) {
                class_243 v = mc.field_1724.method_18798();
                mc.field_1724.method_18800(v.field_1352, 0.25, v.field_1350);
            }
        }
    }
}
