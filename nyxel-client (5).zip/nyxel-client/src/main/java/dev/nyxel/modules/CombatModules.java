package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3966;

public final class CombatModules {
    private CombatModules() {}

    public static void register() {
        ModuleManager.reg(new KillAura());
        ModuleManager.reg(new TriggerBot());
        ModuleManager.reg(new Aimbot());
        ModuleManager.reg(new AutoTotem());
        ModuleManager.reg(new AutoArmor());
        ModuleManager.reg(new AutoTrap());
        ModuleManager.reg(new SelfTrap());
        ModuleManager.reg(new Surround());
        ModuleManager.reg(new AutoWeb());
    }

    public static class KillAura extends Mod {
        final Setting.Num range = num("Range", 4.2, 1, 6), cooldown = num("Cooldown", 0.92, 0, 1);
        final Setting.Bool players = bool("Players", true), hostile = bool("Hostile", true),
                animals = bool("Animals", false), rotate = bool("Rotate", true), walls = bool("ThroughWalls", false);
        final Setting.Mode sort = mode("Sort", "Distance", "Distance", "Health");
        public KillAura() { super("KillAura", "Automatycznie atakuje pobliskie cele", Category.COMBAT); }
        @Override public void onTick() {
            var list = Util.targets(range.d(), players.get(), hostile.get(), animals.get(), walls.get(), sort.is("Health"));
            if (list.isEmpty()) return;
            class_1309 t = list.get(0);
            if (rotate.get()) Util.lookAt(t.method_5829().method_1005());
            if (mc.field_1724.method_7261(0f) < cooldown.f()) return;
            mc.field_1761.method_2918(mc.field_1724, t);
            mc.field_1724.method_6104(class_1268.field_5808);
        }
    }

    public static class TriggerBot extends Mod {
        final Setting.Num cooldown = num("Cooldown", 0.95, 0, 1);
        final Setting.Bool players = bool("Players", true), mobs = bool("Mobs", true);
        public TriggerBot() { super("TriggerBot", "Bije to, na co patrzysz, gdy bron jest naladowana", Category.COMBAT); }
        @Override public void onTick() {
            if (mc.field_1755 != null || !(mc.field_1765 instanceof class_3966 r)) return;
            class_1297 e = r.method_17782();
            if (!(e instanceof class_1309 le) || !le.method_5805()) return;
            if (e instanceof class_1657 p) { if (!players.get() || Util.isFriend(p)) return; } else if (!mobs.get()) return;
            if (mc.field_1724.method_7261(0f) < cooldown.f()) return;
            mc.field_1761.method_2918(mc.field_1724, e);
            mc.field_1724.method_6104(class_1268.field_5808);
        }
    }

    public static class Aimbot extends Mod {
        final Setting.Num range = num("Range", 6, 1, 20);
        final Setting.Bool onlyAttack = bool("OnlyWhenAttacking", true);
        public Aimbot() { super("Aimbot", "Celuje w najblizszego gracza", Category.COMBAT); }
        @Override public void onTick() {
            if (onlyAttack.get() && !mc.field_1690.field_1886.method_1434()) return;
            class_1657 p = Util.nearestPlayer(range.d());
            if (p != null) Util.lookAt(p.method_5829().method_1005());
        }
    }

    public static class AutoTotem extends Mod {
        final Setting.Mode mode = mode("Mode", "Smart", "Smart", "Always");
        final Setting.Num health = num("Health", 10, 1, 20);
        final Setting.Num delay = numI("Delay", 0, 0, 20);
        int timer;
        public AutoTotem() { super("AutoTotem", "Wklada totem do drugiej reki", Category.COMBAT); }
        @Override public void onTick() {
            if (timer > 0) { timer--; return; }
            if (mc.field_1755 != null || mc.field_1724.method_6079().method_31574(class_1802.field_8288)) return;
            if (mode.is("Smart") && mc.field_1724.method_6032() + mc.field_1724.method_6067() > health.d()) return;
            for (int i = 0; i < 36; i++) {
                if (mc.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8288)) {
                    mc.field_1761.method_2906(0, Util.screenSlot(i), 40, class_1713.field_7791, mc.field_1724);
                    timer = delay.i();
                    return;
                }
            }
        }
    }

    public static class AutoArmor extends Mod {
        final Setting.Num delay = numI("Delay", 4, 0, 20);
        int timer;
        public AutoArmor() { super("AutoArmor", "Zaklada brakujace elementy zbroi", Category.COMBAT); }
        @Override public void onTick() {
            if (timer > 0) { timer--; return; }
            if (mc.field_1755 != null) return;
            for (int i = 0; i < 36; i++) {
                class_1799 s = mc.field_1724.method_31548().method_5438(i);
                if (s.method_7960()) continue;
                class_1304 es = mc.field_1724.method_32326(s);
                if (!es.method_46643() || !mc.field_1724.method_6118(es).method_7960()) continue;
                mc.field_1761.method_2906(0, Util.screenSlot(i), 0, class_1713.field_7794, mc.field_1724);
                timer = delay.i();
                return;
            }
        }
    }

    /** Wspolna logika stawiania listy blokow z limitem na tick. */
    abstract static class Placer extends Mod {
        final Setting.Num perTick = numI("BlocksPerTick", 2, 1, 6);
        final Setting.Bool rotate = bool("Rotate", false);
        boolean warned;
        Placer(String n, String d) { super(n, d, Category.COMBAT); }
        @Override public void onEnable() { warned = false; }
        abstract net.minecraft.class_1792 item();
        void placeAll(List<class_2338> plan) {
            int slot = Util.findHotbar(s -> s.method_31574(item()));
            if (slot < 0) {
                if (!warned) { Util.info("§cBrak " + item().method_63680().getString() + " w hotbarze"); warned = true; }
                return;
            }
            int n = 0;
            for (class_2338 p : plan) {
                if (n >= perTick.i()) break;
                if (Util.place(p, slot, rotate.get())) n++;
            }
        }
    }

    static List<class_2338> ring(class_2338 f, boolean feet, boolean head, boolean top) {
        List<class_2338> l = new ArrayList<>();
        if (feet) for (class_2350 d : class_2350.class_2353.field_11062) l.add(f.method_10093(d));
        if (head) for (class_2350 d : class_2350.class_2353.field_11062) l.add(f.method_10084().method_10093(d));
        if (top) l.add(f.method_10086(2));
        return l;
    }

    public static class AutoTrap extends Placer {
        final Setting.Num range = num("Range", 5, 1, 6);
        public AutoTrap() { super("AutoTrap", "Zamyka najblizszego gracza w obsydianie"); }
        net.minecraft.class_1792 item() { return class_1802.field_8281; }
        @Override public void onTick() {
            class_1657 t = Util.nearestPlayer(range.d());
            if (t != null) placeAll(ring(t.method_24515(), true, true, true));
        }
    }

    public static class SelfTrap extends Placer {
        public SelfTrap() { super("SelfTrap", "Zamyka ciebie w obsydianie (glowa + sufit)"); }
        net.minecraft.class_1792 item() { return class_1802.field_8281; }
        @Override public void onTick() { placeAll(ring(mc.field_1724.method_24515(), false, true, true)); }
    }

    public static class Surround extends Placer {
        public Surround() { super("Surround", "Obsydian wokol twoich stop"); }
        net.minecraft.class_1792 item() { return class_1802.field_8281; }
        @Override public void onTick() { placeAll(ring(mc.field_1724.method_24515(), true, false, false)); }
    }

    public static class AutoWeb extends Placer {
        final Setting.Num range = num("Range", 5, 1, 6);
        public AutoWeb() { super("AutoWeb", "Stawia pajeczyne na nogach i glowie celu"); }
        net.minecraft.class_1792 item() { return class_1802.field_8786; }
        @Override public void onTick() {
            class_1657 t = Util.nearestPlayer(range.d());
            if (t == null) return;
            placeAll(List.of(t.method_24515(), t.method_24515().method_10084()));
        }
    }
}
