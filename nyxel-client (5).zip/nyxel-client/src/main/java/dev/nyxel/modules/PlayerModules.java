package dev.nyxel.modules;

import dev.nyxel.core.*;
import java.util.Random;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_418;
import net.minecraft.class_9334;

public final class PlayerModules {
    private PlayerModules() {}

    public static void register() {
        ModuleManager.reg(new AutoEat());
        ModuleManager.reg(new AutoRespawn());
        ModuleManager.reg(new AntiAFK());
        ModuleManager.reg(new AutoTool());
        ModuleManager.reg(new AutoLog());
    }

    public static class AutoEat extends Mod {
        final Setting.Num hunger = numI("Hunger", 14, 1, 19);
        boolean eating; int prev;
        public AutoEat() { super("AutoEat", "Je jedzenie z hotbara, gdy jestes glodny", Category.PLAYER); }

        static boolean good(class_1799 s) {
            return s.method_57826(class_9334.field_50075) && !s.method_31574(class_1802.field_8511) && !s.method_31574(class_1802.field_8680)
                    && !s.method_31574(class_1802.field_8635) && !s.method_31574(class_1802.field_8323) && !s.method_31574(class_1802.field_8233)
                    && !s.method_31574(class_1802.field_8463) && !s.method_31574(class_1802.field_8367)
                    && !s.method_31574(class_1802.field_8766);
        }
        void stop() {
            mc.field_1690.field_1904.method_23481(false);
            if (eating) mc.field_1724.method_31548().method_61496(prev);
            eating = false;
        }
        @Override public void onDisable() { if (mc.field_1724 != null) stop(); }
        @Override public void onTick() {
            int h = mc.field_1724.method_7344().method_7586();
            if (!eating) {
                if (h > hunger.i() || mc.field_1755 != null) return;
                for (int i = 0; i < 9; i++) if (good(mc.field_1724.method_31548().method_5438(i))) {
                    prev = mc.field_1724.method_31548().method_67532();
                    mc.field_1724.method_31548().method_61496(i);
                    mc.field_1690.field_1904.method_23481(true);
                    eating = true;
                    return;
                }
            } else if (h >= 20 || !good(mc.field_1724.method_6047())) stop();
        }
    }

    public static class AutoRespawn extends Mod {
        public AutoRespawn() { super("AutoRespawn", "Automatycznie odradza po smierci", Category.PLAYER); }
        @Override public void onTick() {
            if (mc.field_1755 instanceof class_418 || mc.field_1724.method_29504()) mc.field_1724.method_7331();
        }
    }

    public static class AntiAFK extends Mod {
        final Setting.Num interval = numI("IntervalTicks", 80, 20, 600);
        final Random rnd = new Random();
        public AntiAFK() { super("AntiAFK", "Ruchy zapobiegajace kickowi za AFK", Category.PLAYER); }
        @Override public void onTick() {
            if (mc.field_1724.field_6012 % interval.i() != 0) return;
            mc.field_1724.method_36456(mc.field_1724.method_36454() + (rnd.nextFloat() - 0.5f) * 50f);
            if (mc.field_1724.method_24828()) mc.field_1724.method_6043();
            mc.field_1724.method_6104(net.minecraft.class_1268.field_5808);
        }
    }

    public static class AutoTool extends Mod {
        public AutoTool() { super("AutoTool", "Wybiera najlepsze narzedzie do kopanego bloku", Category.PLAYER); }
        @Override public void onTick() {
            if (!mc.field_1690.field_1886.method_1434() || mc.field_1755 != null) return;
            if (!(mc.field_1765 instanceof class_3965 r) || r.method_17783() != class_239.class_240.field_1332) return;
            class_2680 st = mc.field_1687.method_8320(r.method_17777());
            int best = mc.field_1724.method_31548().method_67532();
            float bs = mc.field_1724.method_31548().method_5438(best).method_7924(st);
            for (int i = 0; i < 9; i++) {
                float s = mc.field_1724.method_31548().method_5438(i).method_7924(st);
                if (s > bs + 0.1f) { bs = s; best = i; }
            }
            mc.field_1724.method_31548().method_61496(best);
        }
    }

    public static class AutoLog extends Mod {
        final Setting.Num health = num("Health", 6, 1, 19);
        public AutoLog() { super("AutoLog", "Wylogowuje, gdy zdrowie spadnie ponizej progu", Category.PLAYER); }
        @Override public void onTick() {
            if (mc.field_1724.method_6032() > health.d() || mc.method_1562() == null) return;
            setEnabled(false);
            mc.method_1562().method_48296().method_10747(class_2561.method_43470("[Nyxel] AutoLog: zdrowie " + (int) mc.field_1724.method_6032()));
        }
    }
}
