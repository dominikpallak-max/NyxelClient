package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.entity.*;
import net.minecraft.class_1747;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2601;
import net.minecraft.class_2609;
import net.minecraft.class_2614;
import net.minecraft.class_2627;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3719;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.*;

public final class WorldModules {
    private WorldModules() {}

    public static void register() {
        ModuleManager.reg(new StashFinder());
        ModuleManager.reg(new Nuker());
        ModuleManager.reg(new Scaffold());
    }

    /**
     * Skanuje zaladowane chunki i raportuje te z duza liczba pojemnikow (stashe).
     * Co liczy sie jako pojemnik ustawiasz w configu: opcje Blocks i Entities (id po przecinku, dopasowanie po fragmencie nazwy).
     * UWAGA: klient widzi tylko chunki wyslane przez serwer (render distance). RangeBlocks ogranicza skan z gory,
     * ale baza 1000 kratek dalej wyjdzie dopiero gdy dolecisz w jej okolice (wszystkie trafienia zapisuja sie do pliku).
     */
    public static class StashFinder extends Mod {
        public static final List<String> log = new ArrayList<>();
        final Setting.Num range = numI("RangeBlocks", 256, 16, 5000);
        final Setting.Num minContainers = numI("MinContainers", 4, 1, 200);
        final Setting.Str blocks = str("Blocks", "chest,barrel,shulker_box,hopper,dropper,dispenser,furnace,smoker,brewing_stand,crafter,decorated_pot,chiseled_bookshelf");
        final Setting.Str entities = str("Entities", "chest_minecart,hopper_minecart,item_frame,chest_boat");
        final Setting.Mode direction = mode("Direction", "Any", "Any", "North", "South", "East", "West", "NorthEast", "NorthWest", "SouthEast", "SouthWest");
        final Setting.Bool autoWalk = bool("AutoWalk", false); // idzie w wybranym kierunku (obraca gracza!)
        final Setting.Bool shulkerAlert = bool("ShulkerAlert", true);
        final Setting.Bool chat = bool("ChatAlert", true);
        final Setting.Bool save = bool("SaveToFile", true);
        private final Map<Long, Integer> seen = new HashMap<>();
        private Object lastWorld;
        private String blocksRaw = "", entitiesRaw = "";
        private String[] blockKeys = new String[0], entityKeys = new String[0];

        public StashFinder() { super("StashFinder", "Wykrywa chunki z duza iloscia skrzyn/beczek/shulkerow/itp (konfigurowalne)", Category.WORLD); }

        @Override public void onEnable() { seen.clear(); }

        /** Wektor kierunku {x, z} i yaw Minecrafta (poludnie=0, zachod=90, polnoc=180, wschod=-90). */
        private double[] dirVec() {
            return switch (direction.get()) {
                case "North" -> new double[]{0, -1, 180};
                case "South" -> new double[]{0, 1, 0};
                case "East" -> new double[]{1, 0, -90};
                case "West" -> new double[]{-1, 0, 90};
                case "NorthEast" -> new double[]{0.7071, -0.7071, -135};
                case "NorthWest" -> new double[]{-0.7071, -0.7071, 135};
                case "SouthEast" -> new double[]{0.7071, 0.7071, -45};
                case "SouthWest" -> new double[]{-0.7071, 0.7071, 45};
                default -> null;
            };
        }

        @Override public void onDisable() { if (autoWalk.get()) mc.field_1690.field_1894.method_23481(false); }

        private static String[] split(String raw) {
            List<String> l = new ArrayList<>();
            for (String t : raw.toLowerCase().split("[,;\\s]+")) if (!t.isBlank()) l.add(t.trim());
            return l.toArray(new String[0]);
        }

        private static boolean matches(String id, String[] keys) {
            for (String k : keys) if (id.contains(k)) return true;
            return false;
        }

        @Override public void onTick() {
            double[] dv = dirVec();
            if (autoWalk.get() && dv != null) {
                mc.field_1724.method_36456((float) dv[2]);
                mc.field_1690.field_1894.method_23481(true);
            }
            if (mc.field_1724.field_6012 % 40 != 0) return;
            if (lastWorld != mc.field_1687) { seen.clear(); lastWorld = mc.field_1687; }
            if (!blocks.get().equals(blocksRaw)) { blocksRaw = blocks.get(); blockKeys = split(blocksRaw); seen.clear(); }
            if (!entities.get().equals(entitiesRaw)) { entitiesRaw = entities.get(); entityKeys = split(entitiesRaw); seen.clear(); }

            int pcx = mc.field_1724.method_31477() >> 4, pcz = mc.field_1724.method_31479() >> 4;
            int r = Math.min(range.i() / 16 + 1, mc.field_1690.method_42503().method_41753() + 2);

            Map<Long, int[]> counts = new HashMap<>(); // klucz chunka -> {total, shulkers}

            for (int cx = pcx - r; cx <= pcx + r; cx++) {
                for (int cz = pcz - r; cz <= pcz + r; cz++) {
                    class_2818 chunk = mc.field_1687.method_2935().method_21730(cx, cz);
                    if (chunk == null) continue;
                    for (class_2586 be : chunk.method_12214().values()) {
                        String id = net.minecraft.class_7923.field_41175.method_10221(be.method_11010().method_26204()).method_12832();
                        if (!matches(id, blockKeys)) continue;
                        int[] c = counts.computeIfAbsent(key(cx, cz), k -> new int[2]);
                        c[0]++;
                        if (id.contains("shulker")) c[1]++;
                    }
                }
            }
            if (entityKeys.length > 0) {
                for (net.minecraft.class_1297 e : mc.field_1687.method_18112()) {
                    String id = net.minecraft.class_7923.field_41177.method_10221(e.method_5864()).method_12832();
                    if (!matches(id, entityKeys)) continue;
                    int[] c = counts.computeIfAbsent(key(e.method_24515().method_10263() >> 4, e.method_24515().method_10260() >> 4), k -> new int[2]);
                    c[0]++;
                }
            }

            for (Map.Entry<Long, int[]> en : counts.entrySet()) {
                int total = en.getValue()[0], shulkers = en.getValue()[1];
                if (!(total >= minContainers.i() || (shulkerAlert.get() && shulkers > 0))) continue;
                if (dv != null) {
                    double rx = (int) (en.getKey() >> 32) * 16 + 8 - mc.field_1724.method_23317();
                    double rz = (int) (long) en.getKey() * 16 + 8 - mc.field_1724.method_23321();
                    double len = Math.sqrt(rx * rx + rz * rz);
                    if (len > 24 && (rx * dv[0] + rz * dv[1]) / len < 0.7071 - 1e-6) continue; // poza sektorem 90 stopni
                }
                Integer prev = seen.get(en.getKey());
                if (prev != null && prev >= total) continue;
                seen.put(en.getKey(), total);
                report((int) (en.getKey() >> 32), (int) (long) en.getKey(), total, shulkers);
            }
        }

        private static long key(int cx, int cz) { return ((long) cx << 32) | (cz & 0xFFFFFFFFL); }

        private void report(int cx, int cz, int total, int shulkers) {
            int x = cx * 16 + 8, z = cz * 16 + 8;
            String line = String.format("Stash? X=%d Z=%d  pojemniki=%d shulkery=%d", x, z, total, shulkers);
            log.add(line);
            if (log.size() > 200) log.remove(0);
            if (chat.get()) Util.info("§d" + line);
            if (save.get()) {
                try {
                    String srv = mc.method_1558() != null ? mc.method_1558().field_3761 : "singleplayer";
                    var f = FabricLoader.getInstance().getConfigDir().resolve("nyxel/stashes.txt");
                    Files.createDirectories(f.getParent());
                    Files.writeString(f, srv + " | " + line + System.lineSeparator(),
                            StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                } catch (IOException ignored) {}
            }
        }
    }

    public static class Nuker extends Mod {
        final Setting.Num range = num("Range", 4, 1, 6);
        final Setting.Num perTick = numI("BlocksPerTick", 1, 1, 10);
        final Setting.Bool flatten = bool("OnlyAtOrAboveFeet", true);
        public Nuker() { super("Nuker", "Niszczy bloki wokol ciebie", Category.WORLD); }
        @Override public void onTick() {
            int r = (int) Math.ceil(range.d());
            class_2338 c = mc.field_1724.method_24515();
            class_243 eye = mc.field_1724.method_33571();
            List<class_2338> list = new ArrayList<>();
            for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
                class_2338 p = c.method_10069(x, y, z);
                if (flatten.get() && p.method_10264() < c.method_10264()) continue;
                if (eye.method_1022(class_243.method_24953(p)) > range.d()) continue;
                class_2680 s = mc.field_1687.method_8320(p);
                if (s.method_26215() || !s.method_26227().method_15769() || s.method_26214(mc.field_1687, p) < 0) continue;
                list.add(p);
            }
            list.sort(Comparator.comparingDouble(p -> eye.method_1025(class_243.method_24953(p))));
            int n = 0;
            for (class_2338 p : list) {
                if (n++ >= perTick.i()) break;
                if (mc.field_1724.method_68878()) mc.field_1761.method_2910(p, class_2350.field_11036);
                else mc.field_1761.method_2902(p, class_2350.field_11036);
                mc.field_1724.method_6104(net.minecraft.class_1268.field_5808);
            }
        }
    }

    public static class Scaffold extends Mod {
        final Setting.Bool rotate = bool("Rotate", false), tower = bool("Tower", true);
        public Scaffold() { super("Scaffold", "Stawia bloki pod toba podczas chodzenia", Category.WORLD); }
        @Override public void onTick() {
            int slot = Util.findHotbar(s -> s.method_7909() instanceof class_1747);
            if (slot < 0) return;
            class_2338 below = mc.field_1724.method_24515().method_10074();
            if (Util.place(below, slot, rotate.get()) && tower.get() && mc.field_1690.field_1903.method_1434() && !Util.moving()) {
                class_243 v = mc.field_1724.method_18798();
                mc.field_1724.method_18800(v.field_1352, 0.42, v.field_1350);
            }
        }
    }
}
