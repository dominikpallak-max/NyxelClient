package dev.nyxel.modules;

import dev.nyxel.core.*;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_476;
import java.util.Random;

public final class MiscModules {
    private MiscModules() {}

    public static void register() {
        ModuleManager.reg(new ChestStealer());
        ModuleManager.reg(new Spammer());
        ModuleManager.reg(new PlaceSound());
    }

    public static class ChestStealer extends Mod {
        final Setting.Num delay = numI("DelayTicks", 1, 0, 10);
        final Setting.Bool autoClose = bool("AutoClose", true);
        int timer;
        public ChestStealer() { super("ChestStealer", "Szybko zabiera wszystko z otwartej skrzyni", Category.MISC); }
        @Override public void onTick() {
            if (!(mc.field_1755 instanceof class_476 s)) return;
            if (timer-- > 0) return;
            class_1707 h = s.method_17577();
            int n = h.method_17388() * 9;
            for (int i = 0; i < n; i++) {
                if (!h.method_7611(i).method_7677().method_7960()) {
                    mc.field_1761.method_2906(h.field_7763, i, 0, class_1713.field_7794, mc.field_1724);
                    timer = delay.i();
                    return;
                }
            }
            if (autoClose.get()) mc.field_1724.method_7346();
        }
    }

    public static class Spammer extends Mod {
        final Setting.Str message = str("Message", "Nyxel Client na topie");
        final Setting.Num delay = numI("DelayTicks", 100, 20, 1200);
        final Setting.Bool suffix = bool("RandomSuffix", true);
        final Random rnd = new Random();
        public Spammer() { super("Spammer", "Wysyla wiadomosc na czat co jakis czas (.set Spammer Message ...)", Category.MISC); }
        @Override public void onTick() {
            if (mc.field_1724.field_6012 % delay.i() != 0 || mc.method_1562() == null) return;
            String m = message.get() + (suffix.get() ? " " + Integer.toString(rnd.nextInt(0xFFFF), 36) : "");
            if (m.startsWith("/")) mc.method_1562().method_45730(m.substring(1));
            else mc.method_1562().method_45729(m);
        }
    }

    /** Dziwny dzwiek przy stawianiu bloku. */
    public static class PlaceSound extends Mod {
        final Setting.Mode sound = mode("Sound", "Burp", "Burp", "Orb", "ArrowHit", "Anvil", "VillagerNo", "Egg", "Enderman", "Random");
        final Setting.Num volume = num("Volume", 1.0, 0.1, 2);
        final Setting.Num pitch = num("Pitch", 1.0, 0.5, 2);
        final Setting.Bool randomPitch = bool("RandomPitch", true);
        final Random rnd = new Random();

        public PlaceSound() {
            super("PlaceSound", "Odtwarza dzwiek przy stawianiu bloku", Category.MISC);
            UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
                if (enabled && world.method_8608() && player == mc.field_1724
                        && player.method_5998(hand).method_7909() instanceof class_1747) play();
                return class_1269.field_5811;
            });
        }

        private class_3414 pick(String n) {
            return switch (n) {
                case "Orb" -> class_3417.field_14627;
                case "ArrowHit" -> class_3417.field_15224;
                case "Anvil" -> class_3417.field_14833;
                case "VillagerNo" -> class_3417.field_15008;
                case "Egg" -> class_3417.field_15219;
                case "Enderman" -> class_3417.field_14879;
                default -> class_3417.field_19149;
            };
        }

        private void play() {
            String n = sound.get();
            if (n.equals("Random")) n = sound.options.get(rnd.nextInt(sound.options.size() - 1));
            float p = pitch.f() + (randomPitch.get() ? (rnd.nextFloat() - 0.5f) * 0.6f : 0f);
            mc.field_1687.method_8486(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), pick(n), class_3419.field_15245, volume.f(), Math.max(0.5f, p), false);
        }
    }
}
