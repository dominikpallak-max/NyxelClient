package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.Util;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3489;
import net.minecraft.class_3966;

public final class CombatPlus {
    private CombatPlus() {}

    public static void register() {
        ModuleManager.reg(new AutoClicker());
        ModuleManager.reg(new AutoGapple());
        ModuleManager.reg(new AutoShield());
        ModuleManager.reg(new AutoWeapon());
        ModuleManager.reg(new MobAura());
        ModuleManager.reg(new JumpCrits());
        ModuleManager.reg(new PearlThrow());
    }

    public static class AutoClicker extends Mod {
        final Setting.Num cps = numI("CPS", 10, 1, 20);
        double acc;
        public AutoClicker() { super("AutoClicker", "Klika za ciebie na celu pod celownikiem (trzymaj LPM)", Category.COMBAT); }
        @Override public void onTick() {
            if (!mc.field_1690.field_1886.method_1434() || mc.field_1755 != null) return;
            acc += cps.d() / 20.0;
            if (acc < 1) return;
            acc -= 1;
            if (mc.field_1765 instanceof class_3966 r) {
                mc.field_1761.method_2918(mc.field_1724, r.method_17782());
                mc.field_1724.method_6104(class_1268.field_5808);
            }
        }
    }

    public static class AutoGapple extends Mod {
        final Setting.Num health = num("Health", 12, 1, 20);
        boolean eating; int prev, ticks;
        public AutoGapple() { super("AutoGapple", "Je zlote jablko, gdy zdrowie spadnie", Category.COMBAT); }
        void stop() {
            mc.field_1690.field_1904.method_23481(false);
            if (eating) mc.field_1724.method_31548().method_61496(prev);
            eating = false;
        }
        @Override public void onDisable() { if (mc.field_1724 != null) stop(); }
        @Override public void onTick() {
            if (!eating) {
                if (mc.field_1724.method_6032() + mc.field_1724.method_6067() > health.d()) return;
                int s = Util.findHotbar(i -> i.method_31574(class_1802.field_8463) || i.method_31574(class_1802.field_8367));
                if (s < 0) return;
                prev = mc.field_1724.method_31548().method_67532();
                mc.field_1724.method_31548().method_61496(s);
                mc.field_1690.field_1904.method_23481(true);
                eating = true; ticks = 0;
            } else if (++ticks > 40 || (ticks > 3 && !mc.field_1724.method_6115())) stop();
        }
    }

    public static class AutoShield extends Mod {
        final Setting.Num range = num("Range", 4, 1, 8);
        boolean held;
        public AutoShield() { super("AutoShield", "Podnosi tarcze, gdy gracz jest blisko", Category.COMBAT); }
        @Override public void onDisable() { if (held) mc.field_1690.field_1904.method_23481(false); held = false; }
        @Override public void onTick() {
            boolean has = mc.field_1724.method_6079().method_31574(class_1802.field_8255) || mc.field_1724.method_6047().method_31574(class_1802.field_8255);
            class_1657 p = has ? Util.nearestPlayer(range.d()) : null;
            if (p != null) { mc.field_1690.field_1904.method_23481(true); held = true; }
            else if (held) { mc.field_1690.field_1904.method_23481(false); held = false; }
        }
    }

    public static class AutoWeapon extends Mod {
        public AutoWeapon() { super("AutoWeapon", "Wybiera miecz/topor, gdy bijesz", Category.COMBAT); }
        static boolean weapon(class_1799 s) { return s.method_31573(class_3489.field_42611) || s.method_31573(class_3489.field_42612); }
        @Override public void onTick() {
            if (!mc.field_1690.field_1886.method_1434() || !(mc.field_1765 instanceof class_3966)) return;
            if (weapon(mc.field_1724.method_6047())) return;
            int s = Util.findHotbar(AutoWeapon::weapon);
            if (s >= 0) mc.field_1724.method_31548().method_61496(s);
        }
    }

    public static class MobAura extends Mod {
        final Setting.Num range = num("Range", 4.2, 1, 6), cooldown = num("Cooldown", 0.92, 0, 1);
        final Setting.Bool rotate = bool("Rotate", true);
        public MobAura() { super("MobAura", "Atakuje tylko wrogie moby", Category.COMBAT); }
        @Override public void onTick() {
            var l = Util.targets(range.d(), false, true, false, false, false);
            if (l.isEmpty()) return;
            class_1309 t = l.get(0);
            if (rotate.get()) Util.lookAt(t.method_5829().method_1005());
            if (mc.field_1724.method_7261(0f) < cooldown.f()) return;
            mc.field_1761.method_2918(mc.field_1724, t);
            mc.field_1724.method_6104(class_1268.field_5808);
        }
    }

    public static class JumpCrits extends Mod {
        public JumpCrits() { super("JumpCrits", "Skacze przy biciu, zeby trafiac krytyki", Category.COMBAT); }
        @Override public void onTick() {
            if (mc.field_1690.field_1886.method_1434() && mc.field_1765 instanceof class_3966
                    && mc.field_1724.method_24828() && !mc.field_1690.field_1903.method_1434()) mc.field_1724.method_6043();
        }
    }

    public static class PearlThrow extends OneShot {
        public PearlThrow() { super("PearlThrow", "Rzuca perle z hotbara (uzyj na bindzie)", Category.COMBAT); }
        @Override protected void run() {
            int s = Util.findHotbar(i -> i.method_31574(class_1802.field_8634));
            if (s < 0) Util.info("§cBrak perly w hotbarze"); else Util.useItem(s);
        }
    }
}
