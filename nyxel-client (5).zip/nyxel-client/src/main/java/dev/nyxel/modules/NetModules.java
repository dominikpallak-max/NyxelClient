package dev.nyxel.modules;

import dev.nyxel.core.*;
import dev.nyxel.util.PacketHooks;
import dev.nyxel.util.Util;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2827;
import net.minecraft.class_2828;
import net.minecraft.class_332;

/** Moduly sieciowe: FakeLag (opoznianie pakietow) i Desync (klient != serwer). */
public final class NetModules {
    private NetModules() {}

    public static void register() {
        ModuleManager.reg(new FakeLag());
        ModuleManager.reg(new Desync());
    }

    private static void hudLine(class_332 ctx, String text, int yOff) {
        int w = mc().field_1772.method_1727(text);
        ctx.method_51433(mc().field_1772, text, ctx.method_51421() / 2 - w / 2,
                ctx.method_51443() / 2 + yOff, 0xFFC77DFF, true);
    }
    private static net.minecraft.class_310 mc() { return net.minecraft.class_310.method_1551(); }
    private static class_243 pos() { var p = mc().field_1724; return new class_243(p.method_23317(), p.method_23318(), p.method_23321()); }

    // ------------------------------------------------------------------
    public static class FakeLag extends Mod {
        // Pakiety sa kolejkowane W KOLEJNOSCI (wszystkie poza keepalive) i zwalniane pojedynczo po DelayMs,
        // z zachowaniem oryginalnych odstepow - serwer widzi normalny lag zamiast paczki/burstu.
        final Setting.Mode mode = mode("Mode", "Constant", "Constant", "Hold");
        final Setting.Num delay = numI("DelayMs", 150, 50, 1500);
        final Setting.Num max = numI("MaxPackets", 200, 20, 1000);
        final Setting.Bool keepAlive = bool("DelayKeepAlive", false);
        final Setting.Bool flushAttack = bool("FlushOnAttack", true);
        final Setting.Bool flushHurt = bool("FlushOnHurt", true);
        final Setting.Bool hud = bool("ShowQueue", false);
        private final java.util.ArrayDeque<Object[]> queue = new java.util.ArrayDeque<>(); // {packet, timestamp}

        public FakeLag() {
            super("FakeLag", "Opoznia pakiety - serwer widzi cie z lagiem", Category.MOVEMENT);
            PacketHooks.FILTERS.add(this::filter);
        }

        private boolean filter(class_2596<?> p) {
            if (!enabled || mc.field_1724 == null) return false;
            if (p instanceof class_2827 && !keepAlive.get()) return false;       // keepalive leci od razu
            if (flushAttack.get() && p instanceof class_2824) { flush(); return false; } // przed atakiem oproznij kolejke
            synchronized (queue) { queue.add(new Object[]{p, System.currentTimeMillis()}); }
            return true;
        }

        public void flush() {
            List<Object[]> snap;
            synchronized (queue) { snap = new ArrayList<>(queue); queue.clear(); }
            for (Object[] e : snap) PacketHooks.sendRaw((class_2596<?>) e[0]);
        }

        @Override public void onDisable() { flush(); }

        @Override public void onTick() {
            if (flushHurt.get() && mc.field_1724.field_6235 > 0) { flush(); return; }
            int size; synchronized (queue) { size = queue.size(); }
            if (size >= max.i()) { flush(); return; }
            if (!mode.is("Constant")) return;
            long now = System.currentTimeMillis();
            while (true) {
                Object[] head;
                synchronized (queue) {
                    head = queue.peek();
                    if (head == null || now - (long) head[1] < delay.i()) break;
                    queue.poll();
                }
                PacketHooks.sendRaw((class_2596<?>) head[0]);
            }
        }

        @Override public void onHud(class_332 ctx) {
            if (!hud.get()) return;
            int size; synchronized (queue) { size = queue.size(); }
            hudLine(ctx, "FakeLag: " + size, 24);
        }
    }

    // ------------------------------------------------------------------
    public static class Desync extends Mod {
        // Serwer dostaje co 20 tickow "stoje w miejscu" (tak jak vanilla przy staniu), a nie calkowita cisze.
        final Setting.Mode onDisable = mode("OnDisable", "Return", "Return", "Sync");
        final Setting.Bool hud = bool("ShowInfo", false);
        private class_243 serverPos, lastPos;
        private int ticks;

        public Desync() {
            super("Desync", "Klient sie rusza, serwer zostaje na starej pozycji", Category.MOVEMENT);
            PacketHooks.FILTERS.add(p -> enabled && mc.field_1724 != null && p instanceof class_2828);
        }

        @Override public void onEnable() {
            if (mc.field_1724 == null) return;
            serverPos = pos();
            lastPos = serverPos;
            ticks = 0;
        }

        @Override public void onTick() {
            class_243 now = pos();
            // duzy skok = teleport od serwera (rubberband) -> serwer i klient znowu zgodne
            if (lastPos != null && now.method_1022(lastPos) > 20) serverPos = now;
            lastPos = now;
            if (serverPos != null && ++ticks % 20 == 0) {
                PacketHooks.sendRaw(new class_2828.class_2829(serverPos.field_1352, serverPos.field_1351, serverPos.field_1350, true, false));
            }
        }

        @Override public void onDisable() {
            if (mc.field_1724 == null || serverPos == null) return;
            if (onDisable.is("Return")) {
                mc.field_1724.method_33574(serverPos);
                mc.field_1724.method_18799(class_243.field_1353);
            }
            serverPos = null;
        }

        @Override public void onHud(class_332 ctx) {
            if (!hud.get() || serverPos == null || mc.field_1724 == null) return;
            hudLine(ctx, String.format("Desync: %.1f", pos().method_1022(serverPos)), 24);
        }
    }
}
